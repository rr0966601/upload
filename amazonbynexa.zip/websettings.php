<?php
define("ALLOW", true);
define('FCPATH', dirname(__FILE__) . DIRECTORY_SEPARATOR);

session_start();

require 'Get/helpers.php';
require 'Get/core.php';

$core = new goNEXA();
$core->runApp();