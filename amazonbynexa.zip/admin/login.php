<?php
session_start();
error_reporting(0);  // Disable error reporting
$settings = parse_ini_file("panel.ini");  // Load settings from config file

// Handle POST request for login
if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    if ($_POST['login'] == $settings['keypanel']){  // Check if the login key matches the one from settings
        $_SESSION['logged_in'] = true;  // Set session as logged in
        header("Location: dashboard.php");  // Redirect to the dashboard
    } else {
        header("Location: ?msg=error");  // Redirect to error page if login key is incorrect
    }
}
?>
<!DOCTYPE html>
<html lang="en" data-layout="vertical" data-topbar="light" data-sidebar="dark" data-sidebar-size="lg" data-sidebar-image="none" data-preloader="disable" data-theme="default" data-theme-colors="default">
<head>
    <meta charset="utf-8" />
    <title>Sign In | NEXACREW</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Sign In NEXACREW" name="description" />
    <meta content="NEXACREW" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/img/favicon.ico">
    <!-- Layout config Js -->
    <script src="assets/js/layout.js"></script>
    <!-- Bootstrap Css -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" />
    <!-- Custom Css-->
    <link href="assets/css/custom.min.css" rel="stylesheet" type="text/css" />
</head>
<body>
    <div class="auth-page-wrapper auth-bg-cover py-5 d-flex justify-content-center align-items-center min-vh-100">
        <div class="bg-overlay"></div>
        <div class="auth-page-content overflow-hidden pt-lg-5">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card overflow-hidden card-bg-fill galaxy-border-none">
                            <div class="row g-0">
                                <div class="col-lg-6">
                                    <div class="p-lg-5 p-4 auth-one-bg h-100">
                                        <div class="bg-overlay"></div>
                                        <div class="position-relative h-100 d-flex flex-column">
                                            <div class="mb-4">
                                                <a href="#" class="d-block">
                                                    <img src="assets/img/gladiator-logo.png" alt="" height="500">
                                                </a>
                                            </div>
                                            <div class="mt-auto">
                                                <div class="mb-3">
                                                    <i class="ri-double-quotes-l display-4 text-success"></i>
                                                </div>
                                                <div id="qoutescarouselIndicators" class="carousel slide" data-bs-ride="carousel">
                                                    <div class="carousel-indicators">
                                                        <button type="button" data-bs-target="#qoutescarouselIndicators" data-bs-slide-to="1" aria-current="true"></button>
                                                    </div>
                                                    <div class="carousel-inner text-center text-white-50 pb-5">
                                                        <div class="carousel-item active">
                                                            <p class="fs-15 fst-italic" id="quote"></p>
                                                            <figcaption class="blockquote-footer ps-3">
                                                                <cite title="Source Title" id="author"></cite>
                                                            </figcaption>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="p-lg-5 p-4">
                                        <div>
                                            <h5 class="text-primary">Sign in to continue to NEXACREW.</h5>
                                        </div>
                                        <?php
                                            // Display error message if login key is incorrect
                                            if ($_GET['msg'] == "error") {
                                                echo '<div class="alert alert-danger alert-dismissible alert-label-icon rounded-label fade show material-shadow" role="alert">
                                                        <i class="ri-error-warning-line label-icon"></i><strong>Sorry</strong>, Login Key is incorrect.
                                                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                                      </div>';
                                            }
                                        ?>
                                        <div class="mt-4">
                                            <form class="needs-validation" novalidate method="POST" action="?do">
                                                <div class="mb-3">
                                                    <div class="float-end">
                                                        <a href="reset-password" class="text-muted">Forgot password?</a>
                                                    </div>
                                                    <label class="form-label" for="password-input">Password</label>
                                                    <div class="position-relative auth-pass-inputgroup mb-3">
                                                        <input type="password" class="form-control pe-5 password-input" placeholder="Enter password" id="password-input" name="login" required>
                                                        <button class="btn btn-link position-absolute end-0 top-0 text-decoration-none text-muted password-addon material-shadow-none" type="button" id="password-addon"><i class="ri-eye-fill align-middle"></i></button>
                                                        <div class="invalid-feedback">
                                                            Please enter the password
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="mt-4">
                                                    <button class="btn btn-success w-100" type="submit" name="signin">Sign In</button>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="mt-5 text-center">
                                            <p class="mb-0">Don't have an account? <a href="signup" class="fw-semibold text-primary text-decoration-underline">Signup</a></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <footer class="footer galaxy-border-none">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="text-center">
                            <p class="mb-0">&copy;
                                <script>document.write(new Date().getFullYear())</script> Gladiator.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </div>

    <!-- JAVASCRIPT -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/simplebar.min.js"></script>
    <script src="assets/js/waves.min.js"></script>
    <script src="assets/js/feather.min.js"></script>
    <script src="assets/js/lord-icon-2.1.0.js"></script>
    <script src="assets/js/plugins.js"></script>
    <!-- Validation init -->
    <script src="assets/js/form-validation.init.js"></script>
    <!-- Password-addon init -->
    <script src="assets/js/password-addon.init.js"></script>
    <!-- DOM Javascript Function -->
    <script type="text/javascript" async>
    let quote = document.getElementById("quote");
    let author = document.getElementById("author");
    const url = "https://dummyjson.com/quotes/random";
    let getQuote = () => {
        fetch(url)
            .then((data) => data.json())
            .then((item) => {
                quote.innerText = item.quote;
                author.innerText = item.author;
            });
        };
    window.addEventListener("load", getQuote);
    </script>
</body>
</html>