<?php
session_start();
error_reporting(0);

// Redirect ke login jika belum login
if (!isset($_SESSION['logged_in'])) {
    header('location: login.php');
    exit;
}

// Path file whitelist & blacklist
$whitelistDir = __DIR__ . "/../Whitelist";

$countryFile = "$whitelistDir/allowCountry.txt";
$ispFile = "$whitelistDir/allowISP.txt";

// Buat folder jika belum ada
@mkdir($whitelistDir, 0777, true);

// Inisialisasi variabel pesan
$saveMessage = "";

// Proses simpan whitelist
if (isset($_POST['allow'])) {
    $saved1 = file_put_contents($countryFile, trim($_POST['allowCountry']));
    $saved2 = file_put_contents($ispFile, trim($_POST['allowISP']));
    if ($saved1 !== false && $saved2 !== false) {
        $saveMessage = "<div class='alert alert-success'>✅ Whitelist saved successfully!</div>";
    } else {
        $saveMessage = "<div class='alert alert-danger'>❌ Failed to save whitelist. Check permissions.</div>";
    }
}


// Baca isi file
$allowCountry = file_exists($countryFile) ? file_get_contents($countryFile) : '';
$allowISP = file_exists($ispFile) ? file_get_contents($ispFile) : '';
?>
<!DOCTYPE html>
<html lang="en" data-layout="vertical" data-topbar="light" data-sidebar="dark" data-sidebar-size="lg" data-sidebar-image="none" data-preloader="disable" data-theme="default" data-theme-colors="default">
<head>
  <meta charset="utf-8" />
  <title>Custom Country & IP Management | NEXACREW</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta content="Country & IP Management" name="description" />
  <meta content="NEXACREW" name="author" />
  <link rel="shortcut icon" href="assets/img/favicon.ico">
  <script src="assets/js/layout.js"></script>
  <link href="assets/css/bootstrap.min.css" rel="stylesheet" />
  <link href="assets/css/icons.min.css" rel="stylesheet" />
  <link href="assets/css/app.min.css" rel="stylesheet" />
  <link href="assets/css/custom.min.css" rel="stylesheet" />
</head>
<body>
  <div id="layout-wrapper">
    <?php require 'header.php'; ?>
    <?php require 'navbar.php'; ?>
    <div class="vertical-overlay"></div>
    <div class="main-content">
      <div class="page-content">
        <div class="container-fluid">

          <div class="row">
            <div class="col-12">
              <div class="page-title-box d-sm-flex align-items-center justify-content-between bg-galaxy-transparent">
                <h4 class="mb-sm-0">Custom Country & IP Management</h4>
                <div class="page-title-right">
                  <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                    <li class="breadcrumb-item active">Country & IP Management</li>
                  </ol>
                </div>
              </div>
            </div>
          </div>

          <?php echo $saveMessage; ?>

          <div class="row">
            <div class="col-xxl-12">
              <div class="card">
                <div class="card-body">
                  <h5 class="card-title">Whitelist Settings</h5>
                  <form method="post">
                    <div class="row">
                      <div class="col-lg-6">
                        <div class="form-group">
                          <label>Allow Country</label>
                          <textarea name="allowCountry" class="form-control" rows="6"><?php echo htmlspecialchars($allowCountry); ?></textarea>
                        </div>
                      </div>
                      <div class="col-lg-6">
                        <div class="form-group">
                          <label>Allow ISP</label>
                          <textarea name="allowISP" class="form-control" rows="6"><?php echo htmlspecialchars($allowISP); ?></textarea>
                        </div>
                      </div>
                    </div>
                    <div class="text-center mt-3">
                      <button type="submit" name="allow" class="btn btn-success"><i class="fa fa-save"></i> Save Whitelist</button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>

      <footer class="footer">
        <div class="container-fluid">
          <div class="row">
            <div class="col-sm-6">
              <script>document.write(new Date().getFullYear())</script> © NEXACREW.
            </div>
            <div class="col-sm-6 text-sm-end">
              Design & Develop by NEXACREW
            </div>
          </div>
        </div>
      </footer>
    </div>
  </div>

  <?php require 'footer.php'; ?>
  <script src="assets/js/bootstrap.bundle.min.js"></script>
  <script src="assets/js/simplebar.min.js"></script>
  <script src="assets/js/waves.min.js"></script>
  <script src="assets/js/feather.min.js"></script>
  <script src="assets/js/plugins.js"></script>
</body>
</html>
