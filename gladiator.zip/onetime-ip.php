<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ip'])) {
    $ip = filter_var($_POST['ip'], FILTER_VALIDATE_IP);

    if ($ip) {
        $htaccessPath = ".htaccess"; 
        $blockRule = "\nDeny from $ip";

        if (file_exists($htaccessPath)) {
            $htaccessContent = file_get_contents($htaccessPath);
            if (strpos($htaccessContent, $blockRule) === false) {
                file_put_contents($htaccessPath, $blockRule, FILE_APPEND | LOCK_EX);
            }
        } else {
            file_put_contents($htaccessPath, "Order Allow,Deny\nDeny from $ip\nAllow from all", LOCK_EX);
        }
    }
}
?>
