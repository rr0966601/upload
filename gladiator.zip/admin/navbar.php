<!-- ========== App Menu ========== -->
<div class="app-menu navbar-menu">
    <div class="navbar-brand-box">
        <a href="/admin/dashboard" class="logo logo-dark">
            <span class="logo-sm">
                <img src="assets/img/gladiator-logo.png" alt="" height="100">
            </span>
            <span class="logo-lg">
                <img src="assets/img/gladiator-logo.png" alt="" height="100">
            </span>
        </a>
        <a href="/admin/dashboard" class="logo logo-light">
            <span class="logo-sm">
                <img src="assets/img/gladiator-logo.png" alt="" height="100">
            </span>
            <span class="logo-lg">
                <img src="assets/img/gladiator-logo.png" alt="" height="100">
            </span>
        </a>
        <button type="button" class="btn btn-sm p-0 fs-20 header-item float-end btn-vertical-sm-hover" id="vertical-hover">
            <i class="ri-record-circle-line"></i>
        </button>
    </div>
    <div class="dropdown sidebar-user m-1 rounded">
        <button type="button" class="btn material-shadow-none" id="page-header-user-dropdown" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <span class="d-flex align-items-center gap-2">
                <img class="rounded header-profile-user" src="assets/img/avatar.jpg" alt="Header Avatar">
                <span class="text-start">
                    <span class="d-block fw-medium sidebar-user-name-text">Who Am I?</span>
                    <span class="d-block fs-14 sidebar-user-name-sub-text"><i class="ri ri-circle-fill fs-10 text-success align-baseline"></i> <span class="align-middle">Online</span></span>
                </span>
            </span>
        </button>
        <div class="dropdown-menu dropdown-menu-end">
            <h6 class="dropdown-header">Welcome!</h6>
            <a class="dropdown-item" href="logout"><i class="mdi mdi-logout text-muted fs-16 align-middle me-1"></i> <span class="align-middle">Logout</span></a>
        </div>
    </div>
    <div id="scrollbar">
        <div class="container-fluid">
            <div id="two-column-menu"></div>
            <ul class="navbar-nav" id="navbar-nav">
                <li class="menu-title"><span>Menu</span></li>
                <li class="nav-item">
                    <a class="nav-link menu-link" href="/admin/dashboard">
                        <i class="ri-dashboard-2-line"></i> <span>Dashboards</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link menu-link" href="/admin/statistics">
                        <i class="ri-bar-chart-grouped-line"></i> <span>Statistics</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link menu-link" href="/admin/settings">
                        <i class="ri-user-settings-line"></i> <span>Settings</span>
                    </a>
                </li>
                <?php 
                function settings() {
                    $file = "../config/settings.ini";
                    if (file_exists($file)) {
                        $settings = parse_ini_file($file);
                        if ($settings === false) {
                            // Handle error in parsing the file
                            throw new Exception("Failed to parse the configuration file.");
                        }
                        return $settings;
                    } else {
                        // Handle the case where the file does not exist
                        throw new Exception("Configuration file not found: " . $file);
                    }
                }
                // Example usage of settings function
                try {
                    $config = settings();
                    // Use the settings...
                } catch (Exception $e) {
                    // Handle exceptions gracefully (log or display error)
                    echo "Error: " . $e->getMessage();
                }
                $settings = settings(); 
                ?>
                <li class="nav-item">
                    <a class="nav-link menu-link" href="https://<?php echo $_SERVER['SERVER_NAME']; ?>/?<?= $settings['site_parameter'] ?>" target="_blank">
                        <i class="ri-global-line"></i> <span>View Scam</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
    <div class="sidebar-background"></div>
</div>
<!-- Left Sidebar End -->