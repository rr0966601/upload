<?php
session_start();
error_reporting(0);
if (!isset($_SESSION['logged_in'])) {
    header('location: login');
    die();
}
?>
<!DOCTYPE html>
<html lang="en" data-layout="vertical" data-topbar="light" data-sidebar="dark" data-sidebar-size="lg" data-sidebar-image="none" data-preloader="disable" data-theme="default" data-theme-colors="default">
<head>
    <meta charset="utf-8" />
    <title>Statistics | Gladiator</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Statistics Gladiator" name="description" />
    <meta content="Gladiator" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/img/favicon.ico">
    <!-- Layout config Js -->
    <script src="assets/js/layout.js"></script>
    <!-- Bootstrap Css -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" />
    <!-- Custom Css-->
    <link href="assets/css/custom.min.css" rel="stylesheet" type="text/css" />
    <!-- Data Tables CSS -->
    <link href="assets/css/dataTables.bootstrap5.css" rel="stylesheet" />
    <link href="assets/css/buttons.bootstrap5.min.css" rel="stylesheet">
    <link href="assets/css/responsive.bootstrap5.css" rel="stylesheet" />
</head>
<body>
    <div id="layout-wrapper">
        <?php require 'header.php'; ?>
        <?php require 'navbar.php'; ?>
        <!-- Vertical Overlay-->
        <div class="vertical-overlay"></div>
        <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="main-content">
            <div class="page-content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box d-sm-flex align-items-center justify-content-between bg-galaxy-transparent">
                                <h4 class="mb-sm-0">Statistics</h4>
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item">
                                            <a href="javascript: void(0);">Statistics</a>
                                        </li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xxl-12">
                    <div class="card">
                        <div class="card-header align-items-center d-flex">
                            <h4 class="card-title mb-0 flex-grow-1">BOT Information</h4>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <div id="basic-datatable_wrapper" class="dataTables_wrapper dt-bootstrap5">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <?php
                                            $file_path = "../logs/total_bot.txt";
                                            if (file_exists($file_path)) {
                                                $bit = file_get_contents($file_path);
                                                $bit = explode("\n", $bit);
                                                $list = array_reverse($bit);
                                            } else {
                                                // Handle file not found
                                                echo "Log file not found.";
                                                $list = [];
                                            }
                                            ?>
                                            <table class="table align-middle m-0" id="basic-datatable" role="grid" aria-describedby="basic-datatable_info">
                                                <thead class="text-muted table-light">
                                                    <tr>
                                                        <th class="text-center">Time</th>
                                                        <th class="text-center">Country</th>
                                                        <th class="text-center">IP Address</th>
                                                        <th class="text-center">Browser</th>
                                                        <th class="text-center">Operating System</th>
                                                        <th class="text-center">Block Type</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                <?php
                                                foreach ($list as $gladiator) {
                                                    // Split the line by "|", but only if the line is not empty
                                                    if (empty($gladiator)) {
                                                        continue; // Skip empty lines
                                                    }
                                                    $gladiator = explode("|", $gladiator);
                                                    // Ensure the line has the expected number of parts (at least 6)
                                                    if (count($gladiator) < 6) {
                                                        continue; // Skip lines with insufficient data
                                                    }
                                                    $time = $gladiator[1];
                                                    $country = $gladiator[2];
                                                    $ip = $gladiator[3];
                                                    $bs = $gladiator[4];
                                                    $os = $gladiator[5];
                                                    $type = $gladiator[6];
                                                    // Skip rows where IP is empty
                                                    if ($ip != "") {
                                                        ?>
                                                        <tr>
                                                            <td class="text-center"><?= $time; ?></td>
                                                            <td class="text-center"><?= $country; ?></td>
                                                            <td class="text-center"><?= $ip; ?></td>
                                                            <td class="text-center"><?= $bs; ?></td>
                                                            <td class="text-center"><?= $os; ?></td>
                                                            <td class="text-center"><?= $type; ?></td>
                                                        </tr>
                                                        <?php
                                                    }
                                                }
                                                ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-sm-6">
                                <script>document.write(new Date().getFullYear())</script> © Gladiator.
                            </div>
                            <div class="col-sm-6">
                                <div class="text-sm-end d-none d-sm-block">
                                    Design & Develop by Gladiator
                                </div>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
            <!-- end main content-->
        </div>
        <!-- END layout-wrapper -->
        <?php require 'footer.php'; ?>
        <!-- JAVASCRIPT -->
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <script src="assets/js/simplebar.min.js"></script>
        <script src="assets/js/waves.min.js"></script>
        <script src="assets/js/feather.min.js"></script>
        <script src="assets/js/lord-icon-2.1.0.js"></script>
        <script src="assets/js/plugins.js"></script>
        <script src="assets/js/jquery-3.6.0.min.js"></script>
        <!-- Data tables -->
        <script src="assets/js/jquery.dataTables.min.js"></script>
        <script src="assets/js/dataTables.bootstrap5.js"></script>
        <script src="assets/js/dataTables.responsive.min.js"></script>
        <script src="assets/js/table-data.js"></script>
        <!-- Dashboard init -->
        <script src="assets/js/dashboard-analytics.init.js"></script>
        <!-- App js -->
        <script src="assets/js/app.js"></script>
    </body>
</html>