<?php

/**
 * moodle_webshell  web services implemntation.
 *
 * @package    moodle_webshell
 * @copyright 2022, Remi GASCOU (Podalirius) <podalirius@protonmail.com>
 * @license MIT
 */

require_once($CFG->libdir."/externallib.php");

class local_moodle_webshell_external extends external_api {

}