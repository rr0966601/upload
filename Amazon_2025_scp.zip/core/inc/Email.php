<?php

/* Recipients, Supports multi values seperated by comma */
$recipients = array(
	"whoiskamley@gmail.com",
	);

?>