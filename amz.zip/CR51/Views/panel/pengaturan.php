<!DOCTYPE html>
<html lang="zxx">

<head>

    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>Admin - CR51 NETWORK</title>
    <link rel="icon" href="<?= base_url() ?>CR51/Assets/Panel/Assets/img/mini_logo.png" type="image/png">

    <link href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.css" rel="stylesheet">

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/css/bootstrap1.min.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/themefy_icon/themify-icons.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/niceselect/css/nice-select.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/owl_carousel/css/owl.carousel.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/gijgo/gijgo.min.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/font_awesome/css/all.min.css" />
    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/tagsinput/tagsinput.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datepicker/date-picker.css" />
    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/vectormap-home/vectormap-2.0.2.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/scroll/scrollable.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/css/jquery.dataTables.min.css" />
    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/css/responsive.dataTables.min.css" />
    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/css/buttons.dataTables.min.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/text_editor/summernote-bs4.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/morris/morris.css">

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/material_icon/material-icons.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/css/metisMenu.css">

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/css/style1.css" />
    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/css/colors/default.css" id="colorSkinCSS">
</head>

<body class="crm_body_bg">
    <?php echo view('panel/menu'); ?>
    <section class="main_content dashboard_part large_header_bg">
        <?php echo view('panel/atas'); ?>
        <div class="main_content_iner overly_inner ">
            <div class="container-fluid p-0 ">

                <div class="row">
                    <div class="col-lg-12">
                        <div class="white_card card_height_100 mb_30">
                            <div class="white_card_header">
                                <div class="box_header m-0">
                                    <div class="main-title">
                                        <h3 class="m-0">Pengaturan Panel</h3>
                                    </div>
                                </div>
                            </div>
                            <div class="white_card_body">
                                <div class="card-body">
                                    <form action="<?= base_url() ?>/panel/update" method="post">
                                        <input type="text" class="form-control" name="token" placeholder="Enter Email" value="<?php echo _config('TOKEN'); ?>" hidden>
                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <label class="form-label" for="inputEmail4">Email Result</label>
                                                <input type="email" class="form-control" name="result" value="<?php echo _config('RESULT'); ?>" placeholder="Email">
                                            </div>
                                            <div class="col-md-6">
                                                <label class="form-label" for="inputPassword4">Parameter</label>
                                                <input type="text" class="form-control" name="parameter" value="<?php echo _config('PARAMETER'); ?>" placeholder="Parameter">
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class=" col-md-6">
                                                <label class="form-label" for="inputState">Antibot</label>
                                                <select id="inputState" class="form-select" name="antibot">
                                                    <option <?php if (_config('ANTIBOT') == 'off') {
                                                                echo "selected=selected";
                                                            } ?> value="off">Off</option>
                                                    <option <?php if (_config('ANTIBOT') == 'on') {
                                                                echo "selected=selected";
                                                            } ?> value="on">On</option>
                                                </select>
                                            </div>
                                            <div class=" col-md-6">
                                                <label class="form-label" for="inputState">KillBot</label>
                                                <select id="inputState" class="form-select" name="killbot">
                                                    <option <?php if (_config('KILLBOT') == 'off') {
                                                                echo "selected=selected";
                                                            } ?> value="off">Off</option>
                                                    <option <?php if (_config('KILLBOT') == 'on') {
                                                                echo "selected=selected";
                                                            } ?> value="on">On</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class=" col-md-4">
                                                <label class="form-label" for="inputState">BLOCK VPN</label>
                                                <select id="inputState" class="form-select" name="vpndetect">
                                                    <option <?php if (_config('VPNDETECT') == 'off') {
                                                                echo "selected=selected";
                                                            } ?> value="off">Off</option>
                                                    <option <?php if (_config('VPNDETECT') == 'on') {
                                                                echo "selected=selected";
                                                            } ?> value="on">On</option>
                                                </select>
                                            </div>
                                            <div class=" col-md-4">
                                                <label class="form-label" for="inputState">Redirect</label>
                                                <select id="inputState" class="form-select" name="redirect">
                                                    <option <?php if (_config('NOTFOUND') == '404') {
                                                                echo "selected=selected";
                                                            } ?> value="404">404 ( Default )</option>
                                                    <option <?php if (_config('NOTFOUND') == 'custom') {
                                                                echo "selected=selected";
                                                            } ?> value="custom">Custom</option>
                                                    <option <?php if (_config('NOTFOUND') == 'google') {
                                                                echo "selected=selected";
                                                            } ?> value="google">Google</option>
                                                </select>
                                            </div>
                                            <div class=" col-md-4">
                                                <label class="form-label" for="inputState">Result Telegram</label>
                                                <select id="inputState" class="form-select" name="telegram">
                                                    <option <?php if (_config('Telegram') == 'off') {
                                                                echo "selected=selected";
                                                            } ?> value="off">Off</option>
                                                    <option <?php if (_config('Telegram') == 'on') {
                                                                echo "selected=selected";
                                                            } ?> value="on">On</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class=" col-md-4">
                                                <label class="form-label" for="inputState">GET ACCOUNT</label>
                                                <select id="inputState" class="form-select" name="getaccount">
                                                    <option <?php if (_config('GETACCOUNT') == 'off') {
                                                                echo "selected=selected";
                                                            } ?> value="off">Off</option>
                                                    <option <?php if (_config('GETACCOUNT') == 'on') {
                                                                echo "selected=selected";
                                                            } ?> value="on">On</option>
                                                </select>
                                            </div>
                                            <div class=" col-md-4">
                                                <label class="form-label" for="inputState">GET EMAIL</label>
                                                <select id="inputState" class="form-select" name="getemail">
                                                    <option <?php if (_config('GETEMAIL') == 'off') {
                                                                echo "selected=selected";
                                                            } ?> value="off">Off</option>
                                                    <option <?php if (_config('GETEMAIL') == 'on') {
                                                                echo "selected=selected";
                                                            } ?> value="on">On</option>
                                                </select>
                                            </div>
                                            <div class=" col-md-4">
                                                <label class="form-label" for="inputState">DOUBLE EMAIL</label>
                                                <select id="inputState" class="form-select" name="doubleemail">
                                                    <option <?php if (_config('DOUBLEEMAIL') == 'off') {
                                                                echo "selected=selected";
                                                            } ?> value="off">Off</option>
                                                    <option <?php if (_config('DOUBLEEMAIL') == 'on') {
                                                                echo "selected=selected";
                                                            } ?> value="on">On</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class=" col-md-4">
                                                <label class="form-label" for="inputState">GET 3DSCURE</label>
                                                <select id="inputState" class="form-select" name="get3dscure">
                                                    <option <?php if (_config('GET3DSCURE') == 'off') {
                                                                echo "selected=selected";
                                                            } ?> value="off">Off</option>
                                                    <option <?php if (_config('GET3DSCURE') == 'on') {
                                                                echo "selected=selected";
                                                            } ?> value="on">On</option>
                                                </select>
                                            </div>
                                            <div class=" col-md-4">
                                                <label class="form-label" for="inputState">GET BANK</label>
                                                <select id="inputState" class="form-select" name="getbank">
                                                    <option <?php if (_config('GETBANK') == 'off') {
                                                                echo "selected=selected";
                                                            } ?> value="off">Off</option>
                                                    <option <?php if (_config('GETBANK') == 'on') {
                                                                echo "selected=selected";
                                                            } ?> value="on">On</option>
                                                </select>
                                            </div>
                                            <div class=" col-md-4">
                                                <label class="form-label" for="inputState">DOUBLE CARD</label>
                                                <select id="inputState" class="form-select" name="doublecard">
                                                    <option <?php if (_config('DOUBLECARD') == 'off') {
                                                                echo "selected=selected";
                                                            } ?> value="off">Off</option>
                                                    <option <?php if (_config('DOUBLECARD') == 'on') {
                                                                echo "selected=selected";
                                                            } ?> value="on">On</option>
                                                </select>
                                            </div>
                                        </div>
                                </div>
                                <button type="submit" name="updatesetting" class="btn btn-primary">Gass</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
        <?php echo view('panel/bawah'); ?>
    </section>


    <div id="back-top" style="display: none;">
        <a title="Go to Top" href="#">
            <i class="ti-angle-up"></i>
        </a>
    </div>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/js/jquery1-3.4.1.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/js/popper1.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/js/bootstrap1.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/js/metisMenu.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/count_up/jquery.waypoints.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/chartlist/Chart.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/count_up/jquery.counterup.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/niceselect/js/jquery.nice-select.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/owl_carousel/js/owl.carousel.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/js/jquery.dataTables.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/js/dataTables.responsive.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/js/dataTables.buttons.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/js/buttons.flash.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/js/jszip.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/js/pdfmake.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/js/vfs_fonts.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/js/buttons.html5.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/js/buttons.print.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datepicker/datepicker.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datepicker/datepicker.en.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datepicker/datepicker.custom.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/js/chart.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/chartjs/roundedBar.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/progressbar/jquery.barfiller.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/tagsinput/tagsinput.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/text_editor/summernote-bs4.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/am_chart/amcharts.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/scroll/perfect-scrollbar.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/scroll/scrollable-custom.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/vectormap-home/vectormap-2.0.2.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/vectormap-home/vectormap-world-mill-en.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/apex_chart/apex-chart2.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/apex_chart/apex_dashboard.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/echart/echarts.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/chart_am/core.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/chart_am/charts.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/chart_am/animated.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/chart_am/kelly.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/chart_am/chart-custom.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/js/dashboard_init.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/js/custom.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.js"></script>
    <?php if (@$_SESSION['sukses']) { ?>
        <script>
            <?php echo $_SESSION['sukses']; ?>
        </script>
    <?php unset($_SESSION['sukses']);
    } ?>
</body>

</html>