<?php
// File Ini Hanya Untuk Redirect, Tidak Ada Sangkut Paut File Lain
header("Location: /install/");
die();
